/*
 *  Copyright (c) 2012 Oracle and/or its affiliates.
 *  All rights reserved
 *
 *  THIS IS UNPUBLISHED PROPRIETARY
 *  SOURCE CODE OF ORAClE CORPORATION.
 *  The copyright notice above does not
 *  evidence any actual or intended
 *  publication of such source code.
 *
 * #ident "@(#) samples/atmi/javaapp/jsimpapp/MyTuxedoJavaServer.java $Revision: 1.2 $"
 */
import weblogic.wtc.jatmi.TypedBuffer;
import weblogic.wtc.jatmi.TypedString;
import com.oracle.tuxedo.tjatmi.*;

public class MyTuxedoJavaServer extends TuxedoJavaServer {

    public MyTuxedoJavaServer() {
        return;
    }

    public int tpsvrinit() throws TuxException {
        System.out.println("MyTuxedoJavaServer.tpsvrinit()");
        return 0;
    }

    public void tpsvrdone() {
        System.out.println("MyTuxedoJavaServer.tpsvrdone()");
        return;
    }

    public void JAVATOUPPER(TPSVCINFO rqst) throws TuxException {
        TypedBuffer     mySvcData;
        TuxAppContext   myAppCtxt = null;
        TuxATMIReply    myTuxReply = null;
        TypedBuffer     myReplyTb = null;

        /* Get TuxAppContext first */
        myAppCtxt = getTuxAppContext();

        mySvcData = rqst.getServiceData();
        TypedString myTbString = (TypedString)mySvcData;

        myAppCtxt.userlog("Handling in JAVATOUPPER()");
        myAppCtxt.userlog("Received string is:" + myTbString.toString());

        TypedString myRplyTbString = null;
        String      myNewStr = myTbString.toString();
        try {
            myNewStr = myNewStr.toUpperCase();
            myRplyTbString = new TypedString(myNewStr);

            /* Return new string to client */
            myAppCtxt.tpreturn(TPSUCCESS, 0, myRplyTbString, 0);
        }
        catch (TuxATMITPException te) {
            myAppCtxt.userlog("TuxATMITPException: " + te);
            try {
                myAppCtxt.tpreturn(TPFAIL, 0, null, 0);
            } catch (Exception ex) {
                myAppCtxt.userlog("Exception: " + ex);
                throw new TuxException(ex.getMessage());
            }
        }
        return;
    }


    public void JAVATOUPPERFORWARD(TPSVCINFO rqst) throws TuxException {
        TypedBuffer     mySvcData;
        TuxAppContext   myAppCtxt  = null;
        TuxATMIReply    myTuxReply = null;
        TypedBuffer     myReplyTb  = null;
        long            myFlags    = TPSIGRSTRT;

        /* Get TuxAppContext first */
        myAppCtxt = getTuxAppContext();

        mySvcData = rqst.getServiceData();
        TypedString myTbString = (TypedString)mySvcData;

        myAppCtxt.userlog("Handling in JAVATOUPPERFORWARD()");
        myAppCtxt.userlog("Received string is:" + myTbString.toString());

        /* Call another service "TOUPPER" */
        try {
            myTuxReply = myAppCtxt.tpcall("TOUPPER", mySvcData, myFlags);

            /* If success, get reply buffer */
            myReplyTb = myTuxReply.getReplyBuffer();

            TypedString myReplyTbStr = (TypedString)myReplyTb;
            myAppCtxt.userlog("Replied string from TOUPPER:" + myReplyTbStr.toString());

            /* Return the replied buffer to client */
            myAppCtxt.tpreturn(TPSUCCESS, 0, myReplyTb, 0);
        } catch (TuxATMITPReplyException tre) {
            myAppCtxt.userlog("TuxATMITPReplyException:" + tre);
            try {
                myAppCtxt.tpreturn(TPFAIL, 0, null, 0);
            } catch (Exception ex) {
                myAppCtxt.userlog("Exception: " + ex);
                throw new TuxException(tre.getMessage());
            }
        } catch (TuxATMITPException te) {
            myAppCtxt.userlog("TuxATMITPException:" + te);
            try {
                myAppCtxt.tpreturn(TPFAIL, 0, null, 0);
            } catch (Exception ex) {
                myAppCtxt.userlog("Exception: " + ex);
                throw new TuxException(te.getMessage());
            }
        }
        return;
    }

}

