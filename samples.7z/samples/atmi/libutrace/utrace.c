/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/libutrace/utrace.c	$Revision: 1.3 $" */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "atmi.h"
#ifdef _TM_WIN
#include <windows.h>
#endif
#ifdef _TMPROTOTYPES
#include <stdarg.h>
#else
#include <varargs.h>
#endif
#include "userlog.h"
#include "utrace.h"

/*** utrace() - add data to utrace ***/

#define NEST (utrrec->nest[0] + utrrec->nest[1])

int
#ifdef _TMPROTOTYPES
utrace(_utrrec *utrrec, char *fmt, ...)
#else
#ifdef lint
utrace(utrrec, Xfmt, va_alist)
_utrrec *utrrec;
char *Xfmt;
va_dcl
#else
utrace(utrrec, va_alist)
va_dcl
#endif
#endif
{
	char buf[2*UTRMAXLEN], rec[2*UTRMAXLEN];
#ifndef _TMPROTOTYPES
	char	*fmt;
#endif
	va_list args;
	char *bufp, *recp;

#if !defined(_TMPROTOTYPES) && defined(lint)
	fmt = Xfmt;
#endif

#ifdef _TMPROTOTYPES
	va_start(args, fmt);
#else
	va_start(args);
	fmt = va_arg(args, char *);
#endif

	(void) vsprintf(buf, fmt, args);

	for (bufp = buf, recp = rec; *bufp != '\0'; *recp++ = *bufp++) {
		/* at the top of the line */
		if (utrrec->tol && *bufp != '\n') {
			switch (*bufp) {
			case ')':
			case '}':
				if (utrrec->nest[1] > 0)
					utrrec->nest[1]--;
				break;
			default:
				break;
			}

			memset(recp, ' ', NEST*UTRINDSIZ);
			recp += NEST*UTRINDSIZ;
			utrrec->tol = 0;
		}

		/* at the end of the line */
		if (*bufp == '\n') {
			switch (*(bufp-1)) {
			case '(':
				utrrec->nest[1]++;
			case '{':
				utrrec->nest[1]++; 
				break;
			case ')':
				if (utrrec->nest[1] > 0)
					utrrec->nest[1]--;
				break;
			default:
				break;
			}

			utrrec->tol = 1;
		}
	}

	/* terminate rec */
	*recp = '\0';

	/* allocate space for utrace record */
	if (utrrec->rec == NULL) {
		utrrec->size = UTRBUFSIZ;
		utrrec->rec = malloc(utrrec->size);
		*(utrrec->rec) = '\0';
	}

	/* allocate more space if necessary */
	if (strlen(utrrec->rec) + strlen(rec) >= utrrec->size) {
		utrrec->size += UTRBUFSIZ;
		utrrec->rec = realloc(utrrec->rec, utrrec->size);
	}

	strcat(utrrec->rec, rec);

	return 0;
}

/*** utrudata() - add user data ***/

/* _buftype - Tuxedo buffer types */

typedef enum {
	buf_carray,
	buf_string,
	buf_fml,
	buf_view,
	buf_x_octet,
	buf_x_c_type,
	buf_x_common,
	buf_fml32,
	buf_view32,
	buf_xml,
	buf_mbstring,
	buf_end
} _buftype;

static struct {
	_buftype type;
	char *name;
} buftypes[] = {
	{buf_carray, "CARRAY"},
	{buf_string, "STRING"},
	{buf_fml, "FML"},
	{buf_view, "VIEW"},
	{buf_x_octet, "X_OCTET"},
	{buf_x_c_type, "X_C_TYPE"},
	{buf_x_common, "X_COMMON"},
	{buf_fml32, "FML32"},
	{buf_view32, "VIEW32"},
	{buf_xml, "XML"},
	{buf_mbstring, "MBSTRING"},
	{buf_end, NULL}
};

static int
#ifdef _TMPROTOTYPES
utrudata(_utrrec *utrrec, char *data, long len, int utrvalue)
#else
utrudata(utrrec, data, len)
_utrrec *utrrec;
char *data;
long len;
int utrvalue;
#endif
{
	int ret = 0;
	long size;
	char type[9], subtype[17];
	char enc[32];
	int i;

	utrace(utrrec, "(0x%lx){\n", data);
	utrace(utrrec, "len=%ld\n", len);

	if (data == NULL)
		goto ret;

	/* data type and subtype */
	type[8] = subtype[16] = '\0';
	size = tptypes(data, type, subtype);
	if (size == -1) {
		ret = -1;
		goto ret;
	}

	utrace(utrrec, "type=\"%s\"\n", type);

	if (subtype[0])
		utrace(utrrec, "subtype=\"%s\"\n", subtype);

	for (i = 0; buftypes[i].type != buf_end; i++) {
		if (strcmp(buftypes[i].name, type) == 0)
			break;
	}

	/* MBSTRING encoding name */
	switch (buftypes[i].type) {
	case buf_fml32:
	case buf_view32:
	case buf_mbstring:
		ret = tpgetmbenc(data, enc, 0);
		if (ret == -1) {
			switch (tperrno) {
			case TPEPROTO:
				strcpy(enc, "<none>");
				break;
			default:
				enc[0] = '\0';
				goto ret;
			}
		}
		utrace(utrrec, "mbenc=\"%s\"\n", enc);
		break;
	default:
		break;
	}

	/* data value */
	if (utrvalue) {
		utrace(utrrec, "value=");

		switch (buftypes[i].type) {
		case buf_carray:
		case buf_x_octet:
			utrcarray(utrrec, data, len);
			break;
		case buf_string:
		case buf_mbstring:
			utrstring(utrrec, data, len);
			break;
		case buf_fml:
			utrfml(utrrec, data);
			break;
		case buf_view:
		case buf_x_c_type:
		case buf_x_common:
			utrview(utrrec, NULL, data);
			break;
		case buf_fml32:
			utrfml32(utrrec, data);
			break;
		case buf_view32:
			utrview32(utrrec, NULL, data);
			break;
		case buf_xml:
			utrace(utrrec, "<XML buffer: TODO>\n");
			break;
		case buf_end:
			break;
		default:
			break;
		}
	}

ret:
	utrace(utrrec, "}\n");
	return ret;
}

/*** utrodata() - add out data ***/

static int
#ifdef _TMPROTOTYPES
utrodata(_utrrec *utrrec, char **datap, long *lenp, int utrtype)
#else
utrodata(utrrec, datap, lenp)
_utrrec *utrrec;
char **datap;
long *lenp;
int utrtype;
#endif
{
	utrace(utrrec, "(0x%lx){\n", datap);

	utrace(utrrec, "data=");
	utrudata(utrrec, *datap, *lenp, utrtype == utr_enter ? 0 : 1);

	utrace(utrrec, "len=(0x%lx)%ld\n", lenp, *lenp);

	utrace(utrrec, "}\n");

	return 0;
}

/*** utrvalname() - convert value to string and add ***/

/* _valname - value and visual name */

typedef struct {
	long val;
	char* name;
} _valname;

/* valname for revent */

static _valname revent_valname[] = {
	{TPEV_DISCONIMM, "TPEV_DISCONIMM"},
	{TPEV_SENDONLY, "TPEV_SENDONLY"},
	{TPEV_SVCERR, "TPEV_SVCERR"},
	{TPEV_SVCFAIL, "TPEV_SVCFAIL"},
	{TPEV_SVCSUCC, "TPEV_SVCSUCC"},
	{0, NULL}
};

/* valname for tpreturn */

static _valname rval_valname[] = {
	{TPFAIL, "TPFAIL"},
	{TPSUCCESS, "TPSUCCESS"},
	{TPEXIT, "TPEXIT"},
	{0, NULL}
};

static int
#ifdef _TMPROTOTYPES
utrvalname(_utrrec *utrrec, _valname *valnames, long arg)
#else
utrvalname(utrrec, valname, arg)
_utrrec *utrrec;
_valname *valnames;
long arg;
#endif
{
	int i, nvalnames;

	for (i = 0, nvalnames = 0; valnames[i].val; i++) {
		if (arg == valnames[i].val) {
			utrace(utrrec, valnames[i].name);
			break;
		}
	}

	if (valnames[i].val == 0)
		utrace(utrrec, "<unknown>");

	utrace(utrrec, "\n");

	return 0;
}

/*** utrflags() - convert flags to string and add ***/

/* _flag - flag value and visual name */

typedef struct {
	long flag;
	char* name;
} _flag;


/* flags for svcinfo */

static _flag svc_flags[] = {
	{TPNOBLOCK, "TPNOBLOCK"},
	{TPSIGRSTRT, "TPSIGRSTRT"},
	{TPNOREPLY, "TPNOREPLY"},
	{TPNOTRAN, "TPNOTRAN"},
	{TPTRAN, "TPTRAN"},
	{TPNOTIME, "TPNOTIME"},
	{TPABSOLUTE, "TPABSOLUTE"},
	{TPGETANY, "TPGETANY"},
	{TPNOCHANGE, "TPNOCHANGE"},
	{RESERVED_BIT1, "RESERVED_BIT1"},
	{TPCONV, "TPCONV"},
	{TPSENDONLY, "TPSENDONLY"},
	{TPRECVONLY, "TPRECVONLY"},
	{TPACK, "TPACK"},
	{RESERVED_BIT2, "RESERVED_BIT2"},
	{RESERVED_BIT3, "RESERVED_BIT3"},
	{RESERVED_BIT4, "RESERVED_BIT4"},
	{RESERVED_BIT5, "RESERVED_BIT5"},
	{0, NULL}
};

/* flags for tpinit */

static _flag tpinit_flags[] = {
	{TPU_MASK, "TPU_MASK"},
	{TPU_SIG, "TPU_SIG"},
	{TPU_DIP, "TPU_DIP"},
	{TPU_IGN, "TPU_IGN"},
	{TPSA_FASTPATH, "TPSA_FASTPATH"},
	{TPSA_PROTECTED, "TPSA_PROTECTED"},
	{TPMULTICONTEXTS, "TPMULTICONTEXTS"},
	{TPU_THREAD, "TPU_THREAD"},
	{0, NULL}
};

/* flags for tpqctl */

static _flag tpqctl_flags[] = {
	{TPQCORRID, "TPQCORRID"},
	{TPQFAILUREQ, "TPQFAILUREQ"},
	{TPQBEFOREMSGID, "TPQBEFOREMSGID"},
	{TPQGETBYMSGIDOLD, "TPQGETBYMSGIDOLD"},
	{TPQMSGID, "TPQMSGID"},
	{TPQPRIORITY, "TPQPRIORITY"},
	{TPQTOP, "TPQTOP"},
	{TPQWAIT, "TPQWAIT"},
	{TPQREPLYQ, "TPQREPLYQ"},
	{TPQTIME_ABS, "TPQTIME_ABS"},
	{TPQTIME_REL, "TPQTIME_REL"},
	{TPQGETBYCORRIDOLD, "TPQGETBYCORRIDOLD"},
	{TPQPEEK, "TPQPEEK"},
	{TPQDELIVERYQOS, "TPQDELIVERYQOS"},
	{TPQREPLYQOS, "TPQREPLYQOS"},
	{TPQEXPTIME_ABS, "TPQEXPTIME_ABS"},
	{TPQEXPTIME_REL, "TPQEXPTIME_REL"},
	{TPQEXPTIME_NONE, "TPQEXPTIME_NONE"},
	{TPQGETBYMSGID, "TPQGETBYMSGID"},
	{TPQGETBYCORRID, "TPQGETBYCORRID"},
	{0, NULL}
};

static int
#ifdef _TMPROTOTYPES
utrflags(_utrrec *utrrec, _flag *flags, long arg)
#else
utrflags(utrrec, flags, arg)
_utrrec *utrrec;
_flag *flags;
long arg;
#endif
{
	int i, nflags;

	for (i = 0, nflags = 0; flags[i].flag; i++) {
		if (arg & flags[i].flag) {
			if (nflags != 0)
				utrace(utrrec, "|");
			utrace(utrrec, flags[i].name);
			nflags++;
		}
	}

	if (nflags == 0)
		utrace(utrrec, "<none>");

	utrace(utrrec, "\n");

	return 0;
}

/*** utrcltid() - add CLIENTID ***/

static int
#ifdef _TMPROTOTYPES
utrcltid(_utrrec *utrrec, long *clientdata)
#else
utrcltid(utrrec, cltid)
_utrrec *utrrec;
CLIENTID *cltid;
#endif
{
	int i;
	int n = 3;

	utrace(utrrec, "{");

	for (i = 0; i < n; i++) {
		if (i > 0)
			utrace(utrrec, ",");
		utrace(utrrec, "%ld", clientdata[i]);
	}

	utrace(utrrec, "}\n");

	return 0;
}

/*** utrsvcinfo() - add TPSVCINFO ***/

static int
#ifdef _TMPROTOTYPES
utrsvcinfo(_utrrec *utrrec, TPSVCINFO *svcinfo)
#else
utrsvcinfo(utrrec, svcinfo)
_utrrec *utrrec;
TPSVCINFO *svcinfo;
#endif
{
	utrace(utrrec, "(0x%lx){\n", svcinfo);
	utrace(utrrec, "name=\"%s\"\n", svcinfo->name);
	utrace(utrrec, "flags=");
	utrflags(utrrec, svc_flags, svcinfo->flags);
	utrace(utrrec, "data=");
	utrudata(utrrec, svcinfo->data, svcinfo->len, 1);
	utrace(utrrec, "cd=%d\n", svcinfo->cd);
	utrace(utrrec, "appkey=%ld\n", svcinfo->appkey);
	utrace(utrrec, "cltid=");
	utrcltid(utrrec, svcinfo->cltid.clientdata);
	utrace(utrrec, "}\n");

	return 0;
}

/*** utrtpqctl() - add TPQCTL ***/

static int
#ifdef _TMPROTOTYPES
utrtpqctl(_utrrec *utrrec, TPQCTL *tpqctl)
#else
utrtpqctl(utrrec, tpqctl)
_utrrec *utrrec;
TPQCTL *tpqctl;
#endif
{
	utrace(utrrec, "(0x%lx){\n", tpqctl);
	utrace(utrrec, "flags=");
	utrflags(utrrec, tpqctl_flags, tpqctl->flags);
	utrace(utrrec, "deq_time=%ld\n", tpqctl->deq_time);
	utrace(utrrec, "priority=%ld\n", tpqctl->priority);
	utrace(utrrec, "diagnostic=%ld\n", tpqctl->diagnostic);
	utrace(utrrec, "msgid=\"%s\"\n", tpqctl->msgid);
	utrace(utrrec, "corrid=\"%s\"\n", tpqctl->corrid);
	utrace(utrrec, "replyqueue=\"%s\"\n", tpqctl->replyqueue);
	utrace(utrrec, "failurequeue=\"%s\"\n", tpqctl->failurequeue);
	utrace(utrrec, "cltid=");
	utrcltid(utrrec, tpqctl->cltid.clientdata);
	utrace(utrrec, "urcode=%ld\n", tpqctl->urcode);
	utrace(utrrec, "appkey=%ld\n", tpqctl->appkey);
	utrace(utrrec, "delivery_qos=%ld\n", tpqctl->delivery_qos);
	utrace(utrrec, "reply_qos=%ld\n", tpqctl->reply_qos);
	utrace(utrrec, "exp_time=%ld\n", tpqctl->exp_time);
	utrace(utrrec, "}\n");

	return 0;
}

/*** utrcarray() - add carray data ***/

int
#ifdef _TMPROTOTYPES
utrcarray(_utrrec *utrrec, char *data, long len)
#else
utrcarray(utrrec, data, len)
_utrrec *utrrec;
char *data;
long len;
#endif
{
	/* truncate the data by UTRMAXLEN */
	long l;
	if (len > UTRMAXLEN) {
		for (l = 0; l < UTRMAXLEN; l++)
			utrace(utrrec, "%x", data[l]);
		utrace(utrrec, " ...\n");
	} else {
		for (l = 0; l < len; l++)
			utrace(utrrec, "%x", data[l]);
		utrace(utrrec, "\n");
	}

	return 0;
}

/*** utrstring() - add string data ***/

int
#ifdef _TMPROTOTYPES
utrstring(_utrrec *utrrec, char *data, long len)
#else
utrstring(utrrec, data, len)
_utrrec *utrrec;
char *data;
long len;
#endif
{
	/* truncate the data by UTRMAXLEN */
	if (len > UTRMAXLEN) {
		char *buf = malloc(UTRMAXLEN + 1);
		strncpy(buf, data, UTRMAXLEN);
		buf[UTRMAXLEN] = '\0';
		utrace(utrrec, "\"%s ...\"\n", buf);
		free(buf);
	} else {
		utrace(utrrec, "\"%s\"\n", data);
	}

	return 0;
}

/*** ulogutrace() - write utrace to the ULOG ***/

static int
#ifdef _TMPROTOTYPES
ulogutrace(_utrrec *utrrec, char *category)
#else
ulogutrace(utrrec, category)
_utrrec *utrrec;
char *category;
#endif
{
	char cat[3];
	char *buf, *p, *q;

	if (utrrec == NULL || utrrec->rec == NULL)
		return 0;

	strncpy(cat, category ? category : "??", 2);
	cat[2] = '\0';

	buf = malloc(utrrec->size);
	memcpy(buf, utrrec->rec, utrrec->size);

	for (p = buf; (q = strchr(p, '\n')) != NULL; p = q+1) {
		*q = '\0';
		userlog("%s:%s:%s", UTRPREFIX, cat, p);
	}

	free(buf);

	return 0;
}

/*** tputrace() - ***/

/*
 * Save the following data when entering a ATMI function so that
 * tputrace() called when returning the function can write the
 * contents of the data set by the function.
 */

typedef struct {
	char **odata;
	long *olen;
	long *revent;
	TPQCTL *tpqctl;
} _utrsavedata;

/* save data for each Tuxedo context */
/* adjust UTRMAXCTXT for your application */
static _utrsavedata savedatatbl[UTRMAXCTX];

static _utrsavedata *
getsavedata()
{
	TPCONTEXT_T context;
	int ctxtid = tpgetctxt(&context, 0);

	if (ctxtid >= UTRMAXCTX)
		return NULL;

	return &savedatatbl[ctxtid];
}

int
#ifdef _TMPROTOTYPES
_TMDLLENTRY
tputrace(char *trrec, int nest, char *category, char *funcname, int utrtype, va_list args)
#else
tputrace(trrec, nest, category, funcname, utrtype, args)
char *trrec;
int nest;
char *category;
char *funcname;
int utrtype;
va_list args;
#endif
{
	size_t initlen = 1024;
	_utrrec buf = {NULL, 0, {nest, 0}, 1};
	_utrrec *utrrec = &buf;
	int i, j;
	int ret;

	if (utrtype != utr_enter && utrtype != utr_leave)
		return 0;

	for (i = 0; _utrfuncs[i].name != NULL; i++) {
		if (strcmp(_utrfuncs[i].name, funcname) == 0 && _utrfuncs[i].type == utrtype)
			break;
	}

	if (_utrfuncs[i].name == NULL) {
		/* The function is not defined in _utrfuncs.       */
		/* Write the default TMTRACE record to the userlog */
#if 0
		(void) userlog(trrec);
#else
		/* replacing the "TRACE" prefix with UTRPREFIX    */
		(void) userlog("%s%s", UTRPREFIX, strchr(trrec, ':'));
#endif

		return 0;
	}

	utrace(utrrec, "%s %s(\n", utrtype == utr_enter ? "{" : "}", _utrfuncs[i].name);

	for (j = 0; _utrfuncs[i].args[j].type != arg_end; j++) {
		_argtype argtype = _utrfuncs[i].args[j].type;
		char *argname = _utrfuncs[i].args[j].name;

		if (argtype == arg_skip) {
			/* skip this arg */
			(void) va_arg(args, char *);
			continue;
		}

		if (argtype == arg_insert) {
			/* write the string specified in argname */
			utrace(utrrec, "%s\n", argname);
			continue;
		}

		utrace(utrrec, "%s=", argname);

		switch (argtype) {
		case arg_int:
			{
				int arg = va_arg(args, int);
				utrace(utrrec, "%d\n", arg);
			}
			break;
		case arg_intp:
			{
				int *argp = va_arg(args, int *);
				utrace(utrrec, "(0x%lx)%d\n", argp, *argp);
			}
			break;
		case arg_long:
			{
				long arg = va_arg(args, long);
				utrace(utrrec, "%ld\n", arg);
			}
			break;
		case arg_longp:
			{
				long *argp = va_arg(args, long *);
				utrace(utrrec, "(0x%lx)%ld\n", argp, *argp);
			}
			break;
		case arg_string:
			{
				char *arg = va_arg(args, char *);
				utrace(utrrec, "\"%s\"\n", arg);
			}
			break;
		case arg_idata:
			{
				char *idata = va_arg(args, char *);
				long len = va_arg(args, long);
				utrudata(utrrec, idata, len, 1);
			}
			break;
		case arg_odata:
			{
				char** odata = va_arg(args, char **);
				long *olen = va_arg(args, long *);
				_utrsavedata *savedata = getsavedata();

				utrodata(utrrec, odata, olen, utrtype);

				savedata->odata = odata;
				savedata->olen = olen;
			}
			break;
		case arg_ret:
			/* TMTRACE doesn't pass the odata when leaving the ATMI functions. */
			/* Get the odata from the saved address when entering the function. */
			{
				_utrsavedata *savedata = getsavedata();

				ret = va_arg(args, int);
				utrace(utrrec, "%d\n", ret);

				if (ret == -1) {
					utrace(utrrec, "tperrno=%s\n", tpstrerror(tperrno));

					/* for tprecv, revent is returned if tperrno==TPEEVENT */
					if (strcmp(funcname, "tprecv") == 0 && tperrno == TPEEVENT) {
							utrace(utrrec, "revent=(0x%lx)", savedata->revent);
							utrvalname(utrrec, revent_valname, *savedata->revent);
							switch (*savedata->revent) {
							case TPEV_SENDONLY:
							case TPEV_SVCFAIL:
							case TPEV_SVCSUCC:
								ret = 0; /* odata is available */
								break;
							case TPEV_DISCONIMM:
							case TPEV_SVCERR:
							default:
								break;
							}
					} else  if (strcmp(funcname, "tpdequeue") == 0 && tperrno == TPEDIAGNOSTIC) {
							utrace(utrrec, "tpqctl=");
							utrtpqctl(utrrec, savedata->tpqctl);
					}

				/* for tpdequeue, tpqctl is returned */
				} else {
					if (strcmp(funcname, "tpdequeue") == 0) {
						utrace(utrrec, "tpqctl=");
						utrtpqctl(utrrec, savedata->tpqctl);
					}
				}

				if (ret >= 0) {
					utrace(utrrec, "odata=");
					utrodata(utrrec, savedata->odata, savedata->olen, utrtype);
				}
			}
			break;
		case arg_cltid:
			{
				long clientdata[3];
				clientdata[0] = va_arg(args, long);
				clientdata[1] = va_arg(args, long);
				clientdata[2] = va_arg(args, long);
				utrcltid(utrrec, clientdata);
			}
			break;
		case arg_revent:
			{
				long *revent = va_arg(args, long *);
				_utrsavedata *savedata = getsavedata();

				utrace(utrrec, "(0x%lx)", revent);
				utrvalname(utrrec, revent_valname, *revent);

				savedata->revent = revent;
			}
			break;
		case arg_tpqctl:
			{
				TPQCTL *tpqctl = va_arg(args, TPQCTL *);
				_utrsavedata *savedata = getsavedata();

				utrtpqctl(utrrec, tpqctl);

				savedata->tpqctl = tpqctl;
			}
			break;
		case arg_svcinfo:
			{
				TPSVCINFO *svcinfo = va_arg(args, TPSVCINFO *);
				utrsvcinfo(utrrec, svcinfo);
			}
			break;
		case arg_rval:
			{
				int rval = va_arg(args, int);
				utrvalname(utrrec, rval_valname, rval);
			}
			break;
		case arg_svc_flags:
			{
				long flags = va_arg(args, long);
				utrflags(utrrec, svc_flags, flags);
			}
			break;
		default:
			utrace(utrrec, "unknown argtype\n");
			break;
		}
	}

	utrace(utrrec, ")\n");

	ulogutrace(utrrec, category);

	free(utrrec->rec);

	return 0;
}
