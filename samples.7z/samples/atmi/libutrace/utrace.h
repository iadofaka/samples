/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/libutrace/utrace.h	$Revision: 1.3 $" */

/***
 ***  You can modify the _utrfuncs[] definition below
 ***  to customize your TMUTRACE output.
 ***/

/* modify the following constants if necessary */

#define UTRMAXARG  10       /* max arguments for ATMI functions */
#define UTRBUFSIZ  1024     /* allocation unit for utrace record */
#define UTRMAXLEN  1024     /* max user data length */
#define UTRINDSIZ  2        /* indent size for utrace lines */
#define UTRMAXCTX  100      /* max contexts for _utrsavedata */
#define UTRPREFIX  "UTRACE" /* replaces "TRACE" in the default trace records */

/* _utrtype - utrace type */

typedef enum {
    utr_enter = 0, /* entering the function */
    utr_leave = 1, /* leaving the function */
    utr_other = -1
} _utrtype;

/* _arginfo - type and name of function argument */

typedef enum {
    arg_int,
    arg_intp,
    arg_long,
    arg_longp,
    arg_string,
    arg_idata,
    arg_odata,
    arg_tpinit,
    arg_cltid,
    arg_revent,
    arg_tpqctl,
    arg_svcinfo,
    arg_rval,
    arg_svc_flags,
    arg_ret,
    arg_skip, /* skip this arg */
    arg_insert, /* insert user defined string between args */
    arg_end
} _argtype;

typedef struct {
    _argtype type;
    char *name;
} _arginfo;

/* _funcinfo - utrace type and argument list for ATMI functions */

typedef struct {
    char *name;				/* ATMI function name */
    _utrtype type;			/* entering or leaving */
    _arginfo args[UTRMAXARG];	/* argument definitions */
} _funcinfo;

/* _utrfuncs - define functions handled by utrace */

static _funcinfo _utrfuncs[] = {
    {"tpcall", utr_enter, {
		{arg_string, "svc"},
		{arg_idata, "idata"},
		{arg_odata, "odata"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpcall", utr_leave, {
		{arg_ret, "ret"},
	/*
		{arg_odata, "odata"},
	*/
		{arg_end, NULL}}
    },
    {"tpacall", utr_enter, {
		{arg_string, "svc"},
		{arg_idata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpgetrply", utr_enter, {
		{arg_intp, "cd"},
		{arg_odata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpgetrply", utr_leave, {
		{arg_ret, "ret"},
/*
		{arg_odata, "odata"},
*/
		{arg_end, NULL}}
    },
    {"tpforward", utr_enter, {
		{arg_string, "svc"},
		{arg_idata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpbroadcast", utr_enter, {
		{arg_string, "lmid"},
		{arg_string, "usrname"},
		{arg_string, "cltname"},
		{arg_idata, "data"},
		{arg_end, NULL}}
    },
    {"tpnotify", utr_enter, {
		{arg_cltid, "clientid"},
		{arg_idata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpsend", utr_enter, {
		{arg_int, "cd"},
		{arg_idata, "data"},
		{arg_svc_flags, "flags"},
		{arg_revent, "revent"},
		{arg_end, NULL}}
    },
    {"tprecv", utr_enter, {
		{arg_int, "cd"},
		{arg_odata, "data"},
		{arg_svc_flags, "flags"},
		{arg_revent, "revent"},
		{arg_end, NULL}}
    },
    {"tprecv", utr_leave, {
		{arg_ret, "ret"},
/*
		{arg_revent, "revent"},
		{arg_odata, "data"},
*/
		{arg_end, NULL}}
    },
    {"tpconnect", utr_enter, {
		{arg_string, "svc"},
		{arg_idata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpenqueue", utr_enter, {
		{arg_string, "qspace"},
		{arg_string, "qname"},
		{arg_tpqctl, "ctl"},
		{arg_idata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpdequeue", utr_enter, {
		{arg_string, "qspace"},
		{arg_string, "qname"},
		{arg_tpqctl, "ctl"},
		{arg_odata, "data"},
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    {"tpdequeue", utr_leave, {
		{arg_ret, "ret"},
/*
		{arg_tpqctl, "ctl"},
		{arg_odata, "data"},
*/
		{arg_end, NULL}}
    },
    {"tpservice", utr_enter, {
		{arg_svcinfo, "svcinfo"},
		{arg_end, NULL}}
    },
    {"tpreturn", utr_enter, {
		{arg_rval, "rval"},
		{arg_long, "rcode"},
		{arg_idata, "data"}, 
		{arg_svc_flags, "flags"},
		{arg_end, NULL}}
    },
    /* terminator - do not delete */
    {NULL, utr_other, {
		{arg_end, NULL}}
    },
};

/* _utrrec - utrace record and related info */

typedef struct {
    char *rec;   /* utrace record */
    size_t size; /* allocated record size */
    int nest[2]; /* nesting level: 0=initial, 1=additional */
    int tol;     /* true if next data is at the top of the line */
} _utrrec;

/* external function definitions */

extern int utrace(_utrrec *utrrec, char *fmt, ...);
extern int utrfml(_utrrec *utrrec, char *data);
extern int utrfml32(_utrrec *utrrec, char *data);
extern int utrview(_utrrec *utrrec, char *vname, char *data);
extern int utrview32(_utrrec *utrrec, char *vname, char *data);
extern int utrcarray(_utrrec *utrrec, char *data, long len);
extern int utrstring(_utrrec *utrrec, char *data, long len);
