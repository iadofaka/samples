/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/libutrace/utrfml.c	$Revision: 1.4 $" */

#include <stdlib.h>
#include <string.h>
#include "atmi.h"
#ifdef UTRFML32
#include "fml32.h"
#include "fml1632.h"
#define utrfml utrfml32
#define utrview utrview32
#else
#include "fml.h"
#endif
#include "userlog.h"
#include "utrace.h"

/*** utrfldmbstr() - add MBSTRING field ***/

#ifdef UTRFML32
static int
#ifdef _TMPROTOTYPES
utrfldmbstr(_utrrec *utrrec, char *value, FLDLEN32 vlen)
#else
utrfldmbstr(utrrec, value, vlen)
_utrrec *utrrec;
char *value;
FLDLEN32 vlen;
#endif
{
	int ret;
	char enc[64];
	FLDLEN32 udsize = UTRBUFSIZ, udlen;
	char *udata = malloc(udsize);

	enc[0] = '\0';

retry_unpack:
	udlen = udsize;
	ret = Fmbunpack32(value, vlen, enc, udata, &udlen, 0);
	if (ret == -1) {
		switch (Ferror) {
		case FNOSPACE:
			udata = realloc(udata, udsize *= 2);
			goto retry_unpack;
		default:
			userlog("Fmbunpack32 failed: %s", Fstrerror32(Ferror32));
			free(udata);
			goto ret;
		}
	}

	udata[udlen] = '\0';
	if (enc[0] == '\0') /* FBUFENC */
		strcpy(enc, "<FBUFENC>");

	utrace(utrrec, "{\n");
	utrace(utrrec, "mbenc=\"%s\"\n", enc);
	utrace(utrrec, "value=");
	utrstring(utrrec, udata, udlen);
	utrace(utrrec, "}\n");

ret:
	free(udata);

	return ret;
}
#endif

/*** utrfml() - add FML data ***/

int
#ifdef _TMPROTOTYPES
utrfml(_utrrec *utrrec, char *data)
#else
utrfml(utrrec, data)
_utrrec *utrrec;
char *data;
#endif
{
	int ret = 0;
	FLDID fieldid = FIRSTFLDID;
	FLDOCC oc = 0;
	char *value;
	FLDLEN vlen;
	char *fieldname;

	utrace(utrrec, "{\n");

	while (1) {
		ret = Fnext((FBFR *)data, &fieldid, &oc, NULL, NULL);

		if (ret == 0)
			break;

		if (ret == -1) {
			userlog("Fnext failed: %s", Fstrerror(Ferror));
			goto ret;
		}

		value = Ffind((FBFR *) data, fieldid, oc, &vlen);

		if (value == NULL) {
			userlog("Ffind failed: %s", Fstrerror(Ferror));
			goto ret;
		}

		fieldname = Fname(fieldid);
		utrace(utrrec, "%s[%d]=", fieldname ? fieldname: "<unknown>", oc);

		switch (Fldtype(fieldid)) {
		case FLD_SHORT:
			utrace(utrrec, "%d\n", *((short*)value));
			break;
		case FLD_LONG:
			utrace(utrrec, "%ld\n", *((long*)value));
			break;
		case FLD_FLOAT:
			utrace(utrrec, "%f\n", *((float*)value));
			break;
		case FLD_DOUBLE:
			utrace(utrrec, "%lf\n", *((double*)value));
			break;
		case FLD_CHAR:
			utrace(utrrec, "%c\n", *value);
			break;
		case FLD_STRING:
			utrstring(utrrec, value, vlen);
			break;
		case FLD_CARRAY:
			utrcarray(utrrec, value, vlen);
			break;
#ifdef UTRFML32
		case FLD_PTR:
			utrace(utrrec, "<FLD_PTR type: TODO>\n");
			break;
		case FLD_FML32:
			utrfml32(utrrec, value);
			break;
		case FLD_VIEW32:
		{
			FVIEWFLD *fvfp = (FVIEWFLD *)value;
			utrview32(utrrec, fvfp->vname, fvfp->data);
			break;
		}
		case FLD_MBSTRING:
			utrfldmbstr(utrrec, value, vlen);
			break;
#endif
		default:
			break;
		}
	}

ret:
	utrace(utrrec, "}\n");

	return ret;
}

/*** utrview() - add VIEW data ***/

int
#ifdef _TMPROTOTYPES
utrview(_utrrec *utrrec, char *vname, char *data)
#else
utrview(utrrec, vname, data)
_utrrec *utrrec;
char *vname;
char *data;
#endif
{
	int ret = 0;
	long fdsize = UTRBUFSIZ;
	char* fmldata = tpalloc(FMLTYPE, NULL, fdsize);
	char type[9], subtype[17];

	type[8] = subtype[16] = '\0';
	if (vname != NULL)
		strcpy(subtype, vname);
	else
		tptypes(data, type, subtype);

retry_stof:
	ret = Fvstof((FBFR *) fmldata, data, FUPDATE, subtype);
	if (ret == -1) {
		switch (Ferror) {
		case FNOSPACE:
			fmldata = tprealloc(fmldata, fdsize *= 2);
			goto retry_stof;
		default:
			userlog("Fvstof failed: %s", Fstrerror32(Ferror32));
			goto ret;
		}
	}

	utrfml(utrrec, (char *) fmldata);

ret:
	tpfree(fmldata);

	return ret;
}
