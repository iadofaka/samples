/*	(c) 2003 BEA Systems, Inc. All Rights Reserved. */
/*	Copyright (c) 1997 BEA Systems, Inc.
  	All rights reserved

  	THIS IS UNPUBLISHED PROPRIETARY
  	SOURCE CODE OF BEA Systems, Inc.
  	The copyright notice above does not
  	evidence any actual or intended
  	publication of such source code.
*/

#	Copyright (c) 1990, 1994 Novell, Inc.
#	Copyright (c) 1994 Novell
#	  All Rights Reserved

#	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
#	UNIX System Laboratories, Inc.
#	The copyright notice above does not evidence any
#	actual or intended publication of such source code.

#Copyright (c) 1994 Novell, Inc.
#All rights reserved
#ident	"@(#) samples/atmi/creditapp/crdt_flds.h	$Revision: 1.5 $"

/*	fname	fldid            */
/*	-----	-----            */
#define	C_ACCOUNT_ID	((FLDID)8502)	/* number: 310	 type: long */
#define	C_CRT_LINE	((FLDID)24887)	/* number: 311	 type: float */
#define	C_BALANCE	((FLDID)24888)	/* number: 312	 type: float */
#define	C_ACCT_TYPE	((FLDID)16703)	/* number: 319	 type: char */
#define	C_XA_TYPE	((FLDID)320)	/* number: 320	 type: short */
#define	C_CURS	((FLDID)41281)	/* number: 321	 type: string */
#define	C_AMOUNT	((FLDID)41282)	/* number: 322	 type: string */
#define	C_BAMOUNT	((FLDID)41283)	/* number: 323	 type: string */
#define	C_CAMOUNT	((FLDID)41284)	/* number: 324	 type: string */
