#	(c) 2003 BEA Systems, Inc. All Rights Reserved.
#ident	"@(#) samples/atmi/bankapp/run.sh	$Revision: 1.6 $"
#
bankclt
