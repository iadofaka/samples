/*	(c) 2003 BEA Systems, Inc. All Rights Reserved. */
/*	Copyright (c) 1997 BEA Systems, Inc.
  	All rights reserved

  	THIS IS UNPUBLISHED PROPRIETARY
  	SOURCE CODE OF BEA Systems, Inc.
  	The copyright notice above does not
  	evidence any actual or intended
  	publication of such source code.
*/

/*
 *	Copyright (c) 1995, 1996 BEA Systems, Inc.
 *	All Rights Reserved
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
 *	BEA Systems, Inc.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 */

/* #ident	"@(#) samples/atmi/bankapp/nt/client/bankapp.h	$Revision: 1.4 $" */

#define  IDC_ACCOUNT1		200
#define  IDC_ACCOUNT2		201
#define  IDC_AMOUNT		202
#define  IDC_LASTNAME		203
#define  IDC_FIRSTNAME		204
#define  IDC_MIDNAME		205
#define  IDC_PHONE		206
#define  IDC_STREET		207
#define  IDC_CITYSTATE		208
#define  IDC_SOCSEC		209
#define  IDC_ACCOUNTTYPE1	210
#define  IDC_ACCOUNTTYPE2	211
#define  IDC_BRANCH1		212
#define  IDC_BRANCH2		213
#define  IDC_BRANCH3		214
#define  IDC_BRANCH4		215
#define  IDC_BRANCH5		216
#define  IDC_BRANCH6		217
#define  IDC_BRANCH7		218
#define  IDC_BRANCH8		219
#define  IDC_BRANCH9		220
#define  IDC_BRANCH10		230

#define  IDM_DEPOSIT		150
#define  IDM_WITHDRAWAL		151
#define  IDM_TRANSFER		152
#define  IDM_BALANCE		153
#define  IDM_OPEN		154
#define  IDM_CLOSE		155
#define  IDM_HELP		156

#define  ID_MENUICON		357
#define  IDD_DEPOSIT		300
#define  IDD_WITHDRAW		301
#define  IDD_TRANSFER		302
#define  IDD_BALANCE		303
#define  IDD_OPEN		304
#define  IDD_CLOSE		305

#define IDD_USER                1500
#define IDC_USER                1501
#define IDC_PASSWD              1502
