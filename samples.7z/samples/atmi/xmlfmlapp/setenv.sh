#	Copyright (c) 2005 BEA Systems, Inc.
#	All rights reserved
#
#	THIS IS UNPUBLISHED PROPRIETARY
#	SOURCE CODE OF BEA Systems, Inc.
#	The copyright notice above does not
#	evidence any actual or intended
#	publication of such source code.
export TUXCONFIG=<Replace with your TUXCONFIG Pathname>
export TUXDIR=<Replace with your TUXEDO Pathname>
export FLDTBLDIR32=<Replace with your xmlfmlapp sample Pathname>
export FIELDTBLS32=stockflds
export TPXPARSFILE=stock_validate.par
