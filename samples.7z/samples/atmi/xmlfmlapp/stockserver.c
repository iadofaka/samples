/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/xmlfmlapp/stockserv.c	$Revision: 1.3.40.1 $" */

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <atmi.h>
#include <userlog.h>
#include <fml32.h>
#include "stockflds.h"

#define XMLMAXSIZE 4096

/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/

#if defined(__STDC__) || defined(__cplusplus)
tpsvrinit(int argc, char *argv[])
#else
tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */
	argc = argc;
	argv = argv;

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the stock server");
	return(0);
}

/* This function performs the actual service requested by the client.
   Its argument is a structure containing among other things a pointer
   to the data buffer, and the length of the data buffer.
*/

#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
QUERY(TPSVCINFO *rqst)
#else
QUERY(rqst)
TPSVCINFO *rqst;
#endif
{
	char *xmlbuf, *fmlbuf;
	char *requestfml;
	char *subfml;
	char *stock_name;
	char *fldname;
	FILE *stock_data;
	FLDID32 fieldid = FIRSTFLDID;
	FLDID32 lastfieldid = FIRSTFLDID;
	FLDOCC32 oc;
	FLDLEN32 len = 0;
	int fmlrc, rc;
	long stock_amount = 0;
	float stock_price = 0;

	if((xmlbuf = (char *) tpalloc("XML", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating send buffer\n");
		exit(1);
	}

	if((fmlbuf = (char *) tpalloc("FML32", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating receive buffer\n");
		tpfree(xmlbuf);
		exit(1);
	}

	memset(xmlbuf, 0x0, XMLMAXSIZE);
	if ((stock_data = fopen("stock.xml", "rt")) != NULL) {
		fread(xmlbuf, sizeof(char), XMLMAXSIZE, stock_data);
		fclose(stock_data);
	}
	else {
		userlog("Can not find stock data file: stock.xml");
	}

	rc = tpxmltofml32(xmlbuf, NULL, (FBFR32 **) &fmlbuf, NULL, 0);
	if(rc == -1) {
		userlog("Error convert stock data from XML to FML32");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	requestfml = rqst->data;
	stock_name = Fgetalloc32((FBFR32 *)requestfml, Fldid32("stockname"), 0, &len);
	if ((stock_name == NULL) || (strlen(stock_name) == 0)) {
		userlog("Error get request data");
		if(stock_name)
			free(stock_name);
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	do {
		fmlrc = Fnext32((FBFR32 *) fmlbuf, &fieldid, &oc, NULL, NULL);
		if (fmlrc < 0) {
			userlog("Error get stock data");
			free(stock_name);
			tpfree(xmlbuf);
			tpfree(fmlbuf);
			tpreturn(TPFAIL, -1, NULL, 0, 0);
		}		
		else if (fmlrc == 0) {
			break;
		}
		else {
			if ( fieldid == Fldid32("stockquote") ) {
				subfml = Fgetalloc32((FBFR32 *)fmlbuf, fieldid, oc, &len);
				if (subfml) {
					if (fldname = Fgetalloc32((FBFR32 *)subfml, Fldid32("stockname"), 0, &len)) {
						if (strncmp(fldname, stock_name, len) == 0) {
							if (Fget32((FBFR32 *)subfml, Fldid32("stockprice"), 0, (char *) &stock_price, NULL) == -1) {
								userlog("Error get data");
								free(subfml);
								free(fldname);
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							if (Fget32((FBFR32 *)subfml, Fldid32("stockamount"), 0, (char *) &stock_amount, NULL) == -1) {
								userlog("Error get data");
								free(subfml);
								free(fldname);
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							free(subfml);
							free(fldname);
							break;
						}
						free(fldname);
					}
					free(subfml);
				}
			}
		}
		lastfieldid = fieldid;
	} while(1);

	Fchg32((FBFR32 *) requestfml, Fldid32("stockprice"), 0, (char *) &stock_price, (FLDLEN32)0);
	Fchg32((FBFR32 *) requestfml, Fldid32("stockamount"), 0, (char *) &stock_amount, (FLDLEN32)0);

	/* Return the transformed buffer to the requestor. */
	free(stock_name);
	tpfree(xmlbuf);
	tpfree(fmlbuf);
	tpreturn(TPSUCCESS, 0, rqst->data, rqst->len, 0);
}

#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
BUY(TPSVCINFO *rqst)
#else
BUY(rqst)
TPSVCINFO *rqst;
#endif
{
	char *xmlbuf, *fmlbuf;
	char *requestfml;
	char *subfml;
	char *stock_name;
	char *fldname;
	FILE *stock_data;
	FLDID32 fieldid = FIRSTFLDID;
	FLDID32 lastfieldid = FIRSTFLDID;
	FLDOCC32 oc;
	FLDLEN32 len = 0;
	int fmlrc, rc;
	long stock_amount = 0;
	float stock_price = 0;
	long buy_amount=0;

	if((xmlbuf = (char *) tpalloc("XML", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating send buffer\n");
		exit(1);
	}

	if((fmlbuf = (char *) tpalloc("FML32", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating receive buffer\n");
		tpfree(xmlbuf);
		exit(1);
	}

	memset(xmlbuf, 0x0, XMLMAXSIZE);
	if ((stock_data = fopen("stock.xml", "rt")) != NULL) {
		fread(xmlbuf, sizeof(char), XMLMAXSIZE, stock_data);
		fclose(stock_data);
	}
	else {
		userlog("Can not find stock data file: stock.xml");
	}

	rc = tpxmltofml32(xmlbuf, NULL, (FBFR32 **) &fmlbuf, NULL, 0);
	if(rc == -1) {
		userlog("Error convert stock data from XML to FML32");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	requestfml = rqst->data;
	stock_name = Fgetalloc32((FBFR32 *)requestfml, Fldid32("stockname"), 0, &len);
	if ((stock_name == NULL) || (strlen(stock_name) == 0)) {
		userlog("Error get request data");
		if(stock_name)
			free(stock_name);
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}
	if (Fget32((FBFR32 *)requestfml, Fldid32("stockamount"), 0, (char *) &buy_amount, NULL) == -1) {
		userlog("Error get request data");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	do {
		fmlrc = Fnext32((FBFR32 *) fmlbuf, &fieldid, &oc, NULL, NULL);
		if (fmlrc < 0) {
			userlog("Error get stock data");
			tpfree(xmlbuf);
			tpfree(fmlbuf);
			tpreturn(TPFAIL, -1, NULL, 0, 0);
		}		
		else if (fmlrc == 0) {
			break;
		}
		else {
			if ( fieldid == Fldid32("stockquote") ) {
				subfml = Fgetalloc32((FBFR32 *)fmlbuf, fieldid, oc, &len);
				if (subfml) {
					if (fldname = Fgetalloc32((FBFR32 *)subfml, Fldid32("stockname"), 0, &len)) {
						if (strncmp(fldname, stock_name, len) == 0) {
							if (Fget32((FBFR32 *)subfml, Fldid32("stockprice"), 0, (char *) &stock_price, NULL) == -1) {
								userlog("Error get data");
								free(subfml);
								free(fldname);
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							if (Fget32((FBFR32 *)subfml, Fldid32("stockamount"), 0, (char *) &stock_amount, NULL) == -1) {
								userlog("Error get data");
								free(subfml);
								free(fldname);
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							free(subfml);
							free(fldname);
							stock_amount += buy_amount;
							break;
						}
						free(fldname);
					}
					free(subfml);
				}
			}
		}
		lastfieldid = fieldid;
	} while(1);

	Fchg32((FBFR32 *) requestfml, Fldid32("stockprice"), 0, (char *) &stock_price, (FLDLEN32)0);
	Fchg32((FBFR32 *) requestfml, Fldid32("stockamount"), 0, (char *) &stock_amount, (FLDLEN32)0);

	/* Return the transformed buffer to the requestor. */
	free(stock_name);
	tpfree(xmlbuf);
	tpfree(fmlbuf);
	tpreturn(TPSUCCESS, 0, rqst->data, rqst->len, 0);
/*
	char *xmlbuf, *fmlbuf;
	char *requestfml;
	char *subfml;
	char *stock_name;
	char *fldname;
	char *tmpval;
	FILE *stock_data;
	FLDID32 fieldid = FIRSTFLDID;
	FLDID32 lastfieldid = FIRSTFLDID;
	FLDOCC32 oc;
	FLDLEN32 len = 0;
	int fmlrc, rc;
	long stock_amount = 0;
	float stock_price = 0;
	long buy_amount=0;

	if((xmlbuf = (char *) tpalloc("XML", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating send buffer\n");
		exit(1);
	}

	if((fmlbuf = (char *) tpalloc("FML32", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating receive buffer\n");
		tpfree(xmlbuf);
		exit(1);
	}

	memset(xmlbuf, NULL, XMLMAXSIZE);
	if ((stock_data = fopen("stock.xml", "rt")) != NULL) {
		fread(xmlbuf, sizeof(char), XMLMAXSIZE, stock_data);
		fclose(stock_data);
	}
	else {
		userlog("Can not find stock data file: stock.xml");
	}

	rc = tpxmltofml32(xmlbuf, NULL, (FBFR32 **) &fmlbuf, NULL, 0);
	if(rc == -1) {
		userlog("Error convert stock data from XML to FML32");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	requestfml = rqst->data;
	stock_name = Fgetalloc32((FBFR32 *)requestfml, Fldid32("stockname"), 0, &len);
	if ((stock_name == NULL) || (strlen(stock_name) == 0)) {
		userlog("Error get request data");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}
	tmpval = Fgetalloc32((FBFR32 *)requestfml, Fldid32("stockamount"), 0, &len);
	buy_amount = * (long *) tmpval;

	do {
		fmlrc = Fnext32((FBFR32 *) fmlbuf, &fieldid, &oc, NULL, NULL);
		if (fmlrc < 0) {
			userlog("Error get stock data");
			tpfree(xmlbuf);
			tpfree(fmlbuf);
			tpreturn(TPFAIL, -1, NULL, 0, 0);
		}		
		else if (fmlrc == 0) {
			break;
		}
		else {
			if ( fieldid == Fldid32("stockquote") ) {
				subfml = Fgetalloc32((FBFR32 *)fmlbuf, fieldid, oc, &len);
				if (subfml) {
					if (fldname = Fgetalloc32((FBFR32 *)subfml, Fldid32("stockname"), 0, &len)) {
						if (strncmp(fldname, stock_name, len) == 0) {
							tmpval = Fgetalloc32((FBFR32 *)subfml, Fldid32("stockprice"), 0, &len);
							stock_price = * (float *) tmpval;
							tmpval = Fgetalloc32((FBFR32 *)subfml, Fldid32("stockamount"), 0, &len);
							stock_amount = * (long *) tmpval;
							free(subfml);
							stock_amount += buy_amount;
							break;
						}
					}
					free(subfml);
				}
			}
		}
		lastfieldid = fieldid;
	} while(1);

	Fchg32((FBFR32 *) requestfml, Fldid32("stockprice"), 0, (char *) &stock_price, (FLDLEN32)0);
	Fchg32((FBFR32 *) requestfml, Fldid32("stockamount"), 0, (char *) &stock_amount, (FLDLEN32)0);

	tpfree(xmlbuf);
	tpfree(fmlbuf);
	tpreturn(TPSUCCESS, 0, rqst->data, rqst->len, 0);
*/
}


#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
SELL(TPSVCINFO *rqst)
#else
SELL(rqst)
TPSVCINFO *rqst;
#endif
{
	char *xmlbuf, *fmlbuf;
	char *requestfml;
	char *subfml;
	char *stock_name;
	char *fldname;
	FILE *stock_data;
	FLDID32 fieldid = FIRSTFLDID;
	FLDID32 lastfieldid = FIRSTFLDID;
	FLDOCC32 oc;
	FLDLEN32 len = 0;
	int fmlrc, rc;
	long stock_amount=0;
	float stock_price=0;
	long sell_amount=0;

	if((xmlbuf = (char *) tpalloc("XML", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating send buffer\n");
		exit(1);
	}

	if((fmlbuf = (char *) tpalloc("FML32", NULL, XMLMAXSIZE)) == NULL) {
		(void) fprintf(stderr,"Error allocating receive buffer\n");
		tpfree(xmlbuf);
		exit(1);
	}

	memset(xmlbuf, 0x0, XMLMAXSIZE);
	if ((stock_data = fopen("stock.xml", "rt")) != NULL) {
		fread(xmlbuf, sizeof(char), XMLMAXSIZE, stock_data);
		fclose(stock_data);
	}
	else {
		userlog("Can not find stock data file: stock.xml");
	}

	rc = tpxmltofml32(xmlbuf, NULL, (FBFR32 **) &fmlbuf, NULL, 0);
	if(rc == -1) {
		userlog("Error convert stock data from XML to FML32");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	requestfml = rqst->data;
	stock_name = Fgetalloc32((FBFR32 *)requestfml, Fldid32("stockname"), 0, &len);
	if ((stock_name == NULL) || (strlen(stock_name) == 0)) {
		userlog("Error get request data");
		if(stock_name)
			free(stock_name);
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	if (Fget32((FBFR32 *)requestfml, Fldid32("stockamount"), 0, (char *) &sell_amount, NULL) == -1) {
		userlog("Error get request data");
		tpfree(xmlbuf);
		tpfree(fmlbuf);
		tpreturn(TPFAIL, -1, NULL, 0, 0);
	}

	do {
		fmlrc = Fnext32((FBFR32 *) fmlbuf, &fieldid, &oc, NULL, NULL);
		if (fmlrc < 0) {
			userlog("Error get stock data");
			tpfree(xmlbuf);
			tpfree(fmlbuf);
			tpreturn(TPFAIL, -1, NULL, 0, 0);
		}		
		else if (fmlrc == 0) {
			break;
		}
		else {
			if ( fieldid == Fldid32("stockquote") ) {
				subfml = Fgetalloc32((FBFR32 *)fmlbuf, fieldid, oc, &len);
				if (subfml) {
					if (fldname = Fgetalloc32((FBFR32 *)subfml, Fldid32("stockname"), 0, &len)) {
						if (strncmp(fldname, stock_name, len) == 0) {
							if (Fget32((FBFR32 *)subfml, Fldid32("stockprice"), 0, (char *) &stock_price, NULL) == -1) {
								userlog("Error get data");
								free(fldname);
								free(subfml);
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							if (Fget32((FBFR32 *)subfml, Fldid32("stockamount"), 0, (char *) &stock_amount, NULL) == -1) {
								userlog("Error get data");
								free(fldname);
								free(subfml);
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							free(subfml);
							free(fldname);
							if (stock_amount < sell_amount) {
								userlog("Can not sell too much.");
								free(stock_name);
								tpfree(xmlbuf);
								tpfree(fmlbuf);
								tpreturn(TPFAIL, -1, NULL, 0, 0);
							}
							else {
								stock_amount -= sell_amount;
							}
							break;
						}
						free(fldname);
					}
					free(subfml);
				}
			}
		}
		lastfieldid = fieldid;
	} while(1);

	Fchg32((FBFR32 *) requestfml, Fldid32("stockprice"), 0, (char *) &stock_price, (FLDLEN32)0);
	Fchg32((FBFR32 *) requestfml, Fldid32("stockamount"), 0, (char *) &stock_amount, (FLDLEN32)0);

	/* Return the transformed buffer to the requestor. */
	free(stock_name);
	tpfree(xmlbuf);
	tpfree(fmlbuf);
	tpreturn(TPSUCCESS, 0, rqst->data, rqst->len, 0);
}

