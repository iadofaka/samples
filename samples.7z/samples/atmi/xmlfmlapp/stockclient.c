/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/xmlfmlapp/stockclient.c	$Revision: 1.4.40.1 $" */

#include <string.h>
#include <stdio.h>
#include <atmi.h>		/* TUXEDO  Header File */
#include <fml32.h>
#include "stockflds.h"

#define XMLMAXSIZE 4096

#if defined(__STDC__) || defined(__cplusplus)
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif

{
        char *sendbuf, *rcvbuf;
		char *fmlbuf;
        long sendlen, rcvlen;
        long flags;
        int  ret;
        char type[8], subtype[16];
        FILE *xml_fd;
        char xml_file[256];
        char *xml_buffer = NULL;
		char *tmpval;
        int  nsize;
		FLDLEN32 len = 0;

        if(argc != 2) {
                fprintf(stderr, "Usage: %s <XML doc>\n", argv[0]);
                return(1);
        }

		if((fmlbuf = (char *) tpalloc((char *)"FML32", NULL, XMLMAXSIZE)) == NULL) {
			(void) fprintf(stderr,"Error allocating receive buffer\n");
			tpfree(fmlbuf);
			exit(1);
		}

        /* Read the XML document in first */
        (void)strcpy(xml_file, argv[1]);

        if ((xml_fd = fopen(xml_file, "rt")) != NULL) {
			xml_buffer = (char *)malloc(sizeof(char) * XMLMAXSIZE);
			nsize = fread(xml_buffer, sizeof(char), XMLMAXSIZE, xml_fd);
			fclose(xml_fd);
        }
	else {
		(void) fprintf(stderr, "File %s open failed.\n", xml_file);
			tpfree(fmlbuf);
			return(1);
	}

        /* Attach to System/T as a Client Process */
        if (tpinit((TPINIT *) NULL) == -1) {
                (void) fprintf(stderr, "Tpinit failed\n");
				tpfree(fmlbuf);
                return(1);
        } 

        sendlen = nsize + 100;
        if((sendbuf = (char *) tpalloc((char *)"XML", NULL, sendlen)) == NULL) {
                fprintf(stderr,"Error allocating send buffer, tperrno=%ld\n",tperrno);
				tpfree(fmlbuf);
                tpterm();
                return(1);
        }

	memset(sendbuf, 0 , sendlen);

        if((rcvbuf = (char *) tpalloc((char *)"XML", NULL, sendlen+1)) == NULL) {
                fprintf(stderr,"Error allocating receive buffer, tperrno=%ld\n",tperrno);
                tpfree(sendbuf);
				tpfree(fmlbuf);
				tpterm();
                return(1);
        }
	memset(rcvbuf, 0, sendlen+1);

        strncpy(sendbuf, xml_buffer, nsize);

		ret = tpxmltofml32(sendbuf, NULL, (FBFR32 **) &fmlbuf, NULL, 0);
		if(ret == -1) {
			fprintf(stderr, "Error convert stock data from XML to FML32\n");
            tpfree(sendbuf);
            tpfree(rcvbuf);
            tpfree(fmlbuf);
            tpterm();
            return(1);
 		}
		tmpval = Fgetalloc32((FBFR32 *)fmlbuf, Fldid32("operator"), 0, &len);

		flags = TPNOTIME;
		fprintf(stdout, "send data:\n%s\n", sendbuf);
        ret = tpcall(tmpval, (char *)sendbuf, nsize, (char **)&rcvbuf,  
                       &rcvlen, (long)flags);


        if(ret == -1) {
                fprintf(stderr, "Can't send request to service %s\n", tmpval);
                fprintf(stderr, "Tperrno = %d\n", tperrno);
		free(tmpval);
                tpfree(sendbuf);
                tpfree(rcvbuf);
	            tpfree(fmlbuf);
                tpterm();
                return(1);
        }
	else {
		fprintf(stdout, "return data:\n%s\n", rcvbuf);
	}

    /* Free Buffers & Detach from System/T */
    free(tmpval);
    tpfree(sendbuf);
    tpfree(rcvbuf);
    tpfree(fmlbuf);
    tpterm();         
	return(0);
}
