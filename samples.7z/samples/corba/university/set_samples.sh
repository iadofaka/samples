#! /bin/csh -f
#	(c) 2003 BEA Systems, Inc. All Rights Reserved.

#
# Set PATH for C and C++ compiler by the location
#
if ( -d /opt/SUNWspro/bin ) then
    setenv PATH /opt/SUNWspro/bin:${PATH}
else
    if ( -d /usr/opt/SUNWspro/bin ) then
	setenv PATH /usr/opt/SUNWspro/bin:${PATH}
    else
	if ( -d /usr/vacpp/bin ) then
	    setenv PATH /usr/vacpp/bin:${PATH}
	endif
    endif
endif

if ( -d /usr/openwin/bin ) then
    setenv /usr/openwin/bin:${PATH}
endif

#
# Set TUXDIR and ORACLE_HOME
#
setenv TUXDIR /usr/local/tuxdir
setenv ORACLE_HOME /usr/local/oracle

#
# If JARTYPE is defined, it is for Java2 (aka JDK1.2)
# If JDKDIR is different, set it appropriately later.
#
if ( ! $?JARTYPE ) then
    setenv JDKDIR /usr/local/jdk
    unsetenv JDKDIR_1_2
else
    setenv JDKDIR /usr/local/jdk1.2
    setenv JDKDIR_1_2 $JDKDIR
endif

echo ""
echo "********************************"
echo ""
echo "     TUXDIR: $TUXDIR"
echo "ORACLE_HOME: $ORACLE_HOME"
#echo $ORACLE_SID
echo "     JDKDIR: $JDKDIR"
#echo $JDKDIR_1_2
#
echo ""
echo "********************************"
#
ls /usr/local/oracle/bin/proc >& /dev/null
if ( $status != 0 ) then
    echo ""
    echo "    You need proc for samples..."
    echo "
else
    echo ""
    echo "    ProC is installed"
    echo ""
endif
#
ps -fu oracle | grep ora_smon_ >& /dev/null
if ( $status != 0 ) then
    echo ""
    echo "    You need Oracle process running..."
    echo ""
else
    echo ""
    echo "    Oracle process is running"
    echo ""
endif
echo "*********************************"
#
echo ""
echo "These accounts are logged into the system"
echo ""
finger
echo ""
echo ""
