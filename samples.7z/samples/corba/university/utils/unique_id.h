/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/
//--------------------------------------------------------------------
//
// unique_id.h
//
// C++ UniqueId class header for the university sample application
//
// BEA Systems Inc. sample code
//
//--------------------------------------------------------------------

#ifndef __UNIQUE_ID_H__
#define __UNIQUE_ID_H__

#if defined(WIN32) && (_MSC_VER >= 1300)
#include <iostream>
using namespace std;
#else
#include <iostream.h>
#endif

class UniqueIdInternals;

class UniqueId
{
public:
    static UniqueId generate();
    UniqueId();
    UniqueId(const UniqueId&);
    UniqueId& operator=(const UniqueId& rhs);
    ~UniqueId();
    int operator==(const UniqueId& rhs) const;
    int operator!=(const UniqueId& rhs) const
    {
        return !(*this == rhs);
    }
    int hash() const;
private:
    UniqueIdInternals* m_internals;
friend ostream& operator<<(ostream&, const UniqueId&);
friend istream& operator>>(istream&, UniqueId&);
};

extern ostream& operator<<(ostream&, const UniqueId&);
extern istream& operator>>(istream&, UniqueId&);

#endif // __UNIQUE_ID_H__

