#	(c) 2003 BEA Systems, Inc. All Rights Reserved.
1) Unless specifically indicated, references to any documentation
   point to the 'BEA Tuxedo Guide to the Samples Applications'. Read
   Chapter 2 'Setting up your environment' carefully while
   preparing to build and run the university samples.

2) The Oracle_XA string in the $TUXDIR/udataobj/RM file is platform
   specific. It needs to be modified to match the sample RM file for
   your platform as described in the section dealing with the
   'buildobjserver' command in
   Chapter 9 'Development and Administration Commands' of the
   'BEA Tuxedo Programming Reference Guide'.

   A %TUXDIR%\samples\corba\university\utils\RM_nt file has been
   provided. It must be copied to %TUXDIR%\udataobj\RM to build the
   samples on Windows NT with Oracle 7.3.3.

3) Prior to running the setenv scripts on Windows NT, you must set
   the Visual C++ environment variables by running
   C:\Progra~1\DevStudio\Vc\Bin\VcVars32.bat. Ensure that MSVCDIR
   specifies directory names properly as the Oracle Pro*C/C++
   compiler supports DOS 8.3 naming style.

4) By default, the Java client in these samples use the Netscape
   ORB and corresponding jar files. However on Solaris and
   Windows NT Intel, the samples will support the JAVA JDK ORB V1.2
   additionally when JDK V1.2 is released.

   On Solaris and Windows NT Intel, the JARTYPE environment variable
   must be set to 'JDK' or 'jdk', so that the Java client uses the
   JAVA JDK ORB V1.2 instead of the ORB embedded in Netscape SuiteSpot.

5) It is recommended that you execute 'tmshutdown -y' before proceeding
   to work on the next sample. This will shutdown all servers and
   release resources that will be required for the next sample.

6) Trouble Shooting Tips

   For Oracle database or transaction errors, the information
   available in the ULOG file may be a little coarse. For further
   details on the problem, refer to the sqlnet.log or
   xa_<Oracle_Instance><Date>.trc files.

   The following is a list of common errors a user may encounter while
   running the University samples. Troubleshooting tips point to the
   relevant sections of 'BEA Tuxedo Guide to the Samples Applications'.

   a) If the xa_*.trc file reports

      ORA-00604: error occurred at recursive SQL level
      ORA-00604: error occurred at recursive SQL level 1
      ORA-00018: maximum number of sessions exceeded

      contact your Oracle Database Administrator to have the 'sessions'
      parameter in the %ORACLE_HOME%\Database\Init<Instance>.ora file
      raised. The typical value for this parameter is

      sessions = 128


   b) If either the ULOG or sqlnet.log contains

      SQL*Plus: Release 3.3.3.0.0 - Production on Fri May 01 09:52:55
      Copyright(c) Oracle Corporation 1979, 1996. All rights reserved.

      ERROR: ORA-01034: ORACLE not available
      ORA-09243: smsget: error attaching to SGA
      OSD-04101: invalid SGA: SGA not initialized
      O/S-Error: (OS 203) The system could not find the environment
      option that was entered.

      you will need to start the OracleService (or Instance). Refer to
      the 'Starting the Daemon for the Oracle Database' section in
      Chapter 2 'Setting up your environment'.


   c) To be able to run the transactions, wrapper and production
      samples, XA must be enabled to work between TUXEDO & Oracle. If
      XA is not enabled, the tmboot of these samples will fail with
      the following messages in the ULOG file.
   
      <ID>.<Hostname>+ACE-TMS+AF8-ORA.289: LIBTUX+AF8-CAT:262:
         INFO: Standard main starting
      <ID>.<Hostname>+ACE-TMS+AF8-ORA.289: CMDTUX+AF8-CAT:409:
         ERROR: xa+AF8-recover() returned -3 for group ORA+AF8-GRP
      <ID>.<Hostname>+ACE-TMS+AF8-ORA.289: LIBTUX+AF8-CAT:250:
         ERROR: tpsvrinit() failed

      For help to enable XA, refer to the 'Enabling an XA Resource
      Manager' section in Chapter 2 'Setting up your environment'.

      When you run $ORACLE_HOME/rdbms/admin/xaview.sql, you may
      see errors of the form
      'ORA-00942: table or view does not exist'. These errors are
      expected (may be ignored) if you execute the script for the
      first time.


   d) To be able to run the transactions, wrapper and production
      samples, you will need to initialize a TLOGDEVICE (as specified
      in the ubb configuration file). Failure to perform this as per the
      'Creating the Transactions Log' section in Chapter 5
      'Building the Transactions Tuxedo University Sample Applications'
      will result in the tmboot failing with the following messages in
      the ULOG.

      <ID>.<Hostname>!tmboot.2121:
           WARN: No BBL available on site SITE1.
   	Will not attempt to boot server processes on that site.
      <ID>.<Hostname>!BBL.2132: 043098: TUXEDO Version 2.1 
      <ID>.<Hostname>!BBL.2132: LIBTUX_CAT:262:
           INFO: Standard main starting
      <ID>.<Hostname>!BBL.2132: LIBTUX_CAT:296:
           ERROR: _tlog_open: _gp_tblopen: VTOC not initialized
      <ID>.<Hostname>!BBL.2132: LIBTUX_CAT:319:
           ERROR: Log start cannot open tlog
      <ID>.<Hostname>!BBL.2132: LIBTUX_CAT:248:
           ERROR: System init function failed, Uunixerr = 
      <ID>.<Hostname>!BBL.2132: CMDTUX_CAT:26:
           INFO: The BBL is exiting system


   e) If the sqlnet.log contains the following error 

      Time: 28-MAY-98 16:50:06
      Tracing not turned on.
      Tns error struct:
       nr err code: 12223
       TNS-12223: TNS:internal limit restriction exceeded
       ns main err code: 12540
       TNS-12540: TNS:internal limit restriction exceeded
       ns secondary err code: 12560
       nt main err code: 510
       TNS-00510: Internal limit restriction exceeded
       nt secondary err code: 12
       nt OS err code: 0

      too many TNS connections may be open simultaneously. You will
      need to wait for some of these connections to be released
