/*
	Copyright (c) 2005 BEA Systems, Inc.
	All rights reserved

	THIS IS UNPUBLISHED PROPRIETARY
	SOURCE CODE OF BEA Systems, Inc.
	The copyright notice above does not
	evidence any actual or intended
	publication of such source code.
*/
//--------------------------------------------------------------------
//
// server_ex.h
//
// Utilities to help clients write info to the user log and handle
// CORBA and random exceptions.
//
// BEA Systems Inc. sample code
//
//--------------------------------------------------------------------

#ifndef _SERVER_EX_H_
#define _SERVER_EX_H_

#ifdef WIN32
#if (_MSC_VER >= 1300)
#include <strstream>
using namespace std;
#else
#include <strstrea.h>
#endif
#else
#include <strstream.h>
#endif
#include "ex.h"

// write an ostream fragment to the userlog
#define REPORT(ostream_fragment)  \
                                  \
  ostrstream os;                  \
  os << ostream_fragment << ends; \
  const char* str = os.str();     \
  os.rdbuf()->freeze(0);          \
  TP::userlog("%s", str)

// catch all exceptions, report the exception to the userlog,
// then continue (v.s. rethrow)
#define CATCH_REPORT_AND_SWALLOW_EXCEPTION               \
                                                         \
  catch (CORBA::SystemException& e) {                    \
    REPORT("unexpected CORBA::SystemException : " << e); \
  }                                                      \
  catch (CORBA::Exception& e) {                          \
    REPORT("unexpected CORBA::Exception : " << e);       \
  }                                                      \
  catch (...) {                                          \
    REPORT("unexpected exception");                      \
  }

#endif
