/*
*  Copyright (c) 2016 Oracle, Inc.
*  All rights reserved
*
*  THIS IS UNPUBLISHED PROPRIETARY
*  SOURCE CODE OF ORACLE, Inc.
*  The copyright notice above does not
*  evidence any actual or intended
*  publication of such source code.
*/
/* #ident       "@(#) samples/tdc/tdcapp/tdcclient.c     $Revision: 1.1 $" */

#include <stdio.h>
#include <atmi.h>             /* TUXEDO  Header File */
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#define MAXKEYLEN       127

#define MAXSIZE         4096

#define KEY             "tdc_demo_key"

char *sendbuf, *rcvbuf;
void myexit(){
        tpfree(sendbuf);
        tpfree(rcvbuf);
        tpterm();
        exit(1);
}

#if defined(__STDC__) || defined(__cplusplus)
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif

{
  
    char *key = NULL;
    long sendlen, rcvlen;
    char * cmd = NULL;
    TCACHE * tc = NULL;
    int ret;
    int  fd ;
    int size;
    int i=0;
        
     /* Attach to System/T as a Client Process */
     if (tpinit((TPINIT *) NULL) == -1) {
        printf("Tpinit failed, tperrno=%d.\n", tperrno);
        exit(1);
    }

    /* Allocate STRING buffers for the request and the reply */
    if((sendbuf = (char *) tpalloc("STRING", NULL, MAXSIZE+1)) == NULL) {
        printf("Error allocating send buffer, tperrno=%d.\n", tperrno);
        tpterm();
        exit(1);
    }

    if((rcvbuf = (char *) tpalloc("STRING", NULL, MAXSIZE+1)) == NULL) {
        printf("Error allocating receive buffer, tperrno=%d.\n", tperrno);
        tpfree(sendbuf);
        tpterm();
        exit(1);
    }

    /* get the cache*/
    tc = tpgetcache("cache");
    if ( NULL == tc )
    {
        printf("tpgetcache failed:");
        printf("Tperrno = %d,Tpurcode= %d\n", tperrno,tpurcode);
        myexit();
    }
        
    /*remove all the data*/
    ret =tpcacheremoveall(tc, 0L);
    if(ret == -1) 
    {
        printf("tpcacheremoveall failed:");
        printf("Tperrno = %d\n", tperrno);
        myexit();
    }
        
    /*demo:tpcacheget first time*/
    printf("get data first time----start\n");
    printf("------------------------------------------------\n");
    ret = tpcacheget(tc, KEY, &rcvbuf, &rcvlen, 0L);
    if(ret == -1) {
        userlog("Cant't get the data from cache with the specify key\n, try to get it from local file in the first time.\n");
        printf("Cant't get the data from cache with the specify key\n, try to get it from local file in the first time.\n\n");
    }
     
    /*read content from local file*/
    fd=open("tdc.text",O_RDONLY);
    if ( fd < 0){
        printf("open file failed.\n");
        myexit();
    }
    size = read(fd, sendbuf, MAXSIZE);
    if (size < 0){
        printf("read file failed.\n");
        close(fd);
        myexit();
    }
    close(fd);

    /*put the data to cache*/
    sendbuf[size-1]='\0';
    ret = tpcacheput(tc, KEY, sendbuf, 0, 0L);
    if(ret == -1) {
        printf("tpcacheput failed:");
        printf("Tperrno = %d\n", tperrno);
        myexit();
    }

    /*print the content to stdout*/
    printf("get the data from file tdc.text:\n");
    printf("##################################\n");
    printf("%s\n", sendbuf);
    printf("##################################\n");
    
    printf("------------------------------------------------\n");
    printf("get data first time----end\n\n\n\n");
     /*demo:tpcacheget second time*/

    printf("get data second time----start\n");
    printf("------------------------------------------------\n");
    ret = tpcacheget(tc, KEY, &rcvbuf, &rcvlen, 0L);
    if(ret == -1) {
        userlog("get the data with the specify key from cache failed.\n");
        printf("get the data with the specify key from cache failed.\n");
    }
    /*print the content to stdout*/
    printf("get the data from cache:\n");
    printf("##################################\n");
    printf("%s\n", rcvbuf);
    printf("##################################\n");
    printf("get the data with the specify key from cache success.\n\n");
    userlog("get the data with the specify key from cache success.\n");
    printf("------------------------------------------------\n");
    printf("get data second time----end\n\n");
     
    /*demo:tpcacheremove*/
    ret = tpcacheremove(tc, KEY,0L);
    if(ret == -1) {
        printf("tpcacheremove failed:");
        printf("Tperrno = %d\n", tperrno);
        myexit();
    }
    printf("remove the data with the specify key from cache success.\n");
     
    /* Free Buffers & Detach from System/T */
    tpfree(sendbuf);
    tpfree(rcvbuf);
    tpterm();
    return(0);
}

