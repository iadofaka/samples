/*
  Copyright (c) 2016 Oracle, Inc.
  All rights reserved

  THIS IS UNPUBLISHED PROPRIETARY
  SOURCE CODE OF ORACLE, Inc.
  The copyright notice above does not
  evidence any actual or intended
  publication of such source code.
*/
/* #ident       "@(#) samples/tdc/tscapp/tscclient.c     $Revision: 1.1 $" */

#include <stdio.h>
#include <atmi.h>             /* TUXEDO  Header File */
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#define MAXKEYLEN       127

#define MAXSIZE         4*1024*1024


char *sendbuf, *rcvbuf;
void myexit(){
        tpfree(sendbuf);
        tpfree(rcvbuf);
        tpterm();
        exit(1);
}

#if defined(__STDC__) || defined(__cplusplus)
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif

{
  
    char *key = NULL;
    long sendlen, rcvlen;
    char * cmd = NULL;
    TCACHE * tc = NULL;
    struct timeval starttime, endtime;
    long timeuse;
    int ret;
    int  fd ;
    int size;
    int i=0;
        
    /* Attach to System/T as a Client Process */
     if (tpinit((TPINIT *) NULL) == -1) {
        printf("Tpinit failed, tperrno=%d.\n", tperrno);
        exit(1);
    }

    /* Allocate STRING buffers for the request and the reply */
    if((sendbuf = (char *) tpalloc("STRING", NULL, 128)) == NULL) {
        printf("Error allocating send buffer, tperrno=%d.\n", tperrno);
        tpterm();
        exit(1);
    }

    if((rcvbuf = (char *) tpalloc("STRING", NULL, MAXSIZE+1)) == NULL) {
        printf("Error allocating receive buffer, tperrno=%d\n", tperrno);
        tpfree(sendbuf);
        tpterm();
        exit(1);
    }
    /*clear the cache*/
    tc = tpgetcache("cache");
    if ( tc == NULL ){
         printf("connect cache error, tperrno=%d\n", tperrno);
         myexit();
    }
    ret = tpcacheremoveall(tc,0L);
    if ( ret == -1 ){
        printf(" clear the cache error, tperrno=%d\n", tperrno);
        myexit();
    }
    
    /*get data from service*/
    printf("Call QUERY first time, get data from service Query -- START.\n");
    userlog("Call QUERY first time, get data from service Query -- START.\n");
    sendbuf[1]='\0';
    gettimeofday( &starttime, NULL );
    ret = tpcall("QUERY", sendbuf, 0, &rcvbuf, &rcvlen,0L);
    if (ret ==-1){
        printf("tpcall QUERY failed, tperrno=%d.\n", tperrno);
        myexit();
    }
    gettimeofday( &endtime, NULL );
    timeuse = 1000000*(endtime.tv_sec - starttime.tv_sec ) + endtime.tv_usec - starttime.tv_usec;
    printf("The spend time : %ld.\n",timeuse);
    printf("Call QUERY first time, get data from service Query -- END.\n");
    userlog("Call QUERY first time, get data from service Query -- END.\n");

    /*get data from cache*/
    printf("Call QUERY second time, get data from cache -- START!\n");
    userlog("Call QUERY second time, get data from cache -- START!\n");
    gettimeofday( &starttime, NULL );
    ret = tpcall("QUERY", sendbuf, 0, &rcvbuf, &rcvlen,0L);
    if (ret ==-1){
        printf("tpcall QUERY failed, tperrno=%d.\n", tperrno);
    }
    gettimeofday( &endtime, NULL );
    timeuse = 1000000*(endtime.tv_sec - starttime.tv_sec ) + endtime.tv_usec - starttime.tv_usec;
    printf("The spend time : %ld.\n",timeuse);
    printf("Call QUERY second time, get data from cache -- END!\n");
    userlog("Call QUERY second time, get data from cache -- END!\n");
    
    /*clear the cache */
    tpcacheremoveall(tc, 0L);

    /* Free Buffers & Detach from System/T */
    tpfree(sendbuf);
    tpfree(rcvbuf);
    tpterm();
    return(0);
}

