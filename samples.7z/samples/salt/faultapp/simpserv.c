/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
   Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved

   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */

/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/
#ifdef __cplusplus
extern "C"
#endif

#if defined(__STDC__) || defined(__cplusplus)
int tpsvrinit(int argc, char *argv[])
#else
int tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */
	argc = argc;
	argv = argv;

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the simple server");
	return(0);
}

#if defined(__STDC__) || defined(__cplusplus)
void Misc_Val001(TPSVCINFO *rqst)
#else
void Misc_Val001(rqst)
TPSVCINFO *rqst;
#endif
{
	int strLen;
	char *sendbuf;
	char * ptr;

	ptr = "ABCDEFGHIJKLMN";
	strLen=strlen(ptr);
    if ( (sendbuf = (char *) tpalloc("STRING", NULL, strLen+1)) == NULL )
	{
		fprintf(stderr,"Error allocating send buffer\n");
		tpterm();
        exit(1);
    }

	(void) strcpy(sendbuf, ptr);
	tpreturn(TPFAIL, 0, sendbuf, strLen + 1, 0);
}

