#!/bin/sh
. ./bankvar.sh
tmboot -y
sh ./populate.sh
