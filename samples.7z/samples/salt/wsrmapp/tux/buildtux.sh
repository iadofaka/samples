#!/bin/sh
. ./bankvar.sh
$MAKE -f $MAKEFILE all
tmloadcf -y ubbshm.unix
wsloadcf -y gwws.dep
sh ./crbankdb.sh
sh ./crtlog.sh
tmloadrepos -i bankapp.mif bankapp.repos
