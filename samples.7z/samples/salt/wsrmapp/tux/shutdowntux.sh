#!/bin/sh
. ./bankvar.sh
tmshutdown -y
rmskill
