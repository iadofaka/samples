/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

package com.bea.salt.examples.wsrm;

public class BankData {

    private long    sourceAcct;
    private long    destAcct;
    private float   depositNum;
    private float   transferNum; 
    private float   withdrawalNum;

    public long getSourceAcct() {
        return     sourceAcct;
    }

    public void setSourceAcct( long acct) {
        sourceAcct = acct;
    }

    public long getDestAcct() {
        return     destAcct;
    }

    public void setDestAcct( long acct) {
        destAcct = acct;
    }

    public float getDepositNum() {
        return depositNum;
    }

    public void setDepositNum(float num) {
        depositNum = num;
    }

    public float getTransferNum() {
        return transferNum;
    }

    public void setTransferNum(float num) {
        transferNum = num;
    }

    public float getWithdrawalNum() {
        return withdrawalNum;
    }

    public void setWithdrawalNum(float num) {
        withdrawalNum = num;
    }
}

