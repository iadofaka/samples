/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

package com.bea.salt.examples.wsrm;

import java.rmi.RemoteException;

/**
 *  This is a simple standalone client application that
 *  invokes the the <code>startBankApp</code> operation
 *  of the BankAppClient Web service.
 *  The startBankApp operation in turn invokes the Tuxedo
 *  BankApp application through BEA SALT in Web Service manner.
 *  The bank operations provided by SALT are invoked reliably.
 *
 */
public class Client {

    private String  clientUrl       = "http://localhost:7001/BankAppClient/BankAppClient";

    private long    sourceAcct      = 50001;
    private long    destAcct        = 60002;
    private float   depositNum      = 2500;
    private float   transferNum     = 1300;
    private float   withdrawalNum   = 1250;
    private int     waitMSec        = 5000;

    public Client() {}

    public Client(String pClientUrl) {
        this.clientUrl = pClientUrl;
    }

    /**
     * Runs this example from the command line. Example:
     * <p>
     * <tt>java com.bea.salt.examples.wsrm.Client "http://localhost:7001/BankAppClient/BankAppClient"</tt>
     * <p>
     * The parameters are optional, but if any are supplied,
     * they are interpreted in this order:
     * <p>
     * @param args  url of Client WS such as "http://localhost:7001/BankAppClient/BankAppClient"
     */
    public static void main(String[] args) throws Exception {

        System.out.println("\nBeginning BankAppClient with BEA SALT...\n");

        Client client   =   null;
        String url      =   "http://localhost:7001";

        // Parse the argument list
        if ( args.length > 1 ) {
            System.out.println( "Usage: java com.bea.salt.examples.wsrm.Client " +
                                "http://localhost:7001/BankAppClient/BankAppClient" );
            return;
        } else if (args.length == 1) {
            client = new Client(args[0]);
        }

        try {
            client.invokeWS();
        } catch (Exception e) {
          System.out.println("There was an exception while invoking the WS-RM example.");
          throw e;
        }

        System.out.println("\nEnd com.bea.salt.examples.Client...\n");
    }

    /**
     * <p>FIXME</p>
     *
     * @throws RemoteException
     */
    public void invokeWS() throws Exception {
        try {
          BankAppClientService  service  = new BankAppClientService_Impl( clientUrl+"?WSDL" );
          BankAppClientPortType port     = service.getBankAppClientServicePort(); 
          BankData              bankData = new BankData();
          
          bankData.setSourceAcct(sourceAcct);
          bankData.setDestAcct(destAcct);
          bankData.setDepositNum(depositNum);
          bankData.setTransferNum(transferNum);
          bankData.setWithdrawalNum(withdrawalNum);

          String bankOperation = port.startBankApp(bankData);
          System.out.println("\n");
          System.out.println("-------------------------------------------------------");
          System.out.println(bankOperation);
         
          int interval = 0;

          // We simulate some other operation when wait the Async web service response
          // got.
          while ( interval < waitMSec ) { 
              System.out.print("-");
              interval += 100;
              Thread.sleep(100);
          }

          System.out.println("-------------------------------------------------------");
          System.out.println("Bank Operation Results:");
          System.out.println("-------------------------------------------------------");
          bankOperation = port.inquiry();
          System.out.println(bankOperation);
          System.out.println("-------------------------------------------------------");
          System.out.println("Thanks for your patience.");
        } catch (Exception e) {
          System.out.println("Error occurred while making WS call: "+e.getMessage());
          throw e;
        }
    }

}
