/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

package com.bea.salt.examples.wsrm;

import java.io.*;
import java.util.*;

public class Storage {

    public static String beginSymbol = "----------------------------------------------"; 

    public static String read(String fileName) throws IOException {

        StringBuffer    buffer  = new StringBuffer();
        BufferedReader  in      = new BufferedReader(new FileReader(fileName));
        String          s;
        while( ( s = in.readLine() ) != null ) {
            buffer.append(s);
            buffer.append("\n");
        }
        in.close();
        return buffer.toString();
    }

    public static String readLast(String fileName) throws IOException {
        String str = Storage.read(fileName);
        String[] str_array;
        String lastStr="";

        str_array = str.split("\n");
        for ( int i = str_array.length - 1; i >= 0; i-- ) {
            if (str_array[i].equals(beginSymbol) ) {
                break;
            }

            lastStr +=str_array[i];
            lastStr += "\n";
        }

        // reverse the order 
        str_array = lastStr.split("\n");
        lastStr = "";
        for (int i = str_array.length - 1; i >= 0; i--) {
            lastStr +=str_array[i];
            lastStr += "\n";
        }
        return lastStr;
    }


    public static void write(String fileName, String text) throws IOException {
        PrintWriter out = new PrintWriter(
            new BufferedWriter(new FileWriter(fileName, true)));

        out.println(text);
        out.close();
    }


    public static void addBegin(String fileName) throws IOException {
        Storage.write(fileName,beginSymbol);
    }

    public Storage(String fileName) throws IOException {
    }
}

