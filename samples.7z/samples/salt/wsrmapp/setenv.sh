# (c) 2007 BEA Systems, Inc. All Rights Reserved.
# Copyright (c) 2007  BEA Systems, Inc.
# All Rights Reserved

# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
# BEA Systems, Inc.
# The copyright notice above does not evidence any
# actual or intended publication of such source code.

export GWWS_HOST=@Your Host Name, Do not Use IP Address@
export GWWS_PORT=@Your HTTP Listen Port@
export IPCKEY=@Your Tuxedo application IPCKEY@
export TUXDIR=@Your Tuxedo Installed Directory@
export JAVA_HOME=@Your Java Home Directory@
export WL_HOME=@Your WebLogic Home Directory@
export ANT_HOME=@Your ANT Home Directory@

export MAKE=@Your make command@
export MAKEFILE=@make file appropriate for this platform@

export PATH=$TUXDIR/bin:$ANT_HOME/bin:$WL_HOME/server/bin:$JAVA_HOME/bin:$PATH
export LD_LIBRARY_PATH=$TUXDIR/lib:$LD_LIBRARY_PATH
export SHLIB_PATH=$TUXDIR/lib:$SHLIB_PATH
export LIBPATH=$TUXDIR/lib:$LIBPATH

#
# setting a running Weblogic Server
#
export WL_SERVER_HOST=@Host name where your Weblogic Server is running@
export WL_SERVER_PORT=@Port number that your Weblogic Server is listening@
export WL_SERVER_NAME=@Your Weblogic server name@
export WL_ADMIN_USER=@Your weblogic server user name that have deployment privilege@
export WL_ADMIN_PASS=@Your weblogic server user password that have deployment privilege@
