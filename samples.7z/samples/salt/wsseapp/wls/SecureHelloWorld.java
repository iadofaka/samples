/* 
   (c) 2007 BEA Systems, Inc. All Rights Reserved. 
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

/* #ident "@(#) samples/wsseapp/SecureHelloWorld.java	$Revision: 1.1 $" */

package examples.webservices.wsseapp;

import java.util.Random;
import java.util.Properties;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.*;
import java.rmi.RemoteException;
import javax.xml.rpc.Stub;
import weblogic.security.SSL.TrustManager;
import java.util.List;
import java.util.ArrayList;

import java.security.cert.X509Certificate;
import weblogic.xml.crypto.wss.provider.CredentialProvider;
import weblogic.xml.crypto.wss.WSSecurityContext;
import weblogic.wsee.security.bst.ClientBSTCredentialProvider;
import weblogic.wsee.security.unt.ClientUNTCredentialProvider;


public class SecureHelloWorld {

	CredentialProvider UNTcp;   // Username token credential provider
	CredentialProvider BSTcp;   // Binary X509 token credential provider
	TuxSvcLst_PortType port; 


	public SecureHelloWorld(String[] args) throws Exception {
		// Username or password for the UsernameToken
		String username = args[0];
		String password = args[1];

		
		// Client private key and certificate file
		String keyFile = args[2];
		String clientCertFile = args[3];

		// Standard JAX-RPC code to get a service and port type

		TuxedoWebService service = new TuxedoWebService_Impl();
		port = service.getSecureHelloPort();

		// Create Username and X509 binary security token
 		UNTcp = new ClientUNTCredentialProvider(username, password);
		BSTcp = new ClientBSTCredentialProvider(clientCertFile, keyFile);
	}



	public static void main(String[] args) throws Exception {

		SecureHelloWorld client = new SecureHelloWorld(args);
		
		client.invokeTOUPPER();
		client.invokeTOLOWER();
		client.invokeREVERT();
	}

	public void invokeTOUPPER() throws RemoteException {
		List credProviders = new ArrayList();
		
		credProviders.add(UNTcp);
		Stub stub = (Stub)port;
		stub._setProperty(WSSecurityContext.CREDENTIAL_PROVIDER_LIST, credProviders);		
		
		System.out.println("invoking TOUPPER() with Username Token");
		String response = port.tOUPPER("Hello World");
		System.out.println("response = " + response);
		System.out.println();
	}


	public void invokeTOLOWER() throws RemoteException {
		List credProviders = new ArrayList();
		
		credProviders.add(UNTcp);
		credProviders.add(BSTcp);
		Stub stub = (Stub)port;
		stub._setProperty(WSSecurityContext.CREDENTIAL_PROVIDER_LIST, credProviders);		
		stub._setProperty(WSSecurityContext.TRUST_MANAGER,
			new TrustManager(){
			 public boolean certificateCallback(X509Certificate[] chain, int validateErr){
			   //Typically in a real-life application, Java code that actually 
			   //verifies the certificate goes here; for sake of simplicity, this
			   //example assumes the certificate is valid and simply returns true.
			
			   return true;
			 }
			} );
		
		System.out.println("invoking TOLOWER() with Username Token, X509 token and Signed body");
		String response = port.tOLOWER("Hello World");
		System.out.println("response = " + response);
		System.out.println();
	}

	public void invokeREVERT() throws RemoteException {
		List credProviders = new ArrayList();
		
		credProviders.add(BSTcp);
		Stub stub = (Stub)port;
		stub._setProperty(WSSecurityContext.CREDENTIAL_PROVIDER_LIST, credProviders);		
		stub._setProperty(WSSecurityContext.TRUST_MANAGER,
			new TrustManager(){
			 public boolean certificateCallback(X509Certificate[] chain, int validateErr){
			   //Typically in a real-life application, Java code that actually 
			   //verifies the certificate goes here; for sake of simplicity, this
			   //example assumes the certificate is valid and simply returns true.
			
			   return true;
			 }
			} );
		
		System.out.println("invoking REVERT() with X509 token and Signed body");
		String response = port.rEVERT("Hello World");
		System.out.println("response = " + response);
		System.out.println();
	}
}
