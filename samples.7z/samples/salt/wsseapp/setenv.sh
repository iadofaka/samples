#	(c) 2007 BEA Systems, Inc. All Rights Reserved.
#	Copyright (c) 2007 BEA Systems, Inc.	
#	All Rights Reserved 	 
#
#	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF 
#	BEA Systems, Inc.  
#	The copyright notice above does not evidence any  
#	actual or intended publication of such source code.
#
#	ident	"@(#) samples/wsseapp/setenv.sh	$Revision: 1.3 $"


# Setup environment for WebLogic Server 10.0
export WL_HOME=@WebLogic 10.0 home directory@
. $WL_HOME/samples/domains/wl_server/setExamplesEnv.sh

# Set environment for Tuxedo and Salt
export TUXDIR=<full path of Tuxedo software>
export IPCKEY=62345
export LANG=C
export PATH=$TUXDIR/bin:$PATH
export SHLIB_PATH=$TUXDIR/lib:$SHLIB_PATH
export LIBPATH=$TUXDIR/lib:$LIBPATH
export LD_LIBRARY_PATH=$TUXDIR/lib:$LD_LIBRARY_PATH

export HOSTNAME=`uname -n`
export GWWS_HOST=$HOSTNAME
export GWWS_PORT=4798

