# (c) 2007 BEA Systems, Inc. All Rights Reserved.
#
#     Copyright (c) 2007  BEA Systems, Inc.
#       All Rights Reserved
# 
#     THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
#     BEA Systems, Inc.
#     The copyright notice above does not evidence any
#     actual or intended publication of such source code.

export OPENSSL_CONF=$PWD/openssl.cnf

rm -fr ./demoCA
mkdir ./demoCA
rm -f *.pem *.der
echo "01" >./demoCA/serial
touch ./demoCA/index.txt

# Create root CA
echo "----------- Create Root CA -----------"
openssl genrsa -out ca_key.pem 1024
openssl req -new -key  ca_key.pem -out  ca_cert.csr <./ca_cert.ans
openssl x509 -req -days 6000 -in ca_cert.csr -signkey ca_key.pem -out ca_cert.pem

# Create level-2 CA certificate
echo "----------- Create Level-2 CA -----------"
openssl genrsa -out ca_lev2_key.pem 1024
openssl req -new -key  ca_lev2_key.pem -out ca_lev2_cert.csr <./ca_lev2_cert.ans
openssl ca -policy policy_anything -cert ca_cert.pem -keyfile ca_key.pem -startdate 070701000000Z -enddate 270701000000Z -in ca_lev2_cert.csr -outdir . -out ca_lev2_cert.pem <./confirm.ans

# Create "testUser" certificate
echo "----------- Create testUser private key and certificate -----------"
openssl genrsa -out testUser_key.pem 1024
openssl req -new -key  testUser_key.pem -out testUser_cert.csr <./testUser_cert.ans
openssl ca -policy policy_anything -cert ca_lev2_cert.pem -keyfile ca_lev2_key.pem -startdate 070701000000Z -enddate 270701000000Z -in testUser_cert.csr -outdir . -out testUser_cert.pem <./confirm.ans
# convert the private key from PEM format to DER format
openssl pkcs8 -in  testUser_key.pem -inform PEM -topk8 -nocrypt -outform DER -out testUser_key.der
#rem convert the certificate from PEM format to DER format
openssl x509 -inform PEM -in testUser_cert.pem -outform DER -out testUser_cert.der

rm -f *.csr 

