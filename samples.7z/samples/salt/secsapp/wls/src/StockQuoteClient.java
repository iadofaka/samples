/**
 *  Copyright (c) 2007 BEA Systems, Inc.
 *  All rights reserved
 *
 *  THIS IS UNPUBLISHED PROPRIETARY
 *  SOURCE CODE OF BEA Systems, Inc.
 *  The copyright notice above does
 *  not evidence any actual or intended
 *  publication of such source code.
 */

package com.bea.salt.examples.secsapp;
import com.bea.salt.samples.secsapp.TuxedoWebService;
import com.bea.salt.samples.secsapp.SecsAppSrvGrp;
import com.bea.salt.samples.secsapp.TuxedoWebService_Impl;

import java.io.*;
import java.util.Properties;

import javax.xml.stream.*;
import javax.xml.parsers.*;

import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.w3c.dom.*;

import javax.xml.soap.*;

import weblogic.xml.saaj.*;
import weblogic.xml.domimpl.DocumentImpl;

    /**
     *
     */
public class StockQuoteClient {

    public static void main( String[] args ) throws Exception {

        TuxedoWebService    tuxWebService;

        /**
         *  It will be replace is build with ant.
         */
        SecsAppSrvGrp       portTypeStockApp;

        java.io.File        inXmlFile;

        /**
         *
         */
        if( 1 > args.length ) {
            System.out.println( "Please use input XML file as argument!" );
            return;
        }
        inXmlFile = new File( args[0] );    // input XML file

        /**
         *  Tranform that will be used to deserialize/serialize
         *  input/output XML buffer.
         */
        TransformerFactory  transFactory = TransformerFactory.newInstance();
        Transformer         transformer  = transFactory.newTransformer();

        /**
         *  Service and portTypeStockApp of Web Service.
         */
        tuxWebService     = new TuxedoWebService_Impl();
        portTypeStockApp  = tuxWebService.getSecsApp_HTTPS_IN(
                                System.getenv( "TUX_USERNAME" ).toString().getBytes(),
                                System.getenv( "TUX_PASSWORD" ).toString().getBytes() );

        SOAPFactory soapFactoryImpl = SOAPFactoryImpl.newInstance();
        SOAPElement soapElement     =
                    soapFactoryImpl.createElement(
                            "inbuf", null, "urn:salt.samples.wsdl" );

        transformer.transform(
                    new StreamSource(inXmlFile), new DOMResult(soapElement) );

        Element     outputXML   = (Element)portTypeStockApp.stockQuote( soapElement );
        NodeList    domNodeList = outputXML.getElementsByTagName( "*" );

        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        transformer.transform( new DOMSource( domNodeList.item(0) ),
                               new StreamResult( outStream ) );
        System.out.println( outStream.toString() );
    }

}


