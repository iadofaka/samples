/**
 *  Copyright (c) 2007 BEA Systems, Inc.
 *  All rights reserved
 *
 *  THIS IS UNPUBLISHED PROPRIETARY
 *  SOURCE CODE OF BEA Systems, Inc.
 *  The copyright notice above does
 *  not evidence any actual or intended
 *  publication of such source code.
 */
/*
 *  The Apache Software License, Version 1.1
 *
 *  Copyright (c) 1999-2001 The Apache Software Foundation.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with
 *  or without modification, are permitted provided that the
 *  following conditions are met:
 *
 *  1.  Redistributions of source code must retain the above
 *      copyright notice, this list of conditions and the
 *      following disclaimer.
 *
 *  2.  Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the
 *      following disclaimer in the documentation and/or other
 *      materials provided with the distribution.
 *
 *  3.  The end-user documentation included with the redistribution,
 *      if any, must include the following acknowledgment:
 *          "This product includes software developed by the
 *          Apache Software Foundation (http://www.apache.org/)."
 *      Alternately, this acknowledgment may appear in the software
 *      itself, if and wherever such third-party acknowledgments
 *      normally appear.
 *
 *  4.  The names "Xerces" and "Apache Software Foundation" must
 *      not be used to endorse or promote products derived from
 *      this software without prior written permission.
 *      For written permission, please contact apache\@apache.org.
 *
 *  5.  Products derived from this software may not be called "Apache",
 *      nor may "Apache" appear in their name, without prior written
 *      permission of the Apache Software Foundation.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of the Apache Software Foundation, and was
 *  originally based on software copyright (c) 1999, International
 *  Business Machines, Inc., http://www.ibm.com .  For more information
 *  on the Apache Software Foundation, please see
 *  <http://www.apache.org/>.
 */

/* #ident	"@(#) samples/secsapp/tuxsrc/XMLWrapper.cpp	$Revision: 1.2 $" */


// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/util/XMLUniDefs.hpp>
#include <xercesc/util/TranscodingException.hpp>

#include <xercesc/framework/XMLFormatter.hpp>
#include <xercesc/framework/MemBufInputSource.hpp>
#include <xercesc/framework/MemBufFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>

#include <userlog.h>

#include "DOMTreeErrRpt.hpp"
#include "XMLWrapper.h"

XERCES_CPP_NAMESPACE_USE

XMLWrapper          _gclXmlWrapper;
char               *_gpcstrLocalBuf = NULL;
static const char  *_gscstrBufId    = "mybuf";


// ---------------------------------------------------------------------------
//  Forward references
// ---------------------------------------------------------------------------
void walkTree     ( DOMNode *, DOMDocument * );
void walkStockInfo( DOMNode *, DOMDocument * );

    /************************************************************************/
    /*                                                                      */
    /************************************************************************/
    /**
     *
     */
XMLWrapper* getHandle()
{
    return &_gclXmlWrapper;
}

    /**
     *
     */
void parseXMLBuffer( void* handle, char **ppcstr_xmlbuf )
{
   ( (XMLWrapper*)handle )->parseXMLBuffer( ppcstr_xmlbuf );
}
    /************************************************************************/
    /*                                                                      */
    /************************************************************************/


    /************************************************************************/
    /*                                                                      */
    /************************************************************************/
    /**
     *
     */
void XMLWrapper::parseXMLBuffer( char **ppcstr_xmlbuf )
{
    _gpcstrLocalBuf = (char *)malloc( sizeof(char*) * 2048 );
    memset( _gpcstrLocalBuf, 0, sizeof(char *) * 2048 );

    /**
     *  Initialize the Xerces context.
     */
    try
    {
        XMLPlatformUtils::Initialize();
    }
    catch( const XMLException& toCatch )
    {
        XERCES_STD_QUALIFIER
            cerr<<  "Error during Xerces-c Initialization.\n"
                <<  "  Exception message:"
                <<  XMLString::transcode( toCatch.getMessage() )
                <<
        XERCES_STD_QUALIFIER endl;
    }

    MemBufInputSource *_tmp_pclMemBufIS_ =
                new MemBufInputSource( (const XMLByte*)*ppcstr_xmlbuf,
                                        strlen(*ppcstr_xmlbuf), _gscstrBufId, true );
    *ppcstr_xmlbuf = _gpcstrLocalBuf;

    /**
     *  Create our parser, then attach an error handler
     *  to the parser.
     *  The parser will call back to methods of the
     *  ErrorHandler if it discovers errors during the
     *  course of parsing the XML document.
     */
    XercesDOMParser         *_tmp_pclDomParser_ = new XercesDOMParser;
    DOMTreeErrorReporter    *_tmp_pclDomErrRpt_ = new DOMTreeErrorReporter();
    _tmp_pclDomParser_->setErrorHandler( _tmp_pclDomErrRpt_ );

    /**
     *  Parse the XML file, catching any XML exceptions that
     *  might propogate out of it.
     */
    bool _tmp_bErrOccured_ = false;
    try
    {
        _tmp_pclDomParser_->parse( *_tmp_pclMemBufIS_ );
        int _tmp_intErrCount_ = _tmp_pclDomParser_->getErrorCount();
        if( 0 < _tmp_intErrCount_ )
        {
            _tmp_bErrOccured_ = true;
        }
    }
    catch( const XMLException& e )
    {
        XERCES_STD_QUALIFIER
            cerr<<  "An error occured during parsing\n   Message: "
                <<  XMLString::transcode( e.getMessage() )
                <<
        XERCES_STD_QUALIFIER endl;
        _tmp_bErrOccured_ = true;
    }
    catch( const DOMException& e )
    {
        XERCES_STD_QUALIFIER
            cerr<<  "A DOM error occured during parsing\n   DOMException code: "
                <<  e.code
                <<
        XERCES_STD_QUALIFIER endl;
        _tmp_bErrOccured_ = true;
    }
    catch(...)
    {
        XERCES_STD_QUALIFIER
            cerr<< "An error occured during parsing\n "
                <<
        XERCES_STD_QUALIFIER endl;
        _tmp_bErrOccured_ = true;
    }

    /**
     *  If the parse was successful, output the document
     *  data from the DOM tree
     */
    if( !_tmp_bErrOccured_ && !_tmp_pclDomErrRpt_->getSawErrors() )
    {
        /**
         *
         */
        DOMDocument *_tmp_pclDomDocu_    = _tmp_pclDomParser_->getDocument();
        DOMElement  *_tmp_pclDomEletTop_ = _tmp_pclDomDocu_->getDocumentElement();
        walkTree( _tmp_pclDomEletTop_, _tmp_pclDomDocu_ );

        DOMDocument         *_tmp_pclDomDocuResult_ =
                                _tmp_pclDomParser_->getDocument();

        /**
         *
         */
        DOMImplementation   *_tmp_pclDomImpl_   =
                                DOMImplementationRegistry::getDOMImplementation(
                                            XMLString::transcode("LS") );

        DOMImplementationLS *_tmp_impl = static_cast<DOMImplementationLS*>(_tmp_pclDomImpl_);
        DOMLSSerializer     *_tmp_serializer = _tmp_impl->createLSSerializer();
        DOMLSOutput         *_tmp_outputDesc = _tmp_impl->createLSOutput();

        MemBufFormatTarget  *_tmp_pclMemFormatTarget_
                                                = new MemBufFormatTarget();
        _tmp_outputDesc->setByteStream(_tmp_pclMemFormatTarget_);

        _tmp_serializer->write(_tmp_pclDomDocuResult_, _tmp_outputDesc);
        memcpy( _gpcstrLocalBuf,
                    (char*)_tmp_pclMemFormatTarget_->getRawBuffer(),
                    _tmp_pclMemFormatTarget_->getLen() );

        /**
         *  Clean the resource created and used.
         */
        delete _tmp_pclMemFormatTarget_;
        _tmp_outputDesc->release();
        _tmp_serializer->release();
    }

    /**
     *  Clean up the error handler. The parser does not
     *  adopt handlers since they could be many objects
     *  or one object installed for multiple handlers.
     */
    delete _tmp_pclDomErrRpt_;

    /**
     *  Delete the parser itself.
     *  Must be done prior to calling Terminate, below.
     */
    delete _tmp_pclDomParser_;

    /**
     *  And call the termination method to clean context.
     */
    XMLPlatformUtils::Terminate();
}


    /**
     *
     */
void walkTree( DOMNode *pclDomNode, DOMDocument *pclDomDocu )
{
    if( DOMNode::ELEMENT_NODE == pclDomNode->getNodeType() )
    {
        if( 0 ==
            strcmp( XMLString::transcode( pclDomNode->getNodeName() ), "stock_quote" ) )
        {
            walkStockInfo( pclDomNode, pclDomDocu );
        }
        else
        {
            DOMNodeList *_tmp_pclDomNList_ = pclDomNode->getChildNodes();
            for( int i=0; i<_tmp_pclDomNList_->getLength(); i++ )
            {
                walkTree( _tmp_pclDomNList_->item(i), pclDomDocu );
            }
        }
    }
}


    /**
     *
     */
void walkStockInfo( DOMNode *pclDomNode, DOMDocument *pclDomDocu )
{
    if( 0 ==
        strcmp( XMLString::transcode( pclDomNode->getNodeName() ),
                "stock_quote" )
      )
    {
        DOMNodeList *_tmp_pclDomNodeList_ = pclDomNode->getChildNodes();
        for( int i=0; i<_tmp_pclDomNodeList_->getLength(); i++ )
        {
            DOMNode *_tmp_pclDomNode_ = (DOMNode*)_tmp_pclDomNodeList_->item(i);
            if( 0 ==
                XMLString::compareString( _tmp_pclDomNode_->getNodeName(),
                                          XMLString::transcode( "symbol" ) )
              )
            {
                DOMNode* _tmp_pclDomNode2_ = _tmp_pclDomNode_->getFirstChild();
                if( NULL != _tmp_pclDomNode2_ )
                {
                    if( DOMNode::TEXT_NODE == _tmp_pclDomNode2_->getNodeType() )
                    {
                        DOMText *_tmp_pclDomText_ = (DOMText*)_tmp_pclDomNode2_;
                        if( 0 ==
                            XMLString::compareString(
                                    _tmp_pclDomText_->getData(),
                                    XMLString::transcode( "MSFT" ) ) )
                        {
                            /**
                             *  Create new element.
                             */
                            DOMElement *_tmp_pclDomElet_ =
                                pclDomDocu->createElement(
                                        XMLString::transcode( "price" ) );

                            /**
                             *  Add attribute to element.
                             */
                            _tmp_pclDomElet_->setAttribute(
                                    XMLString::transcode( "type" ) ,
                                    XMLString::transcode( "trade" )  );

                            _tmp_pclDomElet_->setAttribute(
                                    XMLString::transcode( "value" ),
                                    XMLString::transcode( "51.10" ) );
                            pclDomNode->appendChild( _tmp_pclDomElet_ );
                        }
                    }
                }
            }
        }
    }
}
    /************************************************************************/
    /*                                                                      */
    /************************************************************************/



