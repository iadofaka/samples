/**
 *  Copyright (c) 2007 BEA Systems, Inc.
 *  All rights reserved
 *
 *  THIS IS UNPUBLISHED PROPRIETARY
 *  SOURCE CODE OF BEA Systems, Inc.
 *  The copyright notice above does
 *  not evidence any actual or intended
 *  publication of such source code.
 */

/* #ident	"@(#) samples/secsapp/tuxsrc/XMLWrapper.h	$Revision: 1.2 $" */

#ifdef __cplusplus
extern "C"
{
#endif

extern void                 parseXMLBuffer( void *, char** );
extern struct XMLWrapper*   getHandle();

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
class XMLWrapper
{
public:
    void parseXMLBuffer( char ** );
};
#endif


