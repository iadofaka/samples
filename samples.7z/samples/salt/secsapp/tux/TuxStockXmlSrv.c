/**
 *  Copyright (c) 2007 BEA Systems, Inc.
 *  All rights reserved
 *
 *  THIS IS UNPUBLISHED PROPRIETARY
 *  SOURCE CODE OF BEA Systems, Inc.
 *  The copyright notice above does
 *  not evidence any actual or intended
 *  publication of such source code.
 */


/* #ident	"@(#) samples/secsapp/tuxsrc/TuxStockXmlSrv.c	$Revision: 1.2 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include <atmi.h>       /* TUXEDO Header File */
#include <userlog.h>    /* TUXEDO Header File */

#include "XMLWrapper.h"


/**
 *  tpsvrinit is executed when a server is booted,
 *  before it begins processing requests.
 *  It is not necessary to have this function.
 *  Also available is tpsvrdone( not used in this
 *  example ), which is called at server shutdown
 *  time.
 */
#if defined(__STDC__) || defined(__cplusplus)
int tpsvrinit( int argc, char *argv[] )
#else
int tpsvrinit( argc, argv )
    int     argc;
    char  **argv;
#endif
{
    /**
     *  Some compilers warn if argc and argv aren't used.
     */
    argc = argc;
    argv = argv;

    /**
     *  userlog writes to the central TUXEDO message log.
     */
    userlog( "Welcome to the stock quote application sample server" );
    return(0);
}


/**
 *  This function performs the actual service requested
 *  by the client.
 *  It's argument is a structure containing among other
 *  things a pointer to the data buffer, and the length
 *  of the data buffer.
 */
#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
STOCKQUOTE( TPSVCINFO *rqst )
#else
STOCKQUOTE( rqst )
    TPSVCINFO   *rqst;
#endif
{
    int                 i;
    struct XMLWrapper  *pXmlWrap;
    char               *pXmlBuf;
    FILE               *fp;
    char               *temp;

    pXmlWrap = getHandle();

    parseXMLBuffer( pXmlWrap, &rqst->data );
    rqst->len = strlen( rqst->data );

    pXmlBuf = (char *)tpalloc( "XML", NULL, (rqst->len)+1 );
    memset( pXmlBuf, 0         , (rqst->len)+1 );
    memcpy( pXmlBuf, rqst->data, rqst->len     );

    /**
     *  Return the transformed buffer to the requestor.
     */
    tpreturn( TPSUCCESS, 123, pXmlBuf, (rqst->len)+1, 0 );
}

