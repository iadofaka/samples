#############################################################
#   Copyright (c) 2007 BEA Systems, Inc.
#   All rights reserved
#
#   THIS IS UNPUBLISHED PROPRIETARY
#   SOURCE CODE OF BEA Systems, Inc.
#   The copyright notice above does
#   not evidence any actual or intended
#   publication of such source code.
#
#	ident	"@(#) TuxWS/samples/secsapp/setenv.sh	$Revision: 1.8 $"

# ---------------------------------------------------------
# Set Tuxedo home directory.
# Example: TUXDIR=/home/tuxedo
export TUXDIR=

# -----
# Set the WebLogic home directory.
# Example: WL_HOME=/home/wlsrv10
export WL_HOME=

# -----
# Set the JDK and Apache ant home
# Example: JDKHOME=/path/libs/jdk1.8.0_231
#          ANT_HOME=/path/libs/apache-ant-1.8.1
export JAVA_HOME=
export ANT_HOME=


# ---------------------------------------------------------
# Set the sample work directory.
# Example: APPDIR=/home/tuxedo/salt/me/secsapp/work
export APPDIR=`pwd`/work

# Directory of all files runME scripts need(in sample runme
# sub-directory.
export RUNME_DIR=`pwd`/runme

# ---------------------------------------------------------
#  You must set the C/C++ compiler path in PATH.
export PATH=.:$TUXDIR/bin:$JAVA_HOME/bin:$ANT_HOME/bin:$PATH

# ---------------------------------------------------------
# Set some environment parameter of tuxedo server.
export TUXCONFIG=$APPDIR/tuxconfig
export SALTCONFIG=$APPDIR/saltconfig

# Set Tuxedo Metadata Repository input text and
# output binary file parameters.
export REPOS_IN_NAME=mdr_secsapp.mif
export REPOS_OUT_NAME=mdr_secsapp.repos

# ---------------------------------------------------------
# Set some Tuxedo server environment parameters.
export IPCKEY=
export DOMAINID=
export GWWS_HOST=`uname -n`
export GWWS_SSLPORT=

# ---------------------------------------------------------
# Set GWWS service parameters. Please see the readme for detail.
export GWWS_INSTANCE_ID=


# ---------------------------------------------------------
# Application user passwd and certificate passwd.
# And in runme action, all shoule be "salt2007".
export APP_PW=
export TEST_VAR=


#----------------------------------------------------------
# Set tuxedo auth user and password
# Please refer the README for more detail
#
# If in runME process, the TUX_UESERNAME should be test
# and TUX_PASSWORD should be salt2007.
export TUX_USERNAME=
export TUX_PASSWORD=


# ---------------------------------------------------------
# Set the C/C++ compiler run environment.
export CFLAGS=-I.
export LINKLIB=-ltxml

# ---------------------------------------------------------
# Export library path:
#   LD_LIBRARY_PATH -   Must include $TUXDIR/lib on systems that
#                       use shared libraries(except HP-UX and AIX)
#   SHLIB_PATH      -   HP-UX only: must include $TUXDIR/lib
#   LIBPATH         -   AIX only: must include $TUXDIR/lib
#
#   export LD_LIBRARY_PATH SHLIB_PATH LIBPATH
export LD_LIBRARY_PATH=${TUXDIR}/lib:${LD_LIBRARY_PATH}
export SHLIB_PATH=${TUXDIR}/lib:${SHLIB_PATH}
export LIBPATH=$TUXDIR/lib:/usr/lib:${LIBPATH}


#
# Export C++ compiler.
#  on Solaris and Linux - export CC=CC
#  on HPUX              - export CC=aCC
#  on Digital Unix      - export CC=cxx
#  on AIX               - export CC=xlC_r



# ---------------------------------------------------------
# Set the Weblogic client environment.
# You can change the directory $WL_HOME/server/bin, run
# the script file setWLSEnv.sh to set weblogic client
# environment.


