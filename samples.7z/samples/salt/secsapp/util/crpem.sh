#!/bin/ksh

################################################################
#   (c) 2007 BEA Systems, Inc. All Rights Reserved.
#   Copyright (c)  2007  BEA Systems, Inc. 
#   All Rights Reserved
#
#   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
#   BEA Systems, Inc.
#   The copyright notice above does not evidence any
#   actual or intended publication of such source code.

#	ident "@(#) TuxWS/samples/secsapp/util/crpem.sh	$Revision: 1.3 $"
#
#
#   Usage: sh crpem.sh `uname -n`
#
#   - Use ./phrase for all prompts from running this script.
#
#   - The outputs can be used with the example secsapp/setenv.test values.
#
#   - The outputs are a number of pem files, of which copy
#     the followings to runme/ to be consumed by secsapp/build.xml.
#     The copy is the last action of this script for setting up this test.
#
#       cp server.pem cacert.pem trust.ks ../runme/
#

proc=${0}
mach=${1}
OPENSSL_CONF=${PWD}/openssl.cnf
export OPENSSL_CONF

create_cert()
{
    openssl req -newkey rsa:1024 -sha1 -keyout ${1}key.pem -passout file:phrase -out ${1}req.pem < ${1}.in

    # PEM key for GWWS must be of type RSA or DSA.

    openssl rsa -in ${1}key.pem -out tmp.pem.rsa
    mv tmp.pem.rsa ${1}key.pem

    # Sign the certificate with the root CA

    openssl x509 -req -in ${1}req.pem -sha1 -extensions usr_cert -CA root.pem -CAkey root.pem -CAcreateserial -passin file:phrase -out ${1}cert.pem -days 3650

    cat ${1}cert.pem ${1}key.pem cacert.pem > ${1}.pem

    openssl x509 -subject -issuer -dates -noout -in ${1}.pem
}

if [ `uname -s` = "Windows_NT" ]; then
    PATH="$PATH;${TUXDIR}/TuxWS/lib/ssl"
else
    PATH=$PATH:${TUXDIR}/TuxWS/lib/ssl
fi
export PATH

# Create the self-signed root CA and root's certificate: root.pem and cacert.pem
openssl req -newkey rsa:1024 -sha1 -keyout rootkey.pem -passout file:phrase -out rootreq.pem <root.in
openssl x509 -req -in rootreq.pem -sha1 -extensions v3_ca -passin file:phrase -signkey rootkey.pem -out cacert.pem -days 3650

cat cacert.pem rootkey.pem > root.pem

openssl x509 -subject -issuer -dates -noout -in root.pem

# Create server and client's certificates

cat > server.in << END_OF_IN
US
Boston
Boston
TUX
R&D
${mach}



END_OF_IN
create_cert server
rm server.in
cat > client.in << END_OF_IN2
US
Boston
Boston
TUX
R&D
client



END_OF_IN2
create_cert client
rm client.in

# Build keystore for Java Client.
# This ks is used by secsapp/build.xml
keytool -import -keystore trust.ks -file cacert.pem

# Keep the cert generation separate in pwd; and
# copy required files to runme/ for secsapp/build.xml to consume.
cp server.pem cacert.pem trust.ks ../runme/

