/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */

/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/
#ifdef __cplusplus
extern "C"
#endif

#if defined(__STDC__) || defined(__cplusplus)
int tpsvrinit(int argc, char *argv[])
#else
int tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */
	argc = argc;
	argv = argv;

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the simple server");
	return(0);
}

/* This function performs the actual service requested by the client.
   Its argument is a structure containing among other things a pointer
   to the data buffer, and the length of the data buffer.
*/
#if defined(__STDC__) || defined(__cplusplus)
void TestByteArray(TPSVCINFO *rqst)
#else
void TestByteArray(rqst)
TPSVCINFO *rqst;
#endif
{
	userlog("Input buffer length:%ld", rqst->len);
	tpreturn(TPSUCCESS, 0, rqst->data, rqst->len, 0);
}
