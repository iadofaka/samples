#   (c) 2007 BEA Systems, Inc. All Rights Reserved.
#   Copyright (c)  2007  BEA Systems, Inc. 
#   All Rights Reserved
#
#   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
#   BEA Systems, Inc.
#   The copyright notice above does not evidence any
#   actual or intended publication of such source code.

#
export TUXDIR=<full path of Tuxedo software>

#
export JAVA_HOME=<full PATH of JDK installation directory>
export ANT_HOME=<full PATH of ant installation directory>
export WL_HOME=<full PATH of webLogic server installation directory>

#
export APPDIR=$PWD/work
export IPCKEY=<The IPCKEY number for TUXEDO>

#
export GWWS_HOST=`uname -n`
export GWWS_PORT=<The port number used by SALT>

# You must set the C/C++ compiler path in PATH.
export PATH=$TUXDIR/bin:$JAVA_HOME/bin:$ANT_HOME/bin:$WL_HOME/server/bin:$PATH


#   Depend on your platform, set the path
#   for the dynamic library which need to
#   include the TUXEDO library
export LD_LIBRARY_PATH=$TUXDIR/lib:$LD_LIBRARY_PATH
export SHLIB_PATH=$TUXDIR/lib:$SHLIB_PATH
export LIBPATH=$TUXDIR/lib:$LIBPATH

