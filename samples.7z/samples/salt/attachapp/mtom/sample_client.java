/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
*/

package com.bea.salt.mtom.Carmap;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.ResourceBundle;

import javax.activation.FileDataSource;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.rpc.soap.SOAPFaultException;

import java.io.*;
import java.text.*;
import java.util.*;
import java.rmi.RemoteException;
import javax.xml.rpc.Stub;

public class Carmap_StubTest {

    private String              wsdlURI;
    private TuxedoWebService    service;
    private Carmap              port;
    private Stub                stub;
    private int                 bufLen;
    private FileWriter          out;
    private byte[]              reqbuf, repbuf;

    public static void main(String[] args) {
        Carmap_StubTest suite = new Carmap_StubTest();

        suite.mainloop(args);
        return;
    }

    public void mainloop(String[] args) {
        try {
            wsdlURI = "http://" +
                        System.getenv("GWWS_HOST").toString()
                        + ":" +
                        System.getenv("GWWS_PORT").toString();
            service = new TuxedoWebService_Impl();
            port    = service.getHTTP1();
            stub    = (Stub)port;
            stub._setProperty( Stub.ENDPOINT_ADDRESS_PROPERTY, wsdlURI );

            testCarmap();
        } catch (Exception e) {
            System.out.println( "Unexpected exception caught in function mainloop." );
            e.printStackTrace();
        }
        return;
    }

    private void testCarmap() {
        boolean ret = true;

        try {
            reqbuf = getCarrayBuffer(500);
            repbuf = port.overLongInput(reqbuf);
            System.out.println( "Run MTOM sample successfully." );
        } catch (Exception e) {
            System.out.println( "Unexpected exception caught" );
            e.printStackTrace();
        }
        return;
    }

    private byte[] getCarrayBuffer(int size) {
        byte [] carbuf = new byte[size];
        int     index  = 48;

        System.out.println("Allocated buffer size: "+ size);
        for (int j=0; j < size; j++) {
            carbuf[j] = (byte) index;
            if ( index == 57 ) {
                index = 48;
            }
            else {
                index ++;
            }
        }
        return carbuf;
    }
}

