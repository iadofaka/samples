/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
  
   ident "@(#) TuxWS/samples/obwsapp/calc/axis2server/src/sample/calc/Calculator.java	$Revision: 1.1 $"
*/

package sample.calc;

public class Calculator
{
  public int add(int i1, int i2) {
    return i1 + i2; 
  }
}
