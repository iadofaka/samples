/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
  
   ident "@(#) TuxWS/samples/obwsapp/calc/tux/client.c	$Revision: 1.2 $"
*/

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "atmi.h"
#include "fml32.h"
#include "userlog.h"
#include "calc.fml32.h"


#define NLONGS      4       /* Number of string fields */

#define LEN (NLONGS*sizeof(long))

void
usage(char *name)
{
  (void)fprintf(stderr, "Usage:\n %s i1 i2 ", name);
  (void)fprintf(stderr, "\n\twhere: i1 i2 are the input values\n");
  return;
}

int
main(int argc, char *argv[])
{
	FBFR32 *f, *fin;
	long len;
	FLDLEN32 len2;
	long ret_val, inputnum1, inputnum2;
	char *programName;
	int counter;
	
	if (argc != 3) {
		(void)usage(argv[0]);
		exit(1);
	}
	
	/*
	* Set the external variable proc_name (defined in userlog.h)
	* to be the name of the executable program so that it appears
	* in the Tuxedo ULOG entries for the client program.
	*/
	
	proc_name = argv[0];
	
	if (tpinit((TPINIT *)NULL) == -1) {
		(void)fprintf(stderr, "Failed to join application  -- %s\n",
			  tpstrerror(tperrno));
		(void)exit(1);
	}
	
	if ((f = (FBFR32 *)tpalloc("FML32", NULL, Fneeded32(NLONGS, LEN))) == NULL) {
		(void)fprintf(stderr, "Failure to allocate FML32 buffer -- %s\n",
			  tpstrerror(tperrno));
		(void)tpterm();
		(void)exit(1);
	}
	
	if ((fin = (FBFR32 *)tpalloc("FML32", NULL, Fneeded32(NLONGS, LEN/2))) == NULL) {
		(void)fprintf(stderr, "Failure to allocate FML32 buffer -- %s\n",
			  tpstrerror(tperrno));
		(void)tpterm();
		(void)exit(1);
	}
	
	
	inputnum1 = atoi(argv[1]);
	if (Fadd32(fin, param0, (char *)&inputnum1, 0) == -1) {
		(void)fprintf(stderr, "Failure to change param0 field -- %s\n",
		  	  Fstrerror32(Ferror32));
		(void)tpfree((char *)fin);
		(void)tpfree((char *)f);
		(void)tpterm();
		(void)exit(1);
	}
	
	inputnum2 = atoi(argv[2]);
	if (Fadd32(fin, param1, (char *)&inputnum2, 0) == -1) {
		(void)fprintf(stderr, "Failure to change param1 field -- %s\n",
		  	  Fstrerror32(Ferror32));
		(void)tpfree((char *)f);
		(void)tpfree((char *)fin);
		(void)tpterm();
		(void)exit(1);
	}

	if (Fadd32(f, add, (char *)fin, 0) == -1) {
		(void)fprintf(stderr, "Failure to change add field -- %s\n",
		  	  Fstrerror32(Ferror32));
		(void)tpfree((char *)f);
		(void)tpfree((char *)fin);
		(void)tpterm();
		(void)exit(1);
	}
		
	if (tpcall("add", (char *)f, 0, (char **)&f, &len, TPSIGRSTRT) == -1) {
		(void)fprintf(stderr, "Failure to call the add operation -- %s \n",
			  tpstrerror(tperrno));
		(void)tpfree((char *)f);
		(void)tpfree((char *)fin);
		(void)tpterm();
		(void)exit(1);
	}
	
	len2 = Fsizeof32(fin);
	if (Fget32(f, addResponse, 0, (char *)fin, &len2) == -1) {
		(void)fprintf(stderr, "Failure to call get the result field -- %s \n",
			  Fstrerror32(Ferror32));
		(void)tpfree((char *)f);
		(void)tpfree((char *)fin);
		(void)tpterm();
		(void)exit(1);
	}

	if (Fget32(fin, ws_result, 0, (char *)&ret_val, &len2) == -1) {
		(void)fprintf(stderr, "Failure to call get the result field -- %s \n",
			  Fstrerror32(Ferror32));
		(void)tpfree((char *)f);
		(void)tpfree((char *)fin);
		(void)tpterm();
		(void)exit(1);
	}

	
	(void)fprintf(stdout, "The result of (%ld + %ld) is: %ld\n", inputnum1, inputnum2, ret_val);
	
	(void)tpfree((char *)f);
	(void)tpfree((char *)fin);
	(void)tpterm();
	return(0);
}
