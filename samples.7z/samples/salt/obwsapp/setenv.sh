#	(c) 2007 BEA Systems, Inc. All Rights Reserved.
#	Copyright (c) 2007 BEA Systems, Inc.	
#	All Rights Reserved 	 
#
#	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF 
#	BEA Systems, Inc.  
#	The copyright notice above does not evidence any  
#	actual or intended publication of such source code.
#
#	ident	"@(#) samples/obwsapp/calc/setenv.sh	$Revision: 1.4 $"


# Setup environment for Java, ANT, AXIS2
export JAVA_HOME=<full path of JDK installation directory> 
export ANT_HOME=<full path of ANT installation directory>
export AXIS2_HOME=<full path of AXIS2 installation directory>
export AXIS2_SERVER_HOST=localhost
export AXIS2_SERVER_PORT=8080

# Setup environment for Tuxedo and SALT
export TUXDIR=<full path of Tuxedo software>
export HOSTNAME=`uname -n`
export IPCKEY=56789

#
export LD_LIBRARY_PATH=$TUXDIR/lib:$LD_LIBRARY_PATH
export SHLIB_PATH=$TUXDIR/lib:$SHLIB_PATH
export LIBPATH=$TUXDIR/lib:$LIBPATH

#   You must set the C/C++ compiler path in PATH.
export PATH=$TUXDIR/bin:$ANT_HOME/bin:$AXIS2_HOME/bin:$JAVA_HOME/bin:$APPDIR:$PATH
export LANG=C

