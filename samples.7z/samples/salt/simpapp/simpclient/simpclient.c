/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved

   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

/* #ident    "@(#) TuxWS/samples/simpapp/simpclient/simpclient.c    $Revision: 1.18 $" */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __OS400__
#include <iconv.h>
#include <errno.h>
#endif

    /**
     *
     */
#ifdef _WIN32
    #include <winsock2.h>
    typedef unsigned long in_addr_t;
    #define NETERROR WSAGetLastError()
#else
    #include <errno.h>
    #include <unistd.h>
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netdb.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>

    #ifndef SOCKET
        #define SOCKET int
    #endif

    #ifndef INVALID_SOCKET
        #define INVALID_SOCKET  -1
    #endif

    #ifndef SOCKET_ERROR
        #define SOCKET_ERROR    -1
    #endif

    #define NETERROR errno
#ifdef __OS400__
    typedef unsigned long in_addr_t;
#endif
#endif  /* End of #ifdef _WIN32 */



    /**
     *
     */
static const char *HEADER1=
    "POST /simpapp HTTP/1.1\r\n"
    "Host: ";

static const char *HEADER2=
    "\r\n"
    "User-Agent: gSOAP/2.7\r\n"
    "Content-Type: text/xml; charset=utf-8\r\n"
    "Content-Length: ";

static const char *HEADER3=
    "\r\n"
    "Connection: close\r\n"
    "SOAPAction: \"ToUpperWS\"\r\n"
    "\r\n";

static const char *CONTENT1=
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\r"
    "<SOAP-ENV:Envelope \n\r"
        "\txmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n\r"
        "\t<SOAP-ENV:Body>\n\r"
            "\t\t<ns1:ToUpperWS xmlns:ns1=\"urn:pack.simpapp_typedef.salt11\">\n\r"
                "\t\t\t<ns1:inbuf>";

static const char *CONTENT2=
                "</ns1:inbuf>\n\r"
            "\t\t</ns1:ToUpperWS>\n\r"
        "\t</SOAP-ENV:Body>\n\r"
    "</SOAP-ENV:Envelope>\n\r";


static const char *RESULT_START = "<tuxedo:outbuf>";
static const char *FAULT_CODE   = "<faultcode>"    ;
static const char *FAULT_STRING = "<faultstring>"  ;
static const char *LINE         = "---------------------------------------------------------------------------";

#ifdef __OS400__

#define _GP_TOASCII                    ((int)(0x0002))
#define _GP_FROMASCII                  ((int)(0x0004))   

static char * textconvert(char *po, char *pi, long ilen, int mode){

	int ret;
	char *lo, *li;
	size_t len, olen, cvtret;
	char tocode[32], fromcode[32];

	iconv_t cFD;
	
	memset(tocode, 0, sizeof(tocode));
	memset(fromcode, 0, sizeof(fromcode));

	if (mode & _GP_TOASCII) {
		strcpy(tocode, "IBMCCSID00850");
		strcpy(fromcode, "IBMCCSID000370000100");
	}
	else{
		strcpy(tocode, "IBMCCSID00037");
		strcpy(fromcode, "IBMCCSID008500000100");
	}
	cFD = iconv_open(tocode, fromcode);
	
	if (cFD.return_value == -1){
		printf("iconv_open failed, errno = %d\n", errno);
		return NULL;
	}

	li = pi;
	lo = po;
	len = olen = (size_t)ilen;

	ret = iconv(cFD,&li,&len,&lo,&olen);
	if (ret == (size_t)-1) {
		printf("iconv failed, errno = %d\n", errno);
		ret = iconv_close(cFD);
		return NULL;
	}

	ret = iconv_close(cFD);
	
	return po;
}
#endif

    /**
     *
     */
int main ( int argc, char **argv )
{
#ifdef _WIN32
    WSADATA             wsaData;
#endif

    int                 retval;
    SOCKET              conn_socket = INVALID_SOCKET;
    struct sockaddr_in  addr;
    struct hostent     *host;
    in_addr_t           addr_num;
    char               *ret_buf;
    int                 received,
                        ret_len ;
    char               *ret_str,
                       *ret_end;

    if( ( 4 > argc ) || ( 5 < argc ) || ( 5 == argc ) && ( strcmp( argv[4], "-v" ) ) )
    {
        (void) printf ("Usage : %s <host> <port> <string> [-v]\n", argv[0]);
        (void) printf ("\twhere -v indicates request and response HTTP packages should be output\n");
        return -1;
    }

#ifdef _WIN32
    /* Load Winsock */
    if( 0 != ( retval = WSAStartup( MAKEWORD(2,2), &wsaData ) ) )
    {
        (void) fprintf (stderr, "WSAStartup failed with error %d\n", retval);
        WSACleanup();
        return -1;
    }
#endif

    /**
     *  Get the socket.
     */
    conn_socket = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
    if( INVALID_SOCKET == conn_socket )
    {
        (void) fprintf (stderr, "socket failed: %d\n", NETERROR);
        goto cleanup;
    }

    /**
     *  Set the address.
     */
    (void) memset( &addr, 0, sizeof (addr) );
    addr.sin_family = AF_INET;
    addr.sin_port   = htons( atoi(argv[2]) );

    host = gethostbyname( argv[1] );
    if( NULL != host )
    {
        addr_num = ( ( host->h_addr[0] << 24 ) & 0xff000000 ) |
                   ( ( host->h_addr[1] << 16 ) & 0xff0000   ) |
                   ( ( host->h_addr[2] <<  8 ) & 0xff00     ) |
                   (   host->h_addr[3] & 0xff );
    } else {
        addr_num = htonl( inet_addr( argv[1] ) );
    }

#if defined (_AIX) || defined (__hpux) || defined (__OS400__)
    addr.sin_addr.s_addr = addr_num;
#elif defined (__linux)
    addr.sin_addr = *( (struct in_addr *)host->h_addr );
    bzero( &( addr.sin_zero ), 8 );
#else
    addr.sin_addr.S_un.S_un_b.s_b1 = (unsigned char) ( ( addr_num >> 24 ) & 0xff );
    addr.sin_addr.S_un.S_un_b.s_b2 = (unsigned char) ( ( addr_num >> 16 ) & 0xff );
    addr.sin_addr.S_un.S_un_b.s_b3 = (unsigned char) ( ( addr_num >>  8 ) & 0xff );
    addr.sin_addr.S_un.S_un_b.s_b4 = (unsigned char) ( addr_num & 0xff );
#endif

    /**
     *  Connect to the server.
     */
    retval = connect( conn_socket, (struct sockaddr*)&addr, sizeof(addr) );
    if( SOCKET_ERROR == retval )
    {
        (void) fprintf( stderr, "connect failed : %d\n", NETERROR );
        goto cleanup;
    }


    /**
     *  Compose the request package.
     */
    ret_len = 10000;
    ret_buf = (char *)malloc( ret_len+1 );
    if( NULL == ret_buf )
    {
        (void) fprintf( stderr, "Memory run out\n" );
        goto cleanup;
    }


    (void) sprintf( ret_buf,
                        "%s%d.%d.%d.%d:%d%s%d%s%s%s%s",
                        HEADER1,
                        ( addr_num >> 24 ) & 0xff,
                        ( addr_num >> 16 ) & 0xff,
                        ( addr_num >>  8 ) & 0xff,
                        addr_num & 0xff,
                        ntohs( addr.sin_port ),
                        HEADER2,
                        (int)( strlen(CONTENT1) + strlen(argv[3]) + strlen (CONTENT2) ),
                        HEADER3,
                        CONTENT1,
                        argv[3],
                        CONTENT2 );

    /**
     *  Output request package if demanded.
     */
    if( 5 == argc )
    {
        (void) printf ("Request Package\n%s\n%s%s\n\n", LINE, ret_buf, LINE);
    }

#ifdef __OS400__
	(void)textconvert(ret_buf, ret_buf, strlen(ret_buf), _GP_TOASCII);
#endif

    /**
     *  Send the request.
     */
    retval = send( conn_socket, ret_buf, (int)strlen (ret_buf), 0 );
    if( SOCKET_ERROR == retval )
    {
        (void) fprintf( stderr, "send failed: error %d\n", NETERROR );
        free (ret_buf);
        goto cleanup;
    }

    /**
     *  Receive the response.
     */
    for( received = 0;
         0 < ( retval=recv( conn_socket, ret_buf+received, ret_len, 0 ) );
         received += retval, ret_len -= retval );

    if( 0 > retval )
    {
        (void) printf ("recv failed : %d\n", NETERROR);
        free (ret_buf);
        goto cleanup;
    }

    ret_buf[received] = '\0';

#ifdef __OS400__
	(void)textconvert(ret_buf, ret_buf, received, _GP_FROMASCII);
#endif

    if( 5 == argc )
    {
        (void) printf ("Response Package\n%s\n%s\n%s\n\n", LINE, ret_buf, LINE);
    }

    /**
     *  Locate the result string in the response.
     */
    ret_str = strstr( ret_buf, RESULT_START );
    if( NULL != ret_str )
    {
        ret_str += strlen( RESULT_START );
        ret_end  = strchr( ret_str, '<' );
        if( NULL != ret_end )
        {
            *ret_end = '\0';
        }

        (void) printf( "ToUpper Returns: %s\n", ret_str );
    }
    else
    {
        (void) printf( "ERROR Returned.\n" );
        ret_str = strstr( ret_buf, FAULT_CODE );
        if( NULL != ret_str )
        {
            char *tmp;
            ret_str += strlen( FAULT_CODE );
            tmp      = strchr( ret_str, '<' );
            if( NULL != tmp )
            {
                *tmp = '\0';
                (void) printf( "faultcode : %s\n", ret_str );
                ret_str = strstr( tmp+1, FAULT_STRING );
                if( NULL != ret_str )
                {
                    ret_str += strlen( FAULT_STRING );
                    tmp = strchr( ret_str, '<' );
                    if( NULL != tmp )
                    {
                        *tmp = '\0';
                        (void) printf( "faultstring : %s\n", ret_str );
                    }
                }
            }
            else
            {
                (void) printf( "Please use '-v' option to check the packages.\n" );
            }
        }
        else
        {
            (void) printf( "Please use '-v' option to check the packages.\n" );
        }
    }

    free (ret_buf);

    /**
     *  Clean up the client connection.
     */
cleanup:
    if (conn_socket != INVALID_SOCKET)
    {
      #ifdef _WIN32
        retval = shutdown (conn_socket, SD_SEND);
        if( retval == SOCKET_ERROR )
        {
            (void) fprintf( stderr, "shutdown failed: %d\n", WSAGetLastError() );
        }
        retval = closesocket (conn_socket);
        if( retval == SOCKET_ERROR )
        {
            (void) fprintf( stderr, "closesocket failed: %d\n", WSAGetLastError() );
        }
      #else
        (void) close (conn_socket);
      #endif
        conn_socket = INVALID_SOCKET;
    }

  #ifdef _WIN32
    WSACleanup();
  #endif

    return 0;
}

