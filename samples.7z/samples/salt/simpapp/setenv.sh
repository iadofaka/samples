#############################################################
#   Copyright (c) 2007 BEA Systems, Inc.
#   All rights reserved
#
#   THIS IS UNPUBLISHED PROPRIETARY
#   SOURCE CODE OF BEA Systems, Inc.
#   The copyright notice above does
#   not evidence any actual or intended
#   publication of such source code.
#
#	ident	"@(#) TuxWS/samples/simpapp/setenv.sh	$Revision: 1.12 $"

# ---------------------------------------------------------
# Set Tuxedo home directory.
# Example: TUXDIR=/home/tuxedo
export TUXDIR=

# ---------------------------------------------------------
# Set JDK and Apache Ant home directory
# Example: JDKHOME=/path/libs/jdk1.8.0_231
#          ANT_HOME=/path/libs/apache-ant-1.8.1
export JAVA_HOME=
export ANT_HOME=


# -----
# Set the WebLogic home directory.
# Example: WL_HOME=/home/wlsrv10
export WL_HOME=

# -----
# Set the Axis2/Java home directory.
# Example: AXIS2_HOME=/home/axis2
export AXIS2_HOME=


# ---------------------------------------------------------
# Set the sample work directory.
# Example: APPDIR=/home/tuxedo/salt/me/simpapp/work
export APPDIR=`pwd`/work

# ---------------------------------------------------------
# Set some environment parameter of tuxedo server.
export TUXCONFIG=$APPDIR/tuxconfig
export SALTCONFIG=$APPDIR/saltconfig


# ---------------------------------------------------------
# You must set the C/C++ compiler path in PATH.
#
export PATH=.:$TUXDIR/bin:$JAVA_HOME/bin:$ANT_HOME/bin:$WL_HOME/server/bin:%AXIS2_HOME/bin:$PATH

# ---------------------------------------------------------
export LANG=C


# ---------------------------------------------------------
# Set Tuxedo Metadata Repository input text and
# output binary file parameters.
export REPOS_IN_NAME=mdr_simpapp.mif
export REPOS_OUT_NAME=mdr_simpapp.repos

# ---------------------------------------------------------
# Set library path.
export LD_LIBRARY_PATH=${TUXDIR}/lib:${LD_LIBRARY_PATH}
export SHLIB_PATH=${TUXDIR}/lib:${SHLIB_PATH}
export LIBPATH=$TUXDIR/lib:${LIBPATH}


# ---------------------------------------------------------
# Set some Tuxedo server environment parameters.
export IPCKEY=
export GWWS_HOST=`uname -n`
export GWWS_PORT=



