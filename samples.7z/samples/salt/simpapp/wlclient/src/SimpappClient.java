/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

/* #ident	"@(#) TuxWS/samples/simpapp/wlclient/SimpappClient.java	$Revision: 1.5 $" */

package com.bea.salt.examples.simpapp.wlclient;

import java.util.Random;
import java.util.Properties;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.*;
import java.rmi.RemoteException;
import javax.xml.rpc.Stub;



public class SimpappClient {

    public static void main(String[] args) throws Exception {
        TuxedoWebService service;
        Simpapp_PortType port;

        if( args.length < 1 )
        {
            System.out.println( "Please specify the string to tansfer." );
            return;
        }

        service = new TuxedoWebService_Impl();
        port = service.getSimpapp_GWWS1_HTTPPort();
        System.out.println( "ToUpper Returns: " + port.toUpperWS(args[0]) );
    }

}
