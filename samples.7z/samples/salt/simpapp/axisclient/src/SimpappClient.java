/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c) 2007 BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/
/* #ident	"@(#) TuxWS/samples/simpapp/axisclient/SimpappClient.java	$Revision: 1.4 $" */

package com.bea.salt.examples.simpapp.axis2client;

public class SimpappClient {
    
    public static void main(String [] args) {
        try {
            String send = "Hello World!";

            TuxedoWebServiceStub            stub    = new TuxedoWebServiceStub();
            TuxedoWebServiceStub.ToUpperWS  request = new TuxedoWebServiceStub.ToUpperWS();

            request.setInbuf( send );

            TuxedoWebServiceStub.ToUpperWSResponse
                                            response = stub.ToUpperWS( request );

            String  ret = response.getOutbuf();
            System.out.println( "Sent '" + send + "'" );
            System.out.println( "Got  '" + ret  + "'" );
        } catch (Exception e) {
            System.err.println( e.toString() );
        }
    }
}
