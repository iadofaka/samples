/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/* Copyright (c)  2007  BEA Systems, Inc.
 *    All rights reserved
 *     
 *        THIS IS UNPUBLISHED PROPRIETARY
 *        SOURCE CODE OF BEA Systems, Inc.
 *        The copyright notice above does not evidence any actual or intended
 *        publication of such source code.
 *                    
 * ident "@(#) samples/datatypeapp/wlclient/client.java	$Revision: 1.13 $"
 */
import java.util.Random;
import java.util.Properties;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.*;
import java.rmi.RemoteException;
import javax.xml.rpc.Stub;
import salt11.tuxall_typedef.pack.*;
import com.bea.salt.examples.datatype.*;

public class client {
    private String              wsdlURI;
    private TuxedoWebService    service;
    private TuxAll_PortType     port;
    private Stub                stub;

    public void run() throws Exception {
        Properties saltProps = new Properties();
        saltProps.load(new FileInputStream("datatype.properties"));
        wsdlURI = "http://" + saltProps.get("HOSTNAME").toString()
                            + ":"
                            + saltProps.get("GWWSPORT").toString()
                            + "/"
                            + saltProps.get("SERVICE_INSTANCE").toString();
        service = new TuxedoWebService_Impl();
        port    = service.getTuxAll_TuxAll_HTTPPort();
        stub    = (Stub)port;
        stub._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, wsdlURI);
        try {
            todo();
        } catch( Exception e) {
        }
    }

    public void todo() throws Exception {
        Fml32_QUERY_In          req = new Fml32_QUERY_In();
        Fml32_QUERY_Out         rep;
        byte                    chartemp;
        short                   shorttemp;
        float                   floattemp;
        View32_QUERY_In_Tv32_T  view = new View32_QUERY_In_Tv32_T();
        View32_QUERY_Out_Tv32_T vw;

        try {
            chartemp  = 'A';
            shorttemp = 77;
            floattemp = 3;
            req.setTf32Char(chartemp);
            req.setTf32Shrt(shorttemp);
            req.setTf32Flat(floattemp);
            chartemp  = 'B';
            shorttemp = 88;
            floattemp = 4;
            view.setTv32Char(chartemp);
            view.setTv32Shrt(shorttemp);
            view.setTv32Flat(floattemp);
            req.setTf32V32(view);
            rep = port.qUERY(req);
            System.out.println(rep.getTf32Char());
            System.out.println(rep.getTf32Shrt());
            System.out.println(rep.getTf32Flat());
            vw = rep.getTf32V32();
            System.out.println(vw.getTv32Char());
            System.out.println(vw.getTv32Shrt());
            System.out.println(vw.getTv32Flat());
        } catch (Exception e) {
            System.out.println("Invoke Service exception." + e.getMessage());
        }
    }

    public static void main(String[] args) {
        client clt = new client();

        try {
            clt.run();
        } catch( Exception e) {
        }
        return;
    }
}
