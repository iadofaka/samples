/*
 * (c) 2007 BEA Systems, Inc. All Rights Reserved.
 * Copyright (c)  2007  BEA Systems, Inc.
 *    All rights reserved
 *
 *        THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BEA Systems, Inc.
 *        The copyright notice above does not evidence any actual or intended
 *        publication of such source code.
 *
 * ident "@(#) TuxWS/samples/datatypeapp/tux/dataserver.c	$Revision: 1.4 $"
 */

#include <stdio.h>
#include <ctype.h>
#include <malloc.h>

#include "fml32.h"      /* TUXEDO Header File */
#include "atmi.h"       /* TUXEDO Header File */
#include "userlog.h"    /* TUXEDO Header File */
#include "tv32.h"

#ifdef __cplusplus
extern "C"
{
#endif


#define BUFFERLEN 4096


    /**
     *  These function performs the actual service requested
     *  by the client.
     *  Its argument is a structure containing among other
     *  things a pointer to the data buffer, and the length
     *  of the data buffer.
     */
#if defined(__STDC__)
void query(TPSVCINFO *rqst)
#else
void query(rqst)
    TPSVCINFO *rqst;
#endif
{
    FLDID32         fieldid32 = 0;
    FBFR32         *fbfr32;
    char           *ptr;
    int             loop;
    short           sss;
    FLDLEN32        len32;
    FVIEWFLD       *viewfld = NULL;
    struct tv32_t  *tv32;

    userlog( "Enter the server, method query.%d\n", rqst->len );

    fbfr32 = (FBFR32 *)rqst->data;
    len32  = BUFFERLEN;
    if( NULL == ( ptr = (char *)malloc(BUFFERLEN) ) )
    {
        userlog("Malloc failed.");
        tpreturn(TPFAIL, 0, rqst->data, rqst->len, 0);
    }

    fieldid32 = Fldid32("tf32char");
    if( 0 > Fget32( fbfr32, fieldid32, 0, ptr, &len32 ) )
    {
        userlog("1.Fget32 error. Ferror32=%d.\n",Ferror32);
        tpreturn(TPFAIL, 0, rqst->data, rqst->len, 0);
    }
    userlog( "==SERVER== 1.Input value's length is: %d\n", len32 );
    userlog( "==SERVER== 1.Input value is: %c\n", *ptr );

    len32     = BUFFERLEN;
    fieldid32 = Fldid32("tf32shrt");
    if( 0 > Fget32( fbfr32, fieldid32, 0, ptr, &len32 ) )
    {
        userlog("2.Fget32 error. Ferror32=%d.\n",Ferror32);
        tpreturn(TPFAIL, 0, rqst->data, rqst->len, 0);
    }
    userlog( "==SERVER== 2.Input value's length is: %d\n", len32        );
    userlog( "==SERVER== 2.Input value is: %d\n"         , *(short*)ptr );

    len32     = BUFFERLEN;
    fieldid32 = Fldid32("tf32flat");
    if( 0 > Fget32( fbfr32, fieldid32, 0, ptr, &len32 ) )
    {
        userlog("3.Fget32 error. Ferror32=%d.\n",Ferror32);
        tpreturn(TPFAIL, 0, rqst->data, rqst->len, 0);
    }
    userlog( "==SERVER== 3.Input value's length is: %d\n", len32 );
    userlog( "==SERVER== 3.Input value is: %10f\n", *(float*)ptr );

    len32     = BUFFERLEN;
    fieldid32 = Fldid32("tf32v32");
    if( NULL == ( ptr = Fgetalloc32( fbfr32, fieldid32, 0, &len32 ) ) )
    {
        userlog("Fgetalloc32 failed.");
        tpreturn(TPFAIL, 0, rqst->data, rqst->len, 0);
    }

    viewfld = (FVIEWFLD *)ptr;
    tv32    = (struct tv32_t *)viewfld->data;
    userlog( "==SERVER== 4.Returned value is: %c\n"  , tv32->tv32char );
    userlog( "==SERVER== 5.Returned value is: %d\n"  , tv32->tv32shrt );
    userlog( "==SERVER== 6.Returned value is: %10f\n", tv32->tv32flat );
    free(ptr);
    tpreturn( TPSUCCESS, 0, rqst->data, rqst->len, 0 );
}



    /**
     *  tpsvrinit is executed when a server is booted, before
     *  it begins processing requests.  It is not necessary
     *  to have this function.
     *  Also available is tpsvrdone (not used in this example),
     *  which is called at server shutdown time.
     */
#if defined(__STDC__)
int tpsvrinit(int argc, char *argv[])
#else
int tpsvrinit(argc, argv)
    int     argc;
    char  **argv;
#endif
{
    /* Some compilers warn if argc and argv aren't used. */
    argc = argc;
    argv = argv;
    /* userlog writes to the central TUXEDO message log */
    return 0;
}

#ifdef __cplusplus
}
#endif


