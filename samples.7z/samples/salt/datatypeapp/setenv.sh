#!/bin/ksh

#############################################################
#   Copyright (c) 2007 BEA Systems, Inc.
#   All rights reserved
#
#   THIS IS UNPUBLISHED PROPRIETARY
#   SOURCE CODE OF BEA Systems, Inc.
#   The copyright notice above does
#   not evidence any actual or intended
#   publication of such source code.
#
#	ident	"@(#) TuxWS/samples/datatypeapp/setenv.sh	$Revision: 1.15 $"


# ---------------------------------------------------------------
# JDK, Apache Ant and Weblogic version are required.
# See README for version details.
TUXDIR=<Your Tuxedo directory>
JAVA_HOME=<Your Java Home directory>
ANT_HOME=<Your Ant Home directory>
WL_HOME=<Your Weblogic Home Directory>
#
export TUXDIR JAVA_HOME ANT_HOME WL_HOME

# ---------------------------------------------------------------
APPDIR=`pwd`/work
TUXCONFIG=$APPDIR/tuxconfig
SALTCONFIG=$APPDIR/saltconfig
#
export APPDIR TUXCONFIG SALTCONFIG


# ---------------------------------------------------------------
export LANG=C


# ---------------------------------------------------------------
TPMBENC=UTF-8
VIEWDIR32=$APPDIR
FLDTBLDIR32=$APPDIR
FIELDTBLS32=tf32.fml32
VIEWFILES32=tv32.V
export TPMBENC VIEWDIR32 FLDTBLDIR32 FIELDTBLS32 VIEWFILES32


# ---------------------------------------------------------------
GWWS_HOST=`uname -n`
GWWS_PORT=<Your GWWS listen port>
IPCKEY=<Your IPC key>
export GWWS_HOST GWWS_PORT IPCKEY

#
# Set Tuxedo Metadata Repository input text and
# output binary file parameters.
export REPOS_IN_NAME=mdr_datatypeapp.mif
export REPOS_OUT_NAME=mdr_datatypeapp.repos


# ---------------------------------------------------------------
# Set library path.
LD_LIBRARY_PATH=${TUXDIR}/lib:${LD_LIBRARY_PATH}
SHLIB_PATH=${TUXDIR}/lib:${SHLIB_PATH}
LIBPATH=$TUXDIR/lib:/usr/lib:${LIBPATH}

# ---------------------------------------------------------------
# You must set the C/C++ compiler path in PATH.
PATH=.:${TUXDIR}/bin:${JAVA_HOME}/bin:${ANT_HOME}/bin:${PATH}
#
export LD_LIBRARY_PATH LIBPATH SHLIB_PATH PATH



