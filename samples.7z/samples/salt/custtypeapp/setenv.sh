#   (c) 2007 BEA Systems, Inc. All Rights Reserved.
#   Copyright (c) 2007  BEA Systems, Inc.
#   All Rights Reserved

#   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
#   BEA Systems, Inc.
#   The copyright notice above does not evidence any
#   actual or intended publication of such source code.

export GWWS_HOST=@Your Host Name, Do not Use IP Address@
export GWWS_PORT=@Your HTTP Listen Port@
export IPCKEY=@Your Tuxedo application IPCKEY@
export TUXDIR=@Your Tuxedo Installed Directory@
export JAVA_HOME=@Your Java Home Directory@
export WL_HOME=@Your WebLogic Home Directory@
export ANT_HOME=@Your ANT Home Directory@

#
# shared library suffix for your platform
# AIX     : ".so"
# Solaris : ".so"
# Linux   : ".so"
# HPUX    : ".sl"
#
export DLL_SUFFIX=@dll suffix for various platforms@

export MAKE=@gmake or make on your platform@

#
# makefile to be used for your platform
# e.g. Solaris-makefile.sol ; AIX-makefile.aix 
#
export MAKEFILE=@make file name to be used for your platform@

#
# Set environment variables for Compiling Tuxedo applications
#
export PATH=@PATH where can find your C/C++ compilers and make command@:$PATH


export PATH=$TUXDIR/bin:$JAVA_HOME/bin:$ANT_HOME/bin:$WL_HOME/server/bin:$PATH
export LD_LIBRARY_PATH=$TUXDIR/lib:$LD_LIBRARY_PATH
export SHLIB_PATH=$TUXDIR/lib:$SHLIB_PATH
export LIBPATH=$TUXDIR/lib:$LIBPATH

