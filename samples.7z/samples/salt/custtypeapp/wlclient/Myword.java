/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved
    
    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

package com.bea.salt.examples.custtypeapp.wlclient;

import java.lang.Integer;
import java.lang.NumberFormatException;
import java.util.StringTokenizer;
import java.util.Random;
import java.util.Properties;
import java.util.Date;
import java.text.DecimalFormat;
import java.io.*;
import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;
import salt11.custmap_typedef.pack.*;
import org.example.myword.*;

public class Myword {

    public static void main(String[] args) {

        TuxedoWebService service;
        Custmap_Porttype port;

        try {
            String  strlang, strEnglish;

            if ( args.length != 2 ) {
                System.out.println("\nPlease specify english word to translate:");
                BufferedReader b = new BufferedReader( new InputStreamReader(System.in) );
                strEnglish = b.readLine();

                System.out.println("\nPlease specify target language:");
                b = new BufferedReader( new InputStreamReader(System.in) );
                strlang = b.readLine();
            } else {
                strlang    = args[1];
                strEnglish = args[0];
            }

            service = new TuxedoWebService_Impl();
            port    = service.getCustmap_Port();

            // prepare the request message
            Languages tolang = Languages.fromValue(strlang);
            Translated tran = new Translated();
            tran.setLang(tolang);
            tran.set_value("");
            TMyword word = new TMyword();
            word.setEnglish(strEnglish);
            word.setTranslated(tran);

            Inbuf_Element1 snd = new Inbuf_Element1();
            snd.setMyword(word);
            
            // call the actual service
            Outbuf_Element2 rcv = port.mYWORD(snd);

            if ( rcv == null || rcv.getMyword() == null ) {
                throw new Exception("Cannot get result from service myword");
            }

            if ( rcv.getMyword().getError() != null ) {
                throw new Exception(rcv.getMyword().getError());
            }

            System.out.println("===================================");
            System.out.println("English   : " + rcv.getMyword().getEnglish() );
            System.out.println("===================================");
            System.out.println( rcv.getMyword().getTranslated().getLang() + "   : " + rcv.getMyword().getTranslated().get_value() );
            System.out.println("===================================");
        } catch (NumberFormatException e) {
            System.out.println(e + "\nplease rerun the program.");
        } catch (Exception e) {
            System.out.println("Exception : " + e);
        }
    }
}
