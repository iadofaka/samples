/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved
    
    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

package com.bea.salt.examples.custtypeapp.wlclient;

import java.lang.Integer;
import java.lang.NumberFormatException;
import java.util.StringTokenizer;
import java.util.Random;
import java.util.Properties;
import java.util.Date;
import java.text.DecimalFormat;
import java.io.*;
import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;
import salt11.custmap_typedef.pack.*;
import org.example.employees.*;

public class GetEmployee {

    public static void main(String[] args) {

        TuxedoWebService service;
        Custmap_Porttype port;

        try {
            service = new TuxedoWebService_Impl();
            port    = service.getCustmap_Port();

            // prepare an empty request for all employees retrieve
            Fml32_GETEMPLOYEE_In snd = new Fml32_GETEMPLOYEE_In();
            snd.setF_NAME("");
            
            // call the actual service
            Outbuf_Element1 rcv = port.gETEMPLOYEE(snd);

            if ( rcv == null || rcv.getEMPLOYEES() == null ) {
                throw new Exception("Cannot get result from service employee");
            }

            TEmployees  temp = rcv.getEMPLOYEES();
            Employee [] emps = temp.getEmployee();

            System.out.println("===================================");
            System.out.println("Employee matched  : " + emps.length );
            System.out.println("===================================");

            for ( int i = 0 ; i < emps.length ; i++ ) {
                System.out.println(emps[i].getName() + "\t" + emps[i].getGender() + "\t" + emps[i].getType() 
                                    + "\t" + emps[i].getEmpno() + "\t" + emps[i].getDepartment() );
            }
        } catch (NumberFormatException e) {
            System.out.println(e + "\nplease rerun the program.");
        } catch (Exception e) {
            System.out.println("Exception : " + e);
        }
    }
}
