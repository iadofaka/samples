/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

package com.bea.salt.examples.custtypeapp.wlclient;

import java.lang.Integer;
import java.lang.NumberFormatException;
import java.util.StringTokenizer;
import java.util.Random;
import java.util.Properties;
import java.util.Date;
import java.text.DecimalFormat;
import java.io.*;
import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;
import salt11.custmap_typedef.pack.*;
import org.example.point24.TPoint24;

public class Calc24 {

    public static void main(String[] args) {
        TuxedoWebService service;
        Custmap_Porttype port;

        try {

            int [] pokernums = new int[4];

            if ( args.length != 4 ) {

                System.out.println("\nPlease specify 4 numbers([1-13]) as input:");
                BufferedReader b = new BufferedReader( new InputStreamReader(System.in) );
                String getInput = b.readLine();
                int  gotnum = 0;

                if ( getInput != null && !getInput.equals("") ) {
                    StringTokenizer tokenizer = new StringTokenizer(getInput, " ");
                    while( tokenizer.hasMoreTokens() ) {
                        String p = tokenizer.nextToken();
                        int value = Integer.parseInt(p);
                        if ( value < 1 || value > 13 )
                            throw new NumberFormatException("Not all specified numbers in range [1-13]");

                        if ( gotnum < 4 )
                            pokernums[gotnum++] = value;
                        else
                            gotnum++;
                    }
                }

                if ( gotnum != 4 ) {
                    throw new NumberFormatException("4 numbers are required");
                }
            } else {
                for ( int i = 0 ; i < 4 ; i++ ) {
                    pokernums[i] = Integer.parseInt(args[i]);
                        if ( pokernums[i] < 1 || pokernums[i] > 13 )
                            throw new NumberFormatException("Not all specified numbers in range [1-13]");
                }
            }

            service = new TuxedoWebService_Impl();
            port = service.getCustmap_Port();

            // prepare the request message
            TPoint24 p24 = new TPoint24();
            p24.setP(pokernums);

            Inbuf_Element snd = new Inbuf_Element();
            snd.setPoint24(p24);
            
            // call the actual service
            Outbuf_Element rcv = port.cALC24(snd);

            if ( rcv == null || rcv.getPoint24() == null ) {
                throw new Exception("Cannot get result from service calc24");
            }

            if ( rcv.getPoint24().getP() == null ) {
                throw new Exception("Cannot deserialize XML data into Java object");
            }

            System.out.println("===================================");
            System.out.println("Poker   Number : " + 
                                rcv.getPoint24().getP()[0] + "  " + 
                                rcv.getPoint24().getP()[1] + "  " + 
                                rcv.getPoint24().getP()[2] + "  " + 
                                rcv.getPoint24().getP()[3] );

            String[] formulas = rcv.getPoint24().getFormula();
            if ( formulas == null ) {
                System.out.println("No available Result");
                System.out.println("===================================");
            } else {
                System.out.println("Result  Number : " + formulas.length);
                System.out.println("===================================");
                DecimalFormat fmt = new DecimalFormat("000");
                for ( int i = 0 ; i < formulas.length ; i++ ) {
                    String seq = fmt.format(i);
                    System.out.println("Formula No." + seq + " : " + formulas[i]);
                }
            }
        } catch (NumberFormatException e) {
            System.out.println(e + "\nplease rerun the program.");
        } catch (Exception e) {
            System.out.println("Exception : " + e);
        }
    }
}
