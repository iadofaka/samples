/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */


/* ident "@(#) samples/salt/custtypeapp/tuxserver/myword.c    $Revision: 1.3 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>   /* TUXEDO Header File */
#include <userlog.h>    /* TUXEDO Header File */

int main(int argc, char **argv)
{
    char * sendbuf, * rcvbuf;
    long sendlen, rcvlen;
    int ret;

    if ( argc !=3 ) {
        fprintf(stderr, "Usage : %s english_word language_to_translate.\n",
                        argv[0]);
        exit(1);
    }

    /* Attach to System/T as a Client Process */
    if (tpinit((TPINIT *) NULL) == -1) {
        (void) fprintf(stderr, "Tpinit failed\n");
        exit(1);
    }

    /* Allocate FML32 buffers for the request and the reply */
    if((sendbuf = tpalloc("XML", NULL, 4096)) == NULL) {
        (void) fprintf(stderr,"Error allocating send buffer\n");
        tpterm();
        exit(1);
    }

    sprintf(sendbuf, "\
<\?xml version=\"1.0\" encoding=\"UTF-8\"\?>\n\
<Myword xmlns=\"http://www.example.org/myword\">\n\
\t<English>%s</English>\n\
\t<Translated lang=\"%s\"></Translated>\n\
</Myword>", argv[1], argv[2]);

    sendlen = strlen(sendbuf);

    rcvlen = 4096;
    if((rcvbuf = tpalloc("XML", NULL, rcvlen)) == NULL) {
        (void) fprintf(stderr,"Error allocating receive buffer\n");
        tpfree((char *)sendbuf);
        tpterm();
        exit(1);
    }


    fprintf(stdout, "Send XML buffer:\n%s\n", sendbuf);

    ret = tpcall("MYWORD", sendbuf, sendlen, &rcvbuf, &rcvlen, 0);
    if ( ret == -1 && TPESVCFAIL != tperrno ) {
        (void) fprintf(stderr, "Can't send request to service MYWORD\n");
        (void) fprintf(stderr, "Tperrno = %d, %s\n", tperrno, tpstrerror(tperrno));
        tpfree((char *)sendbuf);
        tpfree((char *)rcvbuf);
        tpterm();
        exit(1);
    }

    fprintf(stdout, "Returned XML buffer:\n%s\n", rcvbuf);


    tpfree((char *)sendbuf);
    tpfree((char *)rcvbuf);
    tpterm();
    return (0);
}

