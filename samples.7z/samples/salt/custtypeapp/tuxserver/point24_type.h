/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* #ident "@(#) samples/salt/custtypeapp/tuxserver/point24_type.h $Revision: 1.4 $" */

#ifndef _point24_type_h
#define _point24_type_h

#include <tmenv.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DELIMITER			';'
#define MAX_RESULT			32	/* expect at most 32 results */
#define FORMULA_LEN			32	/* max length for each formula string */

typedef struct _point24_t {
	TM32U	p[4];			/* four poker number */
	TM32U	s;				/* solution number */
	TM32U	unuse;			/* for alighment */
} POINT24;

/* Function to add a new formula into the struct */
int _TMDLLENTRY P24_add_formula( POINT24 _TM_FAR * ptr, char * formula );

/* Function to get a formula string according to the index number */
char * _TMDLLENTRY P24_get_formula( POINT24 _TM_FAR * ptr, TM32U index );

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* ! _point24_type_h */
