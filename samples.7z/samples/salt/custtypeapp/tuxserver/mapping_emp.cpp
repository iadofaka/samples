/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* #ident "@(#) samples/salt/custtypeapp/tuxserver/mapping_emp.cpp $Revision: 1.4 $" */

#include <stdio.h>
#include <stdlib.h>
#ifndef WIN32
#include <unistd.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <atmi.h>
#include <userlog.h>
#include <fml32.h>

#ifdef OBB_ANSI_CPP
#include <iostream>
#include <fstream>
#else
#include <iostream.h>
#include <fstream.h>
#endif

#include "mapping_plugin.h"
#include "emp.fml32.h"

/* include xerces header files */
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/util/XMLException.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/framework/MemBufFormatTarget.hpp>
#include <xercesc/framework/MemBufInputSource.hpp>

/* Use Tuxedo bundled Xerces to parse XML data */
XERCES_CPP_NAMESPACE_USE

#ifdef __cplusplus
extern "C" {
#endif

static const char * handler_name = "EmployeeConvert";

static const char * employee_ns = "http://www.example.org/employees";

static XercesDOMParser * parser;
static DOMImplementation * impl;


int ConvertFML32_2_XML(void ** xercesDom, CustomerBuffer * tb, CustType_Ext * info)
{
    XMLCh strTag[256], strURI[256], tmpstr[256];
    DOMDocument * doc = NULL;

    if ( tb == NULL || tb->buf == NULL ) {
        userlog((char *)"Invalid Typed Buffer pointer");
        return -1;
    }

    FBFR32 * fml32buf = (FBFR32 *)tb->buf;

    try {
        /* create root element */
        XMLString::transcode("outbuf", strTag, sizeof(strTag) );
        doc = impl->createDocument(NULL, strTag, 0);

        DOMElement * rootElem = doc->getDocumentElement();

        XMLString::transcode("EMPLOYEES", strTag, sizeof(strTag) );
        XMLString::transcode(employee_ns, strURI, sizeof(strURI));
                DOMElement * topElem = doc->createElementNS(strURI, strTag);
                rootElem->appendChild(topElem);

                for ( int i = 0 ; i < Foccur32(fml32buf, F_NAME) ; i++ ) {
                        DOMElement * elem;
                        DOMText * text;
                        char buf[128];
                        char c;
                        long empno;

                XMLString::transcode("Employee", strTag, sizeof(strTag) );
                        DOMElement * empElem = doc->createElement(strTag);
                        topElem->appendChild(empElem);

                        XMLString::transcode("Name", strTag, sizeof(strTag));
                        elem = doc->createElement(strTag);
                        empElem->appendChild(elem);
                        XMLString::transcode(Fvals32(fml32buf, F_NAME, i), tmpstr, sizeof(tmpstr));
                        text = doc->createTextNode(tmpstr);
                        elem->appendChild(text);

                        Fget32(fml32buf, F_GENDER, i, &c, 0);
                        if ( c == 'F' )
                                strcpy(buf, "female");
                        else
                                strcpy(buf, "male");
                        XMLString::transcode("Gender", strTag, sizeof(strTag));
                        elem = doc->createElement(strTag);
                        empElem->appendChild(elem);
                        XMLString::transcode(buf, tmpstr, sizeof(tmpstr));
                        text = doc->createTextNode(tmpstr);
                        elem->appendChild(text);

                        XMLString::transcode("Type", strTag, sizeof(strTag));
                        elem = doc->createElement(strTag);
                        empElem->appendChild(elem);
                        XMLString::transcode(Fvals32(fml32buf, F_TYPE, i), tmpstr, sizeof(tmpstr));
                        text = doc->createTextNode(tmpstr);
                        elem->appendChild(text);

                        XMLString::transcode("Department", strTag, sizeof(strTag));
                        elem = doc->createElement(strTag);
                        empElem->appendChild(elem);
                        XMLString::transcode(Fvals32(fml32buf, F_DEPT, i), tmpstr, sizeof(tmpstr));
                        text = doc->createTextNode(tmpstr);
                        elem->appendChild(text);

                        empno = Fvall32(fml32buf, F_EMPNO, i);
                        sprintf(buf, "%ld", empno);
                        XMLString::transcode("Empno", strTag, sizeof(strTag));
                        elem = doc->createElement(strTag);
                        empElem->appendChild(elem);
                        XMLString::transcode(buf, tmpstr, sizeof(tmpstr));
                        text = doc->createTextNode(tmpstr);
                        elem->appendChild(text);
                }

                *xercesDom = reinterpret_cast<void *>(doc);
        return 0;

    }
    /*
    catch(const OutOfMemoryException &)
    {
        userlog((char *)"ERROR: XML generator out Of Memory Exception");
    }
    */
    catch(const DOMException& e)
    {
        userlog((char *)"ERROR: XML generator DOM Exception : %d", e.code);
    }
    catch (...)
    {
        userlog((char *)"ERROR: XML generator interal error occurred");
    }

    if ( doc )
        doc->release();
    return -1;
}

/*
 * _ws_pi_init_P_CUSTOM_TYPE_XXXX()
 * _ws_pi_exit_P_CUSTOM_TYPE_XXXX()
 * _ws_pi_set_vtbl_P_CUSTOM_TYPE_XXXX()
 *
 * These three functions must be implemented for a plugin library
 *
 */

int _DLLEXPORT_ _ws_pi_init_P_CUSTOM_TYPE_EmployeeConvert(char * params, void ** priv_ptr)
{
    userlog((char *)" plugin init for custom type %s", handler_name);

    try {
        XMLPlatformUtils::Initialize();
    } catch (const XMLException& e) {
        userlog((char *)"Xerces initialize failed : %d : %s",
                e.getCode(), XMLString::transcode(e.getMessage()));
        return -1;
    }

    parser = new XercesDOMParser();
    if ( NULL == parser ) {
        userlog((char *)"DOM Parser initialize failed");
        XMLPlatformUtils::Terminate();
        return -1;
    }

        impl = DOMImplementationRegistry::getDOMImplementation(XMLString::transcode("LS"));
        if ( NULL == impl ) {
        userlog((char *)"DOM Implementation initialize failed");
        XMLPlatformUtils::Terminate();
        return -1;
        }

    parser->setValidationScheme(XercesDOMParser::Val_Never);
    parser->useScanner(XMLUni::fgSGXMLScanner);

    return 0;
}

int _DLLEXPORT_ _ws_pi_exit_P_CUSTOM_TYPE_EmployeeConvert(void *priv_ptr)
{
    userlog((char *)" plugin exit for handler %s", handler_name);
    delete parser;
    XMLPlatformUtils::Terminate();
    return 0;
}

int _DLLEXPORT_ _ws_pi_set_vtbl_P_CUSTOM_TYPE_EmployeeConvert(void * vtbl)
{
    struct custtype_vtable * vtable;
    if ( ! vtbl )
        return -1;

    vtable = (struct custtype_vtable *) vtbl;

    vtable->soap_in_tuxedo__CUSTBUF = NULL;
    vtable->soap_out_tuxedo__CUSTBUF = ConvertFML32_2_XML;

    userlog((char *)" setup vtable for handler %s", handler_name);

    return 0;
}


#ifdef __cplusplus
} /* extern "C" */
#endif

