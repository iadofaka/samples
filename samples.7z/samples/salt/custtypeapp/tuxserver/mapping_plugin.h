/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* #ident "@(#) samples/salt/custtypeapp/tuxserver/mapping_plugin.h $Revision: 1.3 $" */

#ifndef  _MAPPING_PLUGIN_H_
#define  _MAPPING_PLUGIN_H_

#include <custtype_pi_ex.h>

#if defined(WIN32)
#define _DLLEXPORT_  _declspec(dllexport)
#else
#define _DLLEXPORT_
#endif

#endif /* ! _MAPPING_PLUGIN_H_ */

