/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* ident "@(#) samples/salt/custtypeapp/tuxserver/mywordserver.cpp    $Revision: 1.4 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>   /* TUXEDO Header File */
#include <userlog.h>    /* TUXEDO Header File */
#include <fml32.h>

#ifdef OBB_ANSI_CPP
#include <iostream>
#include <fstream>
#else
#include <iostream.h>
#include <fstream.h>
#endif

/* include xerces header files */
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/util/XMLException.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/framework/MemBufFormatTarget.hpp>
#include <xercesc/framework/MemBufInputSource.hpp>

/* Use Tuxedo bundled Xerces to parse XML data */
XERCES_CPP_NAMESPACE_USE

static XercesDOMParser * parser;
static DOMLSSerializer * theSerializer;
static DOMLSOutput     * outputDesc;
static XMLCh  uriMyword[256];

extern "C" {

int tpsvrinit(int argc, char **argv)
{
    XMLCh tmpstr[256];
    /* Some compilers warn if argc and argv aren't used. */
    argc = argc;
    argv = argv;

    try {
        XMLPlatformUtils::Initialize("UTF-8");
    } catch (const XMLException& e) {
        userlog((char *)"Xerces initialize failed : %d : %s",
                e.getCode(), XMLString::transcode(e.getMessage()));
        return(-1);
    }

    parser = new XercesDOMParser();
    if ( NULL == parser ) {
        userlog((char *)"DOM Parser initialize failed");
        XMLPlatformUtils::Terminate();
        return(-1);
    }

    parser->setValidationScheme(XercesDOMParser::Val_Never);
    parser->useScanner(XMLUni::fgSGXMLScanner);

    XMLString::transcode("LS", tmpstr, sizeof(tmpstr));
    DOMImplementation *impl = DOMImplementationRegistry::getDOMImplementation(tmpstr);
    theSerializer = ((DOMImplementationLS*)impl)->createLSSerializer();
    if ( NULL == theSerializer ) {
        userlog((char *)"Failed to get a serializer from DOM impl");
        XMLPlatformUtils::Terminate();
        return(-1);
    }
    outputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
    if ( NULL == outputDesc ) {
        userlog((char *)"Failed to get an output stream from DOM impl");
        theSerializer->release();
        XMLPlatformUtils::Terminate();
        return(-1);
    }
    DOMConfiguration *serializerConfig = theSerializer->getDomConfig();
    serializerConfig->setParameter(XMLUni::fgDOMWRTSplitCdataSections, true);
    serializerConfig->setParameter(XMLUni::fgDOMWRTFormatPrettyPrint, true);

    XMLString::transcode("http://www.example.org/myword", uriMyword, sizeof(uriMyword));

    userlog("CSTTYPEAPP:INFO Welcome to the word translation server");
    return(0);
}

void tpsvrdone(void)
{
    outputDesc->release();
    theSerializer->release();
    delete parser;
    XMLPlatformUtils::Terminate();

    userlog("CUSTTYPEAPP:INFO word translation server exits");
    return;
}

void setError(DOMDocument * doc, const char * strError)
{
    XMLCh xval[256];

    try {
        DOMElement * rootElem = doc->getDocumentElement();

        XMLString::transcode("Error", xval, sizeof(xval));
        DOMElement * errElem = doc->createElementNS(uriMyword, xval);
        rootElem->appendChild(errElem);

        XMLString::transcode(strError, xval, sizeof(xval));
        DOMText * text = doc->createTextNode(xval);
        errElem->appendChild(text);
    } catch (...) {
        userlog("Error set Error element");
    }
}

DOMDocument * parseReqbuf(char * buff, long buflen)
{
    DOMDocument * doc = NULL;
    MemBufInputSource * memis = NULL;

    memis = new MemBufInputSource((const XMLByte *) buff, buflen, "input", false);
    if ( NULL == memis ) {
        userlog((char *)"Initialize XML request buffer failed");
        return NULL;
    }

    try {
        parser->parse(*memis);
        int errorcount = parser->getErrorCount();
        if ( errorcount > 0 ) {
            userlog((char *)"Error occured during parsing XML");
        } else {
            doc = parser->getDocument();
        }

    } catch (XMLException & e){
        userlog((char *)"XML Exception : %d : %s",
                e.getCode(), XMLString::transcode(e.getMessage()));
    } catch (...) {
        userlog((char *)"Unexpected Exception");
    }

    delete memis;
    return doc;
}

long createRepbuf( DOMDocument * doc, char ** retbuf )
{
    MemBufFormatTarget * myFormTarget;

    try {
        myFormTarget = new MemBufFormatTarget();
        outputDesc->setByteStream(myFormTarget);
        theSerializer->write(doc, outputDesc);
    } catch (...) {
        userlog((char *)"Unexpected Exception");
        return 0;
    }

    long retlen = myFormTarget->getLen() + 1;
    char * buf = tpalloc("XML", NULL, retlen);
    if ( NULL == buf ) {
        userlog((char *)"Error create return buffer");
        delete myFormTarget;
        return 0;
    }

    memcpy(buf, (char *)myFormTarget->getRawBuffer(), myFormTarget->getLen());
    buf[myFormTarget->getLen()] = '\0';
    delete myFormTarget;

    * retbuf = buf;
    return retlen;
}

DOMElement * getEngWord( DOMElement * myword, char * word, unsigned int len )
{
    XMLCh  tag[128];

    XMLString::transcode("English", tag, sizeof(tag));
    DOMNodeList * nodelist = myword->getElementsByTagNameNS(uriMyword, tag);

    if ( nodelist->getLength() == 0 )
        return NULL;

    DOMElement * wordElem = (DOMElement *) nodelist->item(0);
    DOMNode * wordtxt = wordElem->getFirstChild();

    XMLString::transcode( ((DOMText *)wordtxt)->getData(), word, len );
    return wordElem;
}

DOMElement * getLanguage( DOMElement * myword, char * lang, unsigned int len )
{
    XMLCh  tag[128];

    XMLString::transcode("Translated", tag, sizeof(tag));
    DOMNodeList * nodelist = myword->getElementsByTagNameNS(uriMyword, tag);

    if ( nodelist->getLength() == 0 )
        return NULL;

    DOMElement * tranElem = (DOMElement *) nodelist->item(0);

    XMLString::transcode("lang", tag, sizeof(tag));
    const XMLCh * langval = tranElem->getAttribute(tag);

    XMLString::transcode( langval, lang, len );
    return tranElem;
}

void MYWORD(TPSVCINFO * rqst)
{
    XMLCh strVal[256];
    char tmpstr[128], engword[128], lang[128];
    char * retbuf = NULL;
    int found = 0;
    char * delim = NULL;

    DOMDocument * doc = parseReqbuf(rqst->data, rqst->len);
    if ( NULL == doc ) {
        parser->resetDocumentPool();
        tpreturn(TPFAIL, 0, 0, 0, 0);
    }

    DOMElement * myword = doc->getDocumentElement();
    DOMElement * wordElem = getEngWord( myword, engword, sizeof(engword)-1 );
    DOMElement * tranElem = getLanguage( myword, lang, sizeof(lang)-1 );

    char wordfile[128];
    sprintf(wordfile, "./words/%s.dat", engword);

    FILE * fp = fopen(wordfile, "rb");
    if ( NULL == fp ) {
        sprintf(tmpstr, "Word [%s] is not recognized", engword);
        setError(doc, tmpstr);
        goto rtnbuf;
    }

    while( fgets(tmpstr, sizeof(tmpstr), fp) ) {
        if (tmpstr[strlen(tmpstr)-1] == '\n')
            tmpstr[strlen(tmpstr)-1] = '\0';
        delim = strchr(tmpstr, ':');
        if ( delim ) *delim++ = '\0';
        if ( ! strcmp( tmpstr, lang ) ) {
            found = 1;
            break;
        }
    }

    if ( found ) {
        XMLString::transcode(delim, strVal, sizeof(strVal));
        DOMText * text = doc->createTextNode(strVal);
        tranElem->appendChild(text);
    } else {
        sprintf(tmpstr, "Language [%s] is not recognized", lang);
        setError(doc, tmpstr);
    }
    fclose(fp);

rtnbuf:
    long buflen = createRepbuf( doc, &retbuf );
    if ( 0 == buflen ) {
        parser->resetDocumentPool();
        tpreturn(TPFAIL, 0, 0, 0, 0);
    }

    parser->resetDocumentPool();
    tpreturn(TPSUCCESS, 0, retbuf, buflen, 0);
}

} /* extern "C" */
