/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* #ident	"@(#) samples/salt/custtypeapp/tuxserver/calc24.c	$Revision: 1.5 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "atmi.h"		/* TUXEDO  Header File */
#include "point24_type.h"

static void print_usage()
{
	(void) fprintf(stderr, "Usage: calc24 num1 num2 num3 num4\n");
	(void) fprintf(stderr, "       num1-num4 value should be in range[1-13]\n");
	return;
}

static int isNumeric(char * str)
{
	int i;
	for ( i = 0; i < (int) strlen(str); i++ )
		if ( !isdigit(str[i]) )
			return 0;
	return 1;
}

#if defined(__STDC__) || defined(__cplusplus)
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif

{

	POINT24 *sendbuf, *rcvbuf;
	long rcvlen;
	int ret;
	TM32U i;
	TM32U  nums[4];

	if(argc != 5) {
		print_usage();
		exit(1);
	}

	for ( i = 0 ; i < 4 ; i++ ) {
		if ( ! isNumeric( argv[i+1] ) ) {
			print_usage();
			exit(1);
		}
		nums[i] = (TM32U) atoi(argv[i+1]);
	}

	/* Attach to System/T as a Client Process */
	if (tpinit((TPINIT *) NULL) == -1) {
		(void) fprintf(stderr, "Tpinit failed\n");
		exit(1);
	}

	/* Allocate POINT24 buffers for the request and the reply */
	if((sendbuf = (POINT24 *) tpalloc("POINT24", NULL, 0)) == NULL) {
		(void) fprintf(stderr,"Error allocating send buffer\n");
		tpterm();
		exit(1);
	}

	if((rcvbuf = (POINT24 *) tpalloc("POINT24", NULL, 0)) == NULL) {
		(void) fprintf(stderr,"Error allocating receive buffer\n");
		tpfree((char *)sendbuf);
		tpterm();
		exit(1);
	}

	for ( i = 0 ; i < 4 ; i++ )
		sendbuf->p[i] = nums[i];

	/* Request the service TOUPPER, waiting for a reply */
	ret = tpcall("CALC24", (char *)sendbuf, 0, (char **)&rcvbuf, &rcvlen, (long)0);
	if(ret == -1) {
		(void) fprintf(stderr, "Can't send request to service CALC24\n");
		(void) fprintf(stderr, "Tperrno = %d, %s\n", tperrno, tpstrerror(tperrno));
		tpfree((char *)sendbuf);
		tpfree((char *)rcvbuf);
		tpterm();
		exit(1);
	}

	(void) fprintf(stdout, "===================================\n");
	(void) fprintf(stdout, "Poker   Number : %d  %d  %d  %d\n",
				   rcvbuf->p[0], rcvbuf->p[1],
				   rcvbuf->p[2], rcvbuf->p[3]);

	if ( rcvbuf->s == 0 ) {
		(void) fprintf(stdout, "No available Result\n");
		(void) fprintf(stdout, "===================================\n");
	} else {
		(void) fprintf(stdout, "Result  Number : %d\n", rcvbuf->s);
		(void) fprintf(stdout, "===================================\n");
		for ( i = 0 ; i < rcvbuf->s ; i++ )
		{
			/* get each formula */
			(void) fprintf(stdout, "Formula No.%03d : %s\n",
						   i, P24_get_formula(rcvbuf, i));
		}
	}

	/* Free Buffers & Detach from System/T */
	tpfree((char *)sendbuf);
	tpfree((char *)rcvbuf);
	tpterm();
	return(0);
}
