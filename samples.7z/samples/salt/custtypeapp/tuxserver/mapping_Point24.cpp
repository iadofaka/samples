/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* #ident "@(#) samples/salt/custtypeapp/tuxserver/Point24Converter.cpp $Revision: 1.3 $" */

#include <stdio.h>
#include <stdlib.h>
#ifndef WIN32
#include <unistd.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <atmi.h>
#include <userlog.h>

#ifdef OBB_ANSI_CPP
#include <iostream>
#include <fstream>
#else
#include <iostream.h>
#include <fstream.h>
#endif

#include "mapping_plugin.h"
#include "point24_type.h"

/* include xerces header files */
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/util/XMLException.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/framework/MemBufFormatTarget.hpp>
#include <xercesc/framework/MemBufInputSource.hpp>

/* Use Tuxedo bundled Xerces to parse XML data */
XERCES_CPP_NAMESPACE_USE

#ifdef __cplusplus
extern "C" {
#endif

static const char * type_name = "POINT24";

static const char * point24_ns = "http://www.example.org/Point24";

static XercesDOMParser * parser;
static DOMImplementation * impl;

#define ERR_RTN \
    if ( tb->buf ) { \
        tpfree( tb->buf ); \
        tb->buf = NULL; \
        tb->len = 0; \
    } \
    return NULL;

/*
 * The following two functions are actual data convertion functions
 */
CustomerBuffer * ConvertXML_2_POINT24(void * xercesDom, CustomerBuffer * tb, CustType_Ext * info)
{
    char * nsURI, * localname;

    DOMDocument * doc = reinterpret_cast<DOMDocument *>(xercesDom);
    DOMElement * root = doc->getDocumentElement();
    if ( NULL == root ) {
        userlog((char *)"XML doc has no root element");
        return NULL;
    }
        DOMElement * point24 = (DOMElement *)(root->getFirstChild());

    nsURI = XMLString::transcode(point24->getNamespaceURI());
    localname = XMLString::transcode(point24->getLocalName());
    if ( NULL == nsURI || NULL == localname ||
        strcmp(nsURI, point24_ns) || strcmp(localname, "point24") ) {
        if ( nsURI ) delete [] nsURI;
        if ( localname ) delete [] localname;
        userlog((char *)"XML document is not valid, element is not the expected one");
        return NULL;
    }
    delete [] nsURI;
    delete [] localname;


    tb->buf = tpalloc((char *)"POINT24", NULL, 1024);
    if ( NULL == tb->buf ) {
        userlog((char *)"Error allocate Custom Typed Buffer");
        ERR_RTN;
    }
    tb->len = 1024;

    DOMNode * child;
    child = point24->getFirstChild();
    int  count = 0;
    POINT24 * p24buf = (POINT24 *)tb->buf;

    while ( child != NULL ) {
        if ( child->getNodeType() == DOMNode::ELEMENT_NODE ) {
            localname = XMLString::transcode(child->getLocalName());
            if ( localname && ! strcmp( localname, "p" ) ) {
                DOMNode * text = child->getFirstChild();
                if ( text != NULL && text->getNodeType() == DOMNode::TEXT_NODE ){
                        char * value = XMLString::transcode(((DOMText *)text)->getData());
                        p24buf->p[count++] = atoi(value);
                }

            }
            if ( localname ) delete [] localname;
            localname = NULL;
        }
        child = child->getNextSibling();
    }

    return tb;
}

int ConvertPOINT24_2_XML(void ** xercesDom, CustomerBuffer * tb, CustType_Ext * info)
{
    XMLCh strTag[256], strURI[256], tmpstr[256];
    char tmp[16], tmp1[64];
    unsigned int i;
    DOMDocument * doc = NULL;

    if ( tb == NULL || tb->buf == NULL ) {
        userlog((char *)"Invalid Custom Typed Buffer pointer");
        return -1;
    }

    POINT24 * p24 = (POINT24 *)tb->buf;

    try {
        /* create root element */
        XMLString::transcode("outbuf", strTag, sizeof(strTag) );
        doc = impl->createDocument(NULL, strTag, 0);

        DOMElement * rootElem = doc->getDocumentElement();

        XMLString::transcode("point24", strTag, sizeof(strTag) );
        XMLString::transcode(point24_ns, strURI, sizeof(strURI));
                DOMElement * point24Elem = doc->createElementNS(strURI, strTag);
                rootElem->appendChild(point24Elem);

        /* add <p> elements */
        DOMElement * elem;
        DOMText * text;
        for ( i = 0 ; i < 4 ; i++ ) {
            sprintf(tmp, "%u", p24->p[i]);
            XMLString::transcode("p", strTag, sizeof(strTag));
            elem = doc->createElement(strTag);
            point24Elem->appendChild(elem);

            XMLString::transcode(tmp, tmpstr, sizeof(tmpstr));
            text = doc->createTextNode(tmpstr);
            elem->appendChild(text);
        }

        /* add <formula> elements */
        for ( i = 0 ; i < p24->s ; i++ ) {
            sprintf(tmp1, "%s", P24_get_formula(p24, i));
            XMLString::transcode("formula", strTag, sizeof(strTag));
            elem = doc->createElement(strTag);
            point24Elem->appendChild(elem);

            XMLString::transcode(tmp1, tmpstr, sizeof(tmpstr));
            text = doc->createTextNode(tmpstr);
            elem->appendChild(text);
        }

                *xercesDom = reinterpret_cast<void *>(doc);
        return 0;

    }
    /*
    catch(const OutOfMemoryException &)
    {
        userlog((char *)"ERROR: XML generator out Of Memory Exception");
    }
    */
    catch(const DOMException& e)
    {
        userlog((char *)"ERROR: XML generator DOM Exception : %d", e.code);
    }
    catch (...)
    {
        userlog((char *)"ERROR: XML generator interal error occurred");
    }

    if ( doc )
        doc->release();
    return -1;
}

/*
 * _ws_pi_init_P_CUSTOM_TYPE_XXXX()
 * _ws_pi_exit_P_CUSTOM_TYPE_XXXX()
 * _ws_pi_set_vtbl_P_CUSTOM_TYPE_XXXX()
 *
 * These three functions must be implemented for a plugin library
 *
 */

int _DLLEXPORT_ _ws_pi_init_P_CUSTOM_TYPE_POINT24(char * params, void ** priv_ptr)
{
    userlog((char *)" plugin init for custom type %s", type_name);

    try {
        XMLPlatformUtils::Initialize();
    } catch (const XMLException& e) {
        userlog((char *)"Xerces initialize failed : %d : %s",
                e.getCode(), XMLString::transcode(e.getMessage()));
        return -1;
    }

    parser = new XercesDOMParser();
    if ( NULL == parser ) {
        userlog((char *)"DOM Parser initialize failed");
        XMLPlatformUtils::Terminate();
        return -1;
    }

        impl = DOMImplementationRegistry::getDOMImplementation(XMLString::transcode("LS"));
        if ( NULL == impl ) {
        userlog((char *)"DOM Implementation initialize failed");
        XMLPlatformUtils::Terminate();
        return -1;
        }

    parser->setValidationScheme(XercesDOMParser::Val_Never);
    parser->useScanner(XMLUni::fgSGXMLScanner);

    return 0;
}

int _DLLEXPORT_ _ws_pi_exit_P_CUSTOM_TYPE_POINT24(void *priv_ptr)
{
    userlog((char *)" plugin exit for custom type %s", type_name);
    delete parser;
    XMLPlatformUtils::Terminate();
    return 0;
}

int _DLLEXPORT_ _ws_pi_set_vtbl_P_CUSTOM_TYPE_POINT24(void * vtbl)
{
    struct custtype_vtable * vtable;
    if ( ! vtbl )
        return -1;

    vtable = (struct custtype_vtable *) vtbl;

    vtable->soap_in_tuxedo__CUSTBUF = ConvertXML_2_POINT24;
    vtable->soap_out_tuxedo__CUSTBUF = ConvertPOINT24_2_XML;

    userlog((char *)" setup vtable for custom type %s", type_name);

    return 0;
}

#ifdef TEST
int main(int argc, char ** argv)
{
    char xmlbuf[1024];
    long len;
    CustomerBuffer * tb;
    POINT24 * p24;

    if ( argc != 2 ) {
        cout << "Usage: " << argv[0] << " xml_file\n" << endl;
        return -1;
    }

    if ( 0 != _ws_pi_init_P_CUSTOM_TYPE_POINT24(NULL, NULL) ) {
        cout << "Initialize Custom Type Plugin failed" << endl;
        return -1;
    }

    ifstream  cfgfile (argv[1]);

    if ( cfgfile == NULL ) {
        cout << "Error open xml file "<< endl;
        _ws_pi_exit_P_CUSTOM_TYPE_POINT24(NULL);
        return -1;
    }

    memset(xmlbuf, 0x0, 1024);
    cfgfile.read(xmlbuf, 1024);
    cfgfile.close();

    for ( len = strlen(xmlbuf) - 1 ;  len >= 0 && xmlbuf[len] != '>'; xmlbuf[len] = '\0', len-- );

    cout << "==========================" << endl;
    cout << " The request xml buffer   " << endl;
    cout << "==========================" << endl;
    cout << xmlbuf << endl;

    tb = (CustomerBuffer *)malloc(sizeof(CustomerBuffer));
    tb->buf = NULL; tb->len = 0;

    if ( ! ConvertXML_2_POINT24(xmlbuf, tb, (char *)"POINT24") || !tb->buf ) {
        free(tb);
        cout << "Error convert XML document to Custom Typed Buffer 'POINT24'" << endl;
        _ws_pi_exit_P_CUSTOM_TYPE_POINT24(NULL);
        return -1;
    }

    p24 = (POINT24 *)tb->buf;

    //fprintf(stdout, " p %d %d %d %d\n", p24->p[0], p24->p[1], p24->p[2], p24->p[3]);

    P24_add_formula( p24, (char *)"1+2+4+5" );
    P24_add_formula( p24, (char *)"2+3+4+5" );

    char * buf = NULL;
    if ( 0 != ConvertPOINT24_2_XML(&buf, tb, (char *)"POINT24") ) {
        cout << "Error convert back from Custom Typed Buffer 'POINT24' to XML document" << endl;
    } else {
        cout << "==========================" << endl;
        cout << " The response xml buffer  " << endl;
        cout << "==========================" << endl;
        cout << buf << endl;
    }

    tpfree((char *)p24);
    free(tb);
    _ws_pi_exit_P_CUSTOM_TYPE_POINT24(NULL);
    return 0;
}
#endif


#ifdef __cplusplus
} /* extern "C" */
#endif

