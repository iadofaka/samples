/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* ident "@(#) samples/salt/custtypeapp/tuxserver/calc24server.c    $Revision: 1.5 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>   /* TUXEDO Header File */
#include <userlog.h>    /* TUXEDO Header File */

#include "point24_type.h"

/* This function performs the actual service requested by the client.
   Its argument is a structure containing among other things a pointer
   to the data buffer, and the length of the data buffer.
*/

#ifdef __cplusplus
extern "C" {
#endif

#define  MUL    103
#define  DIV    102
#define  ADD    101
#define  SUB    100

struct bnode {
    int             value;
    struct bnode   *left;
    struct bnode   *right;
};

struct formula {
    struct formula *next;
    struct bnode   *rootnode;
    /*
    int             mode;
    */
    char            fstr[32];
};

#define  IS_OPERATORNODE(a) (((a)->value)>=100)
#define  IS_POKERNUMNODE(a) (((a)->value)<100)
#define  OP_PRI(o)          ((o)->value - 100)/2

#define  INFINITE    -999999.0

#define  MODE_1      1
#define  MODE_2      2
#define  MODE_3      3
#define  MODE_4      4
#define  MODE_5      5

static float calc_tree(struct bnode * node)
{
    float leftval, rightval;
    if (IS_POKERNUMNODE(node))
        return (float)node->value;

    leftval  = calc_tree(node->left);
    rightval = calc_tree(node->right);

    if ( leftval == INFINITE || rightval == INFINITE )
        return INFINITE;

    switch (node->value) {
        case ADD:
            return leftval + rightval;
        case SUB:
            return leftval - rightval;
        case MUL:
            return leftval * rightval;
        case DIV:
            if ( rightval == (float)0 ) return INFINITE;
            return leftval / rightval;
        default:
            return INFINITE;
    }
}

static void delete_tree(struct bnode * node)
{
    if ( node->left )
        delete_tree( node->left );
    if ( node->right )
        delete_tree( node->right );
    free(node);
    return;
}

static void print_tree(struct bnode * node, char * buf)
{
    char tmp[32];
    int  bracketflag;
    if ( IS_POKERNUMNODE(node) ) {
        sprintf(tmp, "%d ", node->value);
        strcat(buf, tmp);
        return;
    }

    /* print left sub tree */
    bracketflag = 0;
    if ( IS_OPERATORNODE(node->left) && (OP_PRI(node) > OP_PRI(node->left)) )
        bracketflag = 1;

    if ( bracketflag )
        strcat(buf, "( ");
    print_tree(node->left, buf);
    if ( bracketflag )
        strcat(buf, ") ");

    /* print this operator */
    switch(node->value) {
        case ADD:
            strcat(buf, "+ ");
            break;
        case SUB:
            strcat(buf, "- ");
            break;
        case MUL:
            strcat(buf, "* ");
            break;
        case DIV:
            strcat(buf, "/ ");
            break;
    }

    /* print right sub tree */
    bracketflag = 0;
    if ( IS_OPERATORNODE(node->right) )
        if ( OP_PRI(node) > OP_PRI(node->right) ||
            ( OP_PRI(node) == OP_PRI(node->right)
              && (node->value == SUB || node->value == DIV)
             )
            )
        bracketflag = 1;

    if ( bracketflag )
        strcat(buf, "( ");
    print_tree(node->right, buf);
    if ( bracketflag )
        strcat(buf, ") ");

    return;
}

static int compareFormula(struct formula * f1, struct formula * f2)
{
    return strcmp( f1->fstr, f2->fstr);
}

static float calcFormula(struct formula * f)
{
    return calc_tree(f->rootnode);
}

static int saveFormula(struct formula ** savelist, struct formula * f)
{
    struct formula * cursor, * prev;
    if ( *savelist == NULL ) {
        *savelist = f;
        return 1;
    }
    for ( cursor = *savelist; cursor != NULL; prev = cursor, cursor=cursor->next )
        /* the same formula, do not save */
        if ( compareFormula(cursor, f) == 0 )
            return 0;

    prev->next = f;
    return 1;
}

static void normalizeFormula(struct formula * f)
{
    struct bnode * root = f->rootnode;

    /* print original formula */
    f->fstr[0] = '\0';
    print_tree( root, f->fstr );
#ifdef DEBUG
    fprintf(stdout, "%s ==> %f\n", f->fstr, calcFormula(f));
#endif

    /* TODO: can add some normalize rule to reduce the formula number */

    return;
}

static struct formula * newFormula(int * p, int * op, int mode)
{
    int i;
    struct formula * f = NULL;
    struct bnode * node_op[3];
    struct bnode * node_poker[4];

    f = (struct formula *)malloc(sizeof(struct formula));
    f->next = NULL;
    f->rootnode = NULL;
    f->fstr[0] = '\0';

    for ( i = 0 ; i < 3 ; i++ ) {
        node_op[i] = (struct bnode *)malloc(sizeof(struct bnode));
        node_op[i]->value = op[i];
        node_op[i]->left = node_op[i]->right = NULL;
    }

    for ( i = 0 ; i < 4 ; i++ ) {
        node_poker[i] = (struct bnode *)malloc(sizeof(struct bnode));
        node_poker[i]->value = p[i];
        node_poker[i]->left = node_poker[i]->right = NULL;
    }

    switch ( mode ) {
        case MODE_1:
        f->rootnode =node_op[2];
        /* MODE_1 : ((p0 op0 p1) op1 p2) op2 p3 */
        node_op[0]->left  = node_poker[0];
        node_op[0]->right = node_poker[1];

        node_op[1]->left  = node_op[0];
        node_op[1]->right = node_poker[2];

        node_op[2]->left  = node_op[1];
        node_op[2]->right = node_poker[3];
        break;

        case MODE_2:
        /* MODE_2 : ( p0 op0 ( p1 op1 p2 ) ) op2 p3 */
        f->rootnode =node_op[2];
        node_op[0]->left  = node_poker[0];
        node_op[0]->right = node_op[1];

        node_op[1]->left  = node_poker[1];
        node_op[1]->right = node_poker[2];

        node_op[2]->left  = node_op[0];
        node_op[2]->right = node_poker[3];
        break;

        case MODE_3:
        /* MODE_3 : ( p0 op0 p1 ) op1 ( p2 op2 p3 ) */
        f->rootnode =node_op[1];
        node_op[0]->left  = node_poker[0];
        node_op[0]->right = node_poker[1];

        node_op[1]->left  = node_op[0];
        node_op[1]->right = node_op[2];

        node_op[2]->left  = node_poker[2];
        node_op[2]->right = node_poker[3];
        break;

        case MODE_4:
        /* MODE_4 : p0 op0 ( ( p1 op1 p2 ) op2 p3 ) */
        f->rootnode =node_op[0];
        node_op[0]->left  = node_poker[0];
        node_op[0]->right = node_op[2];

        node_op[1]->left  = node_poker[1];
        node_op[1]->right = node_poker[2];

        node_op[2]->left  = node_op[1];
        node_op[2]->right = node_poker[3];
        break;

        case MODE_5:
        /* MODE_5 : p0 op0 ( p1 op1 ( p2 op2 p3 ) ) */
        f->rootnode =node_op[0];
        node_op[0]->left  = node_poker[0];
        node_op[0]->right = node_op[1];

        node_op[1]->left  = node_poker[1];
        node_op[1]->right = node_op[2];

        node_op[2]->left  = node_poker[2];
        node_op[2]->right = node_poker[3];
        break;
    }

    normalizeFormula(f);
    return f;
}

static void deleteFormula(struct formula * f)
{
    if ( f == NULL )
        return;

    if ( f->rootnode )
        delete_tree(f->rootnode);

    free(f);
    return;
}

void findFormulaList(struct formula ** savelist, int * p)
{
    int p1, p2, p3, p4, i;
    int list[24][4], listnum = 0;
    int op[3], mode;
    struct formula * f;

    /* Get all different permutations of the 4 numbers */
    /* now get all different permutations of the 4 numbers */
    for ( p1 = 0 ; p1 < 4 ; p1++ ) {
        for ( p2 = 0 ; p2 < 4 ; p2++ ) {    if ( p1 == p2 ) continue;
            for ( p3 = 0 ; p3 < 4; p3++ ) {     if ( p3 == p1 || p3 == p2) continue;
                for ( p4 = 0 ; p4 < 4 ; p4++ ) {            if ( p4 == p1 || p4 == p2 || p4 == p3 ) continue;
                    for (i = 0 ; i < listnum ; i++)
                        if ( list[i][0] == p[p1] && list[i][1] == p[p2] && list[i][2] == p[p3] && list[i][3] == p[p4] ) break;
                    if ( i != listnum ) continue;
                    list[listnum][0] = p[p1]; list[listnum][1] = p[p2]; list[listnum][2] = p[p3]; list[listnum][3] = p[p4];
                    listnum++;
                }
            }
        }
    } /* for */

    for ( i = 0 ; i < listnum ; i++ )
    for ( op[0] = SUB ; op[0] <= MUL ; op[0] ++ )
    for ( op[1] = SUB ; op[1] <= MUL ; op[1] ++ )
    for ( op[2] = SUB ; op[2] <= MUL ; op[2] ++ )
    for ( mode = MODE_1 ; mode <= MODE_5 ; mode++ )
    {
        f = newFormula(list[i], op, mode);
        if ( saveFormula(savelist, f) == 0 )
            deleteFormula(f);
    }

    return;
}

void deleteFormulaList(struct formula * savelist)
{
    struct formula * cursor, * next;
    for ( cursor=savelist; cursor!=NULL; cursor=next) {
        next = cursor->next;
        deleteFormula(cursor);
    }
    return;
}

void
#if defined(__STDC__) || defined(__cplusplus)
CALC24(TPSVCINFO *rqst)
#else
CALC24(rqst)
TPSVCINFO *rqst;
#endif
{

    int i;
    char type[9], subtype[17];
    POINT24 * reqbuf, * retbuf;
    struct formula * tmp, * savelist = NULL;

    type[0] = subtype[0] = '\0';
    tptypes(rqst->data, type, subtype);
    if ( strcmp(type, "POINT24") ) {
        userlog("Error in calc24 service, request message is not POINT24 typed buffer!");
        tpreturn(TPFAIL, 0, rqst->data,rqst->len, 0);
    }

    reqbuf = (POINT24 *)rqst->data;

    retbuf = (POINT24 *)tpalloc("POINT24", NULL, 0);

    for ( i = 0 ; i < 4 ; i++ )
        retbuf->p[i] = reqbuf->p[i];

    findFormulaList(&savelist, (int *)(retbuf->p));
    for ( tmp=savelist; tmp != NULL; tmp=tmp->next) {
        float diff = calcFormula(tmp) - 24;
        if ( diff < 0.00001 && diff > -0.00001 )
            P24_add_formula( retbuf, tmp->fstr );
    }
    deleteFormulaList(savelist);

    /* Return the transformed buffer to the requestor. */
    tpreturn(TPSUCCESS, 0, (char *)retbuf, 0, 0);
}

#ifdef __cplusplus
}
#endif

/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/

#if defined(__STDC__) || defined(__cplusplus)
tpsvrinit(int argc, char *argv[])
#else
tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
    /* Some compilers warn if argc and argv aren't used. */
    argc = argc;
    argv = argv;

    /* userlog writes to the central TUXEDO message log */

    userlog("SIMPAPP:INFO Welcome to the calc24 server");
    return(0);
}
