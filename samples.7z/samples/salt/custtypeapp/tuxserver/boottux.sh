#!/bin/sh
. ./setTuxEnv.sh
tmboot -y
