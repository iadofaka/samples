/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */


/* ident "@(#) samples/salt/custtypeapp/tuxserver/empserver.c    $Revision: 1.3 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>   /* TUXEDO Header File */
#include <userlog.h>    /* TUXEDO Header File */
#include <fml32.h>

#include "emp.fml32.h"

static const char * empdatafile = "./empdata/emp.dat";

typedef struct _employee_t EMPLOYEE;

struct _employee_t {
    EMPLOYEE * next;
    int        empno;       /* employee number */
    char       name[128];   /* employee name   */
    char       gender;      /* employee gender */
    char       dept[128];   /* department      */
    char       type[32];    /* employee character type */
    char     * pic;         /* employee picture */
};


static EMPLOYEE * head = NULL;
static EMPLOYEE * tail = NULL;

static int readline(char * buff)
{
    int n = 0;
    EMPLOYEE * emp;
    char * tok;

    emp = (EMPLOYEE *) calloc(1, sizeof(EMPLOYEE));
    if ( NULL == emp )
        return -1;

    tok = strtok(buff, "\n\t ");
    while ( tok ) {
        switch ( n ) {
            case 0: /* employee name */
                strncpy( emp->name, tok, sizeof(emp->name)-1 );
                break;
            case 1: /* employee gender */
                emp->gender = tok[0];
                break;
            case 2: /* employee type */
                strncpy( emp->type, tok, sizeof(emp->type)-1 );
                break;
            case 3: /* employee no */
                emp->empno = atoi(tok);
                break;
            case 4: /* employee dept */
                strncpy( emp->dept, tok, sizeof(emp->dept)-1 );
                break;
            default:
                break;
        }

        tok = strtok(NULL, "\n\t ");
        n++;
    } /* end while */

    /*
     fprintf(stdout, "Employee name[%s], gender[%c], type[%s], empno[%d], dept[%s]\n",
                    emp->name, emp->gender, emp->type, emp->empno, emp->dept);
    */

    /* add to employee list */
    if ( head == NULL ) {
        head = emp;
    } else {
        tail->next = emp;
    }
    tail = emp;
    return 0;
}

int tpsvrinit(int argc, char *argv[])
{
    FILE * fp;
    char buff[512];

    /* Some compilers warn if argc and argv aren't used. */
    argc = argc;
    argv = argv;

    userlog("CUSTTYPEAPP:INFO Welcome to the employee server");

    /* create the employee data structure from the data file */
    fp = fopen(empdatafile, "r");
    if ( NULL == fp ) {
        userlog("CUSTTYPEAPP:Cannot read employ data file [%s]", empdatafile);
        return(-1);
    }

    while (fgets(buff, sizeof(buff), fp)) {

        /* check empty line, comment line */
        if ( *buff == '\n' || *buff == '\0' || *buff == '#' )
            continue;

        /* check line too long, skip it */
        if ( *( buff + strlen(buff) - 1 ) != '\n' ) {
            int x = getc(fp);
            while ( x != EOF && x != '\n' )
                ;
            continue;
        }

        /* get employee data from this line */
        (void) readline(buff);

    }/* end while */

    fclose(fp);
    return(0);
}

void tpsvrdone(void)
{
    userlog("CUSTTYPEAPP:INFO employee server exits");
    return;
}

int match(EMPLOYEE * p, EMPLOYEE * cond)
{
    if ( cond->name[0] != '\0' && !strstr(p->name, cond->name) )
        return 0;

    if ( cond->gender != '\0' && p->gender != cond->gender )
        return 0;

    if ( cond->type[0] != '\0' && strcmp(p->type, cond->type) )
        return 0;

    if ( cond->dept[0] != '\0' && strcmp(p->dept, cond->dept) )
        return 0;

    if ( cond->empno != 0 && p->empno != cond->empno )
        return 0;

    return 1;
}

void GETEMPLOYEE(TPSVCINFO *rqst)
{
    FBFR32 * request, * reply;
    EMPLOYEE inquiry;
    EMPLOYEE * one;

    request = (FBFR32 *)rqst->data;
    reply = (FBFR32 *)tpalloc("FML32", NULL, 4096);
    if ( NULL == reply ) {
        userlog( "Memory Allocation Failure" );
        tpreturn(TPFAIL, 0, 0, 0, 0);
    }

    /* Get the inquiry condition */
    memset( (char *)&inquiry, 0x0, sizeof(EMPLOYEE) );

    if ( Fpres32( request, F_NAME, 0 ) ) {
        char * name = Fvals32(request, F_NAME, 0);
        strncpy(inquiry.name, name, sizeof(inquiry.name)-1);
    }

    if ( Fpres32( request, F_GENDER, 0 ) ) {
        FLDLEN32  len = 0;
        Fget32(request, F_GENDER, 0, (char *)&inquiry.gender, &len);
    }

    if ( Fpres32( request, F_TYPE, 0 ) ) {
        char * type = Fvals32(request, F_TYPE, 0);
        strncpy(inquiry.type, type, sizeof(inquiry.type)-1);
    }

    if ( Fpres32( request, F_EMPNO, 0 ) ) {
        FLDLEN32 len = sizeof(long);
        Fget32(request, F_EMPNO, 0, (char *)&inquiry.empno, &len);
    }

    if ( Fpres32( request, F_DEPT, 0 ) ) {
        char * dept = Fvals32(request, F_DEPT, 0);
        strncpy(inquiry.dept, dept, sizeof(inquiry.dept)-1);
    }

    /* Find employees according to the inquiry condition */
    for ( one = head ; one != NULL ; one = one->next ) {
        if (match(one, &inquiry)) {
            Fadd32(reply, F_NAME, one->name, 0);
            Fadd32(reply, F_GENDER, &one->gender, 0);
            Fadd32(reply, F_TYPE, one->type, 0);
            Fadd32(reply, F_DEPT, one->dept, 0);
            Fadd32(reply, F_EMPNO, (char *)&one->empno, 0);
        }
    }

    tpreturn(TPSUCCESS, 0, (char *)reply, 0, 0);
}

