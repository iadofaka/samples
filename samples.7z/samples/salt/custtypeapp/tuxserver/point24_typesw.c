/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */

/* #ident	"@(#) tuxedo/libbuft/tmtypesw.c	$Revision: 1.6 $" */
#include <tmenv.h>
#ifndef NOWHAT
static  char    sccsid[] = "@(#) tuxedo/libbuft/tmtypesw.c	$Revision: 1.6 $";
#endif

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <tmtypes.h>
#include <userlog.h>
#include <point24_type.h>

#ifdef _TM_NETWARE
#include <signal.h>
#include <process.h>
	static int LibHandle, threadGroupID;
#endif /* _TM_NETWARE */

#ifdef _TML_ENDIAN
static TM32U ntoh_32u(TM32U in)
{
	int c;
	TM32U j;
	char *s1;
	char *s2;
	s1 = (char *)&in;
	s2 = (char *)&j;
	for (c=0;c<sizeof(in);c++)
		s2[sizeof(in)-c-1] = s1[c];
	return(j);
}

#define hton_32u(h) ntoh_32u(h)

#else	/* _TML_ENDIAN */

#define ntoh_32u(n)	(n)
#define hton_32u(n)	(n)

#endif	/* _TML_ENDIAN */

/****************************************************
 * Some common functions to operate type POINT24    *
 *                                                  *
 * Can be used by client or server code             *
 ****************************************************/
int _TMDLLENTRY P24_add_formula( POINT24 _TM_FAR * ptr, char * formula )
{
	int len;
	char * save;

	if ( ptr == NULL || formula == NULL )
		return -1;

	len = strlen(formula);
	if ( len == 0 || len > FORMULA_LEN-1 )
		return -1;

	if ( ptr->s == MAX_RESULT )
		return 0;

	save = (char *)ptr + sizeof(POINT24)  + ptr->s * FORMULA_LEN;
	strncpy( save, formula, len);
	save[len] = '\0';
	ptr->s ++;
	return 1;	/* succeed */
}

char * _TMDLLENTRY P24_get_formula( POINT24 _TM_FAR * ptr, TM32U index )
{
	char * formula;
	if ( ptr == NULL || ptr->s <= 0 || index < 0 || index > ptr->s )
		return NULL;

	formula = (char *)ptr + sizeof(POINT24) + index * FORMULA_LEN;
	return formula;	/* succeed */
}

/****************************************************
 * Callback Routines for type POINT24               *
 *                                                  *
 * These functions will be set in type switch table *
 ****************************************************/
static void P24_h2n( POINT24 _TM_FAR * ptr )
{
	int  i;
	if ( ptr == NULL )
		return;

	for ( i = 0 ; i < 4 ; i++ )
		ptr->p[i] = hton_32u(ptr->p[i]);

	ptr->s = hton_32u(ptr->s);
	return;
}

static void P24_n2h( POINT24 _TM_FAR * ptr )
{
	int  i;
	if ( ptr == NULL )
		return;

	for ( i = 0 ; i < 4 ; i++ )
		ptr->p[i] = ntoh_32u(ptr->p[i]);

	ptr->s = ntoh_32u(ptr->s);
	return;
}

static int _TMDLLENTRY _p24_init(char _TM_FAR *ptr, long len)
{
	int i;
	char * formula;
	POINT24 * pbuf = (POINT24 *)ptr;

	pbuf->p[0] = pbuf->p[1] = pbuf->p[2] = pbuf->p[3] = 0;
	pbuf->s = 0;

	formula = (char *)(ptr + sizeof(POINT24));
	for ( i = 0 ; i < MAX_RESULT; i++ ) {
		* formula = '\0';
		formula += FORMULA_LEN;
	}

	userlog("_p24_init is invoked, len = %d", len);
	return (1);
}

static long _TMDLLENTRY _p24_presend(char _TM_FAR *ptr, long dlen, long mdlen)
{
	/* do xdr in case int data transferred in different architect */
	POINT24 * pbuf = (POINT24 *)ptr;

	userlog("_p24_presend is invoked, dlen=%d, mdlen=%d", dlen, mdlen);

	dlen = pbuf->s * FORMULA_LEN + sizeof(POINT24);

	P24_h2n(pbuf);	/* convert from host byte order to network byte order */

	userlog("_p24_presend is return, dlen=%d", dlen);
	return (dlen);
}

static long _TMDLLENTRY _p24_postrecv(char _TM_FAR *ptr, long dlen, long mdlen)
{
	/* do xdr in case int data transferred in different architect */
	POINT24 * pbuf = (POINT24 *)ptr;

	userlog("_p24_postrecv is invoked, dlen=%d, mdlen=%d", dlen, mdlen);

	P24_n2h(pbuf);	/* convert from network byte order to host byte order */
	dlen = pbuf->s * FORMULA_LEN + sizeof(POINT24);

	userlog("_p24_postrecv is return, dlen=%d", dlen);
	return (dlen);
}

/* application buffer type switch */

/*
 * Initialization of the buffer type switch.
 */
static struct tmtype_sw_t tm_typesw[] = {

/*************************************************
 * This is a custom type POINT24                 *
 *                                               *
 * This type carries a Point24 structure defined *
 * in file point24_type.h                        *
 *************************************************/
{
	"POINT24",	/* type */
	"*",		/* subtype */
	sizeof(POINT24) + MAX_RESULT*FORMULA_LEN,	/* dfltsize */
	_p24_init,	/* initbuf */
	NULL,		/* reinitbuf */
	NULL,		/* uninitbuf */
	_p24_presend,	/* presend */
	NULL,		/* postsend */
	_p24_postrecv,	/* postrecv */
	NULL,		/* encdec */
	NULL,		/* route */
	NULL,		/* filter */
	NULL,		/* format */
	NULL,		/* presend2 */
	NULL		/* multi-byte codeset data convertion */
},

{
	"CARRAY",	/* type */
	"*",		/* subtype */
	0		/* dfltsize */
},
{
	"STRING",	/* type */
	"*",		/* subtype */
	512,		/* dfltsize */
	NULL,		/* initbuf */
	NULL,		/* reinitbuf */
	NULL,		/* uninitbuf */
	_strpresend,	/* presend */
	NULL,		/* postsend */
	NULL,		/* postrecv */
	_strencdec,	/* encdec */
	NULL,		/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_sfilter,	/* filter */
	_sformat,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	NULL		/* presend2 */
},
{
	"FML",		/* type */
	"*",		/* subtype */
	1024,		/* dfltsize */
	_finit,		/* initbuf */
	_freinit,	/* reinitbuf */
	_funinit,	/* uninitbuf */
	_fpresend,	/* presend */
	_fpostsend,	/* postsend */
	_fpostrecv,	/* postrecv */
	_fencdec,	/* encdec */
	_froute,	/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_ffilter,	/* filter */
	_fformat,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	NULL		/* presend2 */
},
{
	"VIEW",		/* type */
	"*",		/* subtype */
	1024,		/* dfltsize */
	_vinit,		/* initbuf */
	_vreinit,	/* reinitbuf */
	NULL,		/* uninitbuf */
	_vpresend,	/* presend */
	NULL,		/* postsend */
	NULL,		/* postrecv */
	_vencdec,	/* encdec */
	_vroute,	/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_vfilter,	/* filter */
	_vformat,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	NULL		/* presend2 */
},
{	/* XATMI - identical to CARRAY */
	"X_OCTET",	/* type */
	"*",		/* subtype */
	0 		/* dfltsize */
},
{	/* XATMI - identical to VIEW */
#if (defined(__OS2__) && defined(__32BIT__) && defined(__IBMC__)) || defined(_as400_)
	"X_C_TYPE",	/* type */
#else
	{'X','_','C','_','T','Y','P','E'},	/* type */
#endif
	"*",		/* subtype */
	1024,		/* dfltsize */
	_vinit,		/* initbuf */
	_vreinit,	/* reinitbuf */
	NULL,		/* uninitbuf */
	_vpresend,	/* presend */
	NULL,		/* postsend */
	NULL,		/* postrecv */
	_vencdec,	/* encdec */
	_vroute,	/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_vfilter,	/* filter */
	_vformat,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	NULL		/* presend2 */
},
{	/* XATMI - identical to VIEW */
#if (defined(__OS2__) && defined(__32BIT__) && defined(__IBMC__)) || defined(_as400_)
	"X_COMMON",
#else
	{'X','_','C','O','M','M','O','N'},	/* type */
#endif
	"*",		/* subtype */
	1024,		/* dfltsize */
	_vinit,		/* initbuf */
	_vreinit,	/* reinitbuf */
	NULL,		/* uninitbuf */
	_vpresend,	/* presend */
	NULL,		/* postsend */
	NULL,		/* postrecv */
	_vencdec,	/* encdec */
	_vroute,	/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_vfilter,	/* filter */
	_vformat,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	NULL		/* presend2 */
},
{
	"FML32",	/* type */
	"*",		/* subtype */
	1024,		/* dfltsize */
	_finit32,	/* initbuf */
	_freinit32,	/* reinitbuf */
	_funinit32,	/* uninitbuf */
	_fpresend32,	/* presend */
	_fpostsend32,	/* postsend */
	_fpostrecv32,	/* postrecv */
	_fencdec32,	/* encdec */
	_froute32,	/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_ffilter32,	/* filter */
	_fformat32,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	_fpresend232,	/* presend2 */
	_fmbconv32	/* multi-byte codeset data conversion */
},
{
	"VIEW32",	/* type */
	"*",		/* subtype */
	1024,		/* dfltsize */
	_vinit32,	/* initbuf */
	_vreinit32,	/* reinitbuf */
	NULL,		/* uninitbuf */
	_vpresend32,	/* presend */
	NULL,		/* postsend */
	NULL,		/* postrecv */
	_vencdec32,	/* encdec */
	_vroute32,	/* route */
#if !defined(_TMDOWN) || defined(WIN32)
	_vfilter32,	/* filter */
	_vformat32,	/* format */
#else
	NULL,		/* filter - not available on this platform */
	NULL,		/* format - not available on this platform */
#endif
	NULL,		/* presend2 */
#if !defined(TUX81)
	_vmbconv32	/* multi-byte codeset data conversion */
#endif
},
{
	"XML",	/* type */
	"*",		/* subtype */
	0,		/* dfltsize */
	NULL,		/* _xinit - not available */
	NULL,		/* _xreinit - not available */
	NULL,		/* _xuninit - not available */
	NULL,		/* _xpresend - not available */
	NULL,		/* _xpostsend - not available */
#if !defined(TUX81)
	_xpostrecv,	/* _xpostrecv */
#else
	NULL,		/* _xpostrecv - not available */
#endif
	NULL,		/* _xencdec - not available */
	_xroute,	/* _xroute */
	NULL,		/* filter - not available */
	NULL		/* format - not available */
},
{
#if (defined(__OS2__) && defined(__32BIT__) && defined(__IBMC__)) || defined(_as400_)
	"MBSTRING",	/* type */
#else
	{'M','B','S','T','R','I','N','G'},	/* type */
#endif
	"*",		/* subtype */
	0,		/* dfltsize */
	_mbsinit,	/* initbuf */
	NULL,		/* reinitbuf */
	NULL,		/* uninitbuf */
	_mbspresend,	/* presend */
	NULL,		/* postsend */
	NULL,		/* postrecv */
	NULL,		/* encdec */
	NULL,		/* route */
	NULL,		/* filter */
	NULL,		/* format */
	NULL,		/* presend2 */
	_mbsconv	/* multi-byte codeset data conversion */
},
{
""
}
};


/*
 * _tmtypeswaddr():
 *	Return the address of the application buffer type switch.
 *	This routine should always be used instead of the "tm_typesw"
 *	symbol, because some dynamic linking environments cannot
 *	access data symbols across libraries.
 */
TMTYPESW _TM_FAR *
#ifdef _TMPROTOTYPES
_TMDLLENTRY
_tmtypeswaddr(void)
#else
_tmtypeswaddr()
#endif
{
#if defined(sun) && !defined(SOLARIS)
	/* On SunOS 4.x this forces proper loading of this library */
	(void) time(0);
#endif
	return(tm_typesw);
}

#ifdef _TM_WIN

#include <windows.h>

int FAR PASCAL
WEP (int bSystemExit)
{
	bSystemExit = bSystemExit;      /* unused */
	return(1);
}

int FAR PASCAL
LibMain(HANDLE hModule, WORD wDataSeg, WORD cbHeapSize, LPSTR lpszCmdLine)
{
	hModule = hModule;
	wDataSeg = wDataSeg;
	cbHeapSize = cbHeapSize;
	lpszCmdLine = lpszCmdLine;
	return(1);
}

#endif

#ifdef _TM_OS2_32
unsigned long _System _DLL_InitTerm(unsigned long hModule, unsigned long ulFlag)
{
	switch(ulFlag) {
		case 0:
		if(_CRT_init() == -1)
			return(0UL);
		break;

		case 1:
		_CRT_term();
		break;
	}
	return(1UL);
}
#endif

#ifdef _TM_NETWARE
static void bufCleanup(int);
static int bufCleanupNLM(void *);

int
#ifdef _TMPROTOTYPES
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif
{
	LibHandle = RegisterLibrary(bufCleanupNLM);
	_e_signal(NULL, SIGTERM, bufCleanup);
	ExitThread(TSR_THREAD, 0);
}

static int
#ifdef _TMPROTOTYPES
bufCleanupNLM(void *arg)
#else
bufCleanupNLM(arg)
void *arg;
#endif
{
	(void) printf("Client 0x%lx exits\n", arg);
	free_data(arg);
	return(0);
}

static void
#ifdef _TMPROTOTYPES
bufCleanup(int sig)
#else
bufCleanup(sig)
int sig;
#endif
{
	/* Free all the contexts */
	(void) printf("GP Signal Cleanup function called\n");
	DeregisterLibrary(LibHandle);
	return;
}

#endif /* _TM_NETWARE */
