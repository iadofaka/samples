#!libbuft.so
_tmtypeswaddr
P24_add_formula
P24_get_formula
