/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */


/* #ident "@(#) samples/salt/custtypeapp/tuxserver/mapping_ids.c $Revision: 1.3 $" */

#include <custtype_pi_ex.h>
#include "mapping_plugin.h"

static int    g_pi_cnt = 2;
static char * g_ids    = "P_CUSTOM_TYPE;P_CUSTOM_TYPE";
static char * g_names  = "POINT24;EmployeeConvert";

/**
 * Return all interfaces implemented in this library
 */
int _DLLEXPORT_ _ws_pi_get_Id_and_Names(int *cnt, char **ids, char ** names)
{
    *cnt   = g_pi_cnt;
    *ids   = g_ids;
    *names = g_names;
    return 0;
}

