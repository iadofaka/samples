/*  (c) 2007 BEA Systems, Inc. All Rights Reserved. */
/*
    Copyright (c)  2007  BEA Systems, Inc.
    All rights reserved

    THIS IS UNPUBLISHED PROPRIETARY
    SOURCE CODE OF BEA Systems, Inc.
    The copyright notice above does not
    evidence any actual or intended
    publication of such source code.
 */


/* #ident   "@(#) samples/salt/custtypeapp/tuxserver/emp.c    $Revision: 1.4 $" */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <atmi.h>       /* TUXEDO  Header File */
#include <userlog.h>
#include <fml32.h>

#include "emp.fml32.h"


int
#if defined(__STDC__) || defined(__cplusplus)
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif

{
    FBFR32 *sendbuf, *rcvbuf;
    long rcvlen;
    FLDOCC32 count;
    int ret, i;
    char buff[512];

    /* Attach to System/T as a Client Process */
    if (tpinit((TPINIT *) NULL) == -1) {
        (void) fprintf(stderr, "Tpinit failed\n");
        exit(1);
    }

    /* Allocate FML32 buffers for the request and the reply */
    if((sendbuf = (FBFR32 *) tpalloc("FML32", NULL, 4096)) == NULL) {
        (void) fprintf(stderr,"Error allocating send buffer\n");
        tpterm();
        exit(1);
    }

    if((rcvbuf = (FBFR32 *) tpalloc("FML32", NULL, 4096)) == NULL) {
        (void) fprintf(stderr,"Error allocating receive buffer\n");
        tpfree((char *)sendbuf);
        tpterm();
        exit(1);
    }

    /* get inquiry condition from std input */
    fprintf(stdout, "Specify employee name ([enter] for any): ");
    fgets(buff, sizeof(buff), stdin);
    if ( buff[strlen(buff)-1] == '\n' )
        buff[strlen(buff)-1] = '\0';
    if ( buff[0] != '\0' )
        Fadd32(sendbuf, F_NAME, buff, 0);

    fprintf(stdout, "Specify employee gender (F for female, M for male, [enter] for any): ");
    fgets(buff, sizeof(buff), stdin);
    if ( buff[strlen(buff)-1] == '\n' )
        buff[strlen(buff)-1] = '\0';
    if ( buff[0] != '\0' )
        Fadd32(sendbuf, F_GENDER, buff, 0);

    fprintf(stdout, "Specify employee type (e.g. Cat, Dog,..., [enter] for any): ");
    fgets(buff, sizeof(buff), stdin);
    if ( buff[strlen(buff)-1] == '\n' )
        buff[strlen(buff)-1] = '\0';
    if ( buff[0] != '\0' )
        Fadd32(sendbuf, F_TYPE, buff, 0);

    fprintf(stdout, "Specify employee dept ([enter] for any): ");
    fgets(buff, sizeof(buff), stdin);
    if ( buff[strlen(buff)-1] == '\n' )
        buff[strlen(buff)-1] = '\0';
    if ( buff[0] != '\0' )
        Fadd32(sendbuf, F_DEPT, buff, 0);

    fprintf(stdout, "Specify employee no ([enter] for any): ");
    fgets(buff, sizeof(buff), stdin);
    if ( buff[strlen(buff)-1] == '\n' )
        buff[strlen(buff)-1] = '\0';
    if ( buff[0] != '\0' ) {
        long empno = atoi(buff);
        Fadd32(sendbuf, F_DEPT, (char *)&empno, 0);
    }

    /* Request the service GETEMPLOYEE, waiting for a reply */
    ret = tpcall("GETEMPLOYEE", (char *)sendbuf, 0, (char **)&rcvbuf, &rcvlen, (long)0);
    if(ret == -1) {
        if ( TPESVCFAIL == tperrno ) {
            (void) fprintf(stderr, "service GETEMPLOYEE return TPFAIL\n");
        } else {
            (void) fprintf(stderr, "Can't send request to service GETEMPLOYEE\n");
            (void) fprintf(stderr, "Tperrno = %d, %s\n", tperrno, tpstrerror(tperrno));
        }
        tpfree((char *)sendbuf);
        tpfree((char *)rcvbuf);
        tpterm();
        exit(1);
    }

    count = Foccur32(rcvbuf, F_NAME);
    (void) fprintf(stdout, "\nEmployees matched :  %d\n\n", count);

    if ( count > 0 ) {

        (void) fprintf(stdout, "%-20s %6s %-10s %-6s %-20s\n",
                       "Name", "Gender", "Type", "Empno", "Dept");
        (void) fprintf(stdout, "==================================================================\n");

        for ( i = 0 ; i < count ; i++ )
        {
            FLDLEN32 len;
            long empno;
            char gender;
            char * name, * type, * dept;

            empno = Fvall32(rcvbuf, F_EMPNO, i);
            Fget32(rcvbuf, F_GENDER, i, &gender, &len);
            name = Fvals32(rcvbuf, F_NAME, i);
            type = Fvals32(rcvbuf, F_TYPE, i);
            dept = Fvals32(rcvbuf, F_DEPT, i);

            (void) fprintf(stdout, "%-20s   %c    %-10s  %04ld  %-20s\n",
                           name, gender, type, empno, dept);

        }

        (void) fprintf(stdout, "==================================================================\n");
    }

    /* Free Buffers & Detach from System/T */
    tpfree((char *)sendbuf);
    tpfree((char *)rcvbuf);
    tpterm();
    return(0);
}
