/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */

/*
       Copyright (c)  2007  BEA Systems, Inc.
       All rights reserved

       THIS IS UNPUBLISHED PROPRIETARY
       SOURCE CODE OF BEA Systems, Inc.
       The copyright notice above does not
       evidence any actual or intended
       publication of such source code.
*/

/* #ident "@(#) samples/salt/obauthmapp/credmap_plugin.cpp $Revision: 1.7 $" */

#ifndef WIN32
#include <unistd.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <atmi.h>
#include <credmap_pi_ex.h>
#include <userlog.h>

#include <string>
#include <algorithm>
#include <vector>
#include <list>

#if defined(__hpux) && !defined(_HP_NAMESPACE_STD)
#include <iostream.h>
#include <fstream.h>
#else
#include <iostream>
#include <fstream>
using namespace std;
#endif

#if defined(WIN32)
#define _DLLEXPORT_  _declspec(dllexport)
#else
#define _DLLEXPORT_
#endif

#define INIT_CREDENMAP        _ws_pi_init_P_CREDENMAP_PLAINFILE
#define EXIT_CREDENMAP        _ws_pi_exit_P_CREDENMAP_PLAINFILE
#define SETVTBL_CREDENMAP     _ws_pi_set_vtbl_P_CREDENMAP_PLAINFILE

static const char * type_name = "PLAINFILE";

typedef vector<string> cred_entry;
static list<cred_entry> cred_map;

class find_entry {
    cred_entry& entry;
public:    
    find_entry(cred_entry& en) : entry(en) {}

    bool operator() (cred_entry & en) {
		for (int i = 0; i < 4; i++) {
			string & str1 =  en[i];
			string & str2 = entry[i];

			if (str1.size() == 0)
				continue;
			if (str1 != str2) 
				return false;
		}
		return true;
    }
};

/*
 * _ws_pi_init_P_CREDENMAP_XXXX()
 * _ws_pi_exit_P_CREDENMAP_XXXX()
 * _ws_pi_set_vtbl_P_CREDENMAP_XXXX()
 *
 * These three functions must be implemented for a plugin library
 *
 */
extern "C" {

    int _DLLEXPORT_ INIT_CREDENMAP(char * params, void ** priv_ptr) {
		userlog((char *)"%s: plugin init for credential mapping",  type_name);
		try {
			// Get the file name
			ifstream ifs ( params , ifstream::in );
			while (ifs.good()) {
				string line;
				getline(ifs,line);

				userlog((char *)"%s: line: %s",  type_name,line.c_str());		
				// skip null line
				if ( !line.length() )
					continue;
				// skip comments
				if ('#' == line[0])
					continue;
 
				cred_entry entry;

				size_t begin = 0;
				size_t end = 0;
				for( int i = 0; i < 5; i++ ) {
					end = line.find(';',begin);
					if ( string::npos == end) {
						userlog((char *)"%s: password mapping file format error: %s",type_name,line.c_str());
						return -1;
					}
					string temp = line.substr(begin, end - begin);
					entry.push_back(temp);
					begin = end + 1;
				}

				string temp = line.substr(begin);
				entry.push_back(temp);
	
				if ( (entry[4].size() == 0) || (entry[4].size() == 0)) {
					userlog((char *)"%s: no user name and password in this line: %s",type_name,line.c_str());
					break;
				} 
				cred_map.push_back(entry);
			}
			ifs.close();
		} catch (...) {
			userlog((char *)"%s: plugin init failed", type_name);
			return -1;
		}
		return 0;
    }

    int Credmap_Passtext(char * domain, char * realm, char * t_userid, char * t_grpid, Cred_UserPass * credential) 
    {
		if (cred_map.begin() == cred_map.end()) {
			userlog((char *)"%s: no credential mapping entry");
			return -1;
		}

		try {
			userlog((char *)"%s: find credential for %s;%s;%s;%s", type_name, domain,realm,t_userid,t_grpid);
			cred_entry entry;
			entry.push_back(string(domain));
			entry.push_back(string(realm));
			entry.push_back(string(t_userid));
			entry.push_back(string(t_grpid));
    
			find_entry fe(entry); 
						
			list<cred_entry>::iterator it = find_if(cred_map.begin(),cred_map.end(),fe);
	    
			if (cred_map.end() == it) {
				userlog((char *)"%s: can not find credential for %s;%s;%s;%s", type_name, domain,realm,t_userid,t_grpid);
				return -1;
			}
	    
			string un = (*it)[4];
			string pw = (*it)[5];

			if(strlen(un.c_str()) > (UP_USERNAME_LEN - 1))
				userlog((char *)"%s: the username '%s' is too long and will be truncated.", type_name, un.c_str());
			strncpy(credential->username,un.c_str(),UP_USERNAME_LEN -1);
			credential->username[UP_USERNAME_LEN -1] = NULL;

			if(strlen(pw.c_str()) > (UP_PASSWORD_LEN - 1))
				userlog((char *)"%s: the password '%s' is too long and will be truncated.", type_name, pw.c_str());
			strncpy(credential->password,pw.c_str(),UP_PASSWORD_LEN -1);
			credential->password[UP_PASSWORD_LEN -1] = NULL;
		} catch (...) {
			userlog((char *)"%s: can not find credential for %s;%s;%s;%s", type_name, domain,realm,t_userid,t_grpid);
			return -1;
		}
		return 0;
    }

    int _DLLEXPORT_ EXIT_CREDENMAP(void *priv_ptr) {
		userlog((char *) "%s: plugin exit for credential mapping", type_name);
		return 0;
    }

    int _DLLEXPORT_ SETVTBL_CREDENMAP(void * vtbl)
    {
		struct credmap_vtable * vtable;
		if ( ! vtbl )
			return -1;
    
		vtable = (struct credmap_vtable *) vtbl;
    
		vtable->gwws_pi_map_http_basic = Credmap_Passtext;

		userlog((char *)"%s: setup vtable for credential mapping", type_name);
    
		return 0;
    }

}// extern "C"
