/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */

/* Copyright (c) 2007 BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

/* ident  "@(#) samples/salt/obcredmapp/tux/Client.c   $Revision: 1.3 $" */

#include <stdio.h>
#include <string.h>
#include <atmi.h>
#include <time.h>
#include <fml32.h>
#include "obauthapp.fml32.h"
#include <stdlib.h>
#include <limits.h>

void
#ifdef _TMPROTOTYPES
usage(char * app)
#else
usage(app)
char * app;
#endif
{
	fprintf(stderr, "Usage: %s <app_passwd> <user_name> <user_passwd>",app);
	exit(1);
}

int 
#ifdef _TMPROTOTYPES
main(int argc, char *argv[])
#else
main(argc, argv)
int argc;
char *argv[];
#endif
{
    unsigned long len;
    long 		rlen = 4096;
    int 		ret;
    char 		err_str[180];
    int 		exit_code = 0;
    TPINIT *	init_buf;
    int 		ret_value;
    char *		io_buf;
    long 		rcv_len;

	FBFR32 *	reqfmlptr = NULL, *repfmlptr = NULL;
	FBFR32 *	subreqfmlptr = NULL;
	FBFR32 *	csubreqfmlptr = NULL;

	char *		app_password = NULL;
	char *		user_name = NULL;
	char * 		user_password = NULL;
	

	if (argc < 4) {
		usage(argv[0]);
	}

	app_password = argv[1];
	user_name = argv[2];
	user_password = argv[3];
	/*
	 * Allocate the TPINIT buffer and populate it.
	 * Call tpinit() to attach to the application.
	 */
	init_buf = (TPINIT *)tpalloc("TPINIT", NULL,
								 (long)(sizeof(TPINIT) + strlen(user_password) +1));
	if (init_buf == NULL) {
		(void)fprintf(stderr, "Allocation of TPINIT buffer failed, error = %d: %s",
					  tperrno, tpstrerror(tperrno));
		exit(1);
	}

	(void)strcpy(init_buf->usrname, user_name);
	(void)strcpy(init_buf->passwd, app_password);
	(void)strcpy((char *)&init_buf->data, user_password);

	ret_value = tpinit(init_buf);
	if (ret_value == -1) {
		(void)fprintf(stderr, "Failed to attach to the application, error = %d: %s",
					  tperrno, tpstrerror(tperrno));
		exit(1);
	}
	tpfree((char *)init_buf);

    /* allocate for databuffer for req and rep*/
    if ( (reqfmlptr = (FBFR32 *) tpalloc("FML32", NULL, 4096)) == NULL ) {
        (void) fprintf( stderr, "Unable to allocate FML32 datatype:%s\n",tpstrerror(tperrno));
        return(1);
    }
    if ( (subreqfmlptr = (FBFR32 *) tpalloc("FML32", NULL, 4096)) == NULL ) {
        (void) fprintf( stderr, "Unable to allocate FML32 datatype:%s\n",tpstrerror(tperrno));
        return(1);
    }
    if ( (csubreqfmlptr = (FBFR32 *) tpalloc("FML32", NULL, 4096)) == NULL ) {
        (void) fprintf( stderr, "Unable to allocate FML32 datatype:%s\n",tpstrerror(tperrno));
        return(1);
    }

    if ( (repfmlptr = (FBFR32 *) tpalloc("FML32", NULL, 4096)) == NULL ) {
        (void) fprintf( stderr, "Unable to allocate FML32 datatype:%s\n",tpstrerror(tperrno));
        return(1);
    }

    Fchg32(csubreqfmlptr,testElement,0,((char*)"T"),0);
    Fchg32(subreqfmlptr,inbuf,0,((char *)csubreqfmlptr),0);
    Fchg32(reqfmlptr,obauthapp,0,(char*)subreqfmlptr,0);
    
    
    (void) printf("The input buffer ->\n");
    Fprint32(reqfmlptr);
    
    ret=tpcall("obauthapp",(char *)reqfmlptr,1,(char **)&repfmlptr,&rlen,TPNOTIME);
    if ( ret  == -1){ 
		(void) fprintf(stderr, "tpcall(%s) failed:%s\n","obauthapp",tpstrerror(tperrno));
		return(1);
    } 
    
	printf( "The output buffer ->\n");
	Fprint32(repfmlptr);

    return(0);
}
