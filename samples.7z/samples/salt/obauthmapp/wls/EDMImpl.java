/* (c) 2007 BEA Systems, Inc. All Rights Reserved. */

/* Copyright (c) 2007 BEA Systems, Inc.
   All rights reserved
 
   THIS IS UNPUBLISHED PROPRIETARY
   SOURCE CODE OF BEA Systems, Inc.
   The copyright notice above does not
   evidence any actual or intended
   publication of such source code.
*/

/* ident  "@(#) samples/salt/obauthmapp/wls/EDMImpl.java   $Revision: 1.4 $" */

package bea.webservices.wsdlc;

import javax.jws.WebService;
import weblogic.jws.*;
import salt11.edm_typedef.pack.Outbuf;
import weblogic.jws.security.RolesAllowed;
import weblogic.jws.security.SecurityRole;

/**
 * EDMImpl class implements web service endpoint interface EDM
 */

@WebService(
  serviceName="EDM",
  targetNamespace="urn:EDM.wsdl",
  endpointInterface="bea.webservices.wsdlc.EDM")
@WLHttpTransport(contextPath="obauthapp",serviceUri="EDM",portName="HTTP_IN")

@RolesAllowed (  {
    @SecurityRole (role="obauthmapp",
                   mapToPrincipals={ "user1" })
} )
public class EDMImpl implements EDM {
    public EDMImpl() {
    }

    public salt11.edm_typedef.pack.Outbuf obauthapp(salt11.edm_typedef.pack.Inbuf inbuf) 
    {
        Outbuf outbuf = new Outbuf();
        outbuf.setTestElement(inbuf.getTestElement());
        return outbuf; 
    }
}

