#   (c) 2007 BEA Systems, Inc. All Rights Reserved.
#
#   Copyright (c) 2007 BEA Systems, Inc.	
#   All Rights Reserved 	 
#
#   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF 
#   BEA Systems, Inc.  
#   The copyright notice above does not evidence any  
#   actual or intended publication of such source code.
#
#	ident	"@(#) samples/salt/abauthmapp/setenv.cmd	$Revision: 1.4 $"

# Setup environment for WebLogic Server 10.0
export WL_HOME=@WebLogic 10.0 home directory@
. $WL_HOME/samples/domains/wl_server/setExamplesEnv.sh

# Setup environment for C/C++ compiler
export PATH=@Your C++ compiler path@:$PATH

# Setup environment for sample Weblogic Server.
export WLS_SERVER_NAME=@Server name of WebLogic sample server@
export WLS_HOSTNAME=@Host name of WebLogic sample server@
export WLS_PORT=@Port of WebLogic sample server@
export WLS_USERNAME=@Admin user name of WebLogic sample server@
export WLS_PASSWORD=@Admin password of WebLogic sample server@

# Set environment for Tuxedo and Salt
export TUXDIR=@Your TUXDIR@
export LANG=C
export PATH=$TUXDIR/bin:$ANT_HOME/bin:$PATH
export SHLIB_PATH=$TUXDIR/lib:$SHLIB_PATH
export LIBPATH=$TUXDIR/lib:$LIBPATH
export LD_LIBRARY_PATH=$TUXDIR/lib:$LD_LIBRARY_PATH

# Set environment for plugin compiling
export DLL_SUFFIX=@DLL SUFFIX@ # For example Solaris:.so.71 ; AIX:.so ; HPUX:.sl
export MAKE=@Make command@ # For example gmake
# You can set MAKEFILE as follow:
# makefile.aix		:	For AIX
# makefile.iahp		:	For HP-UX Itanium
# makefile.iahp64	:	For HP-UX Itanium 64-bit
# makefile.lnx		:	For Linux
# makefile.pahp		: 	For HP-UX PARISC
# makefile.sol		:	For Solaris
export MAKEFILE=@Select a makefile in tux directory@


export APPDIR=`pwd`/tux/work
export HOSTNAME=`uname -n`

export GROUPID=10
export GROUPNAME=group1
export USERNAME=user1
export USERPASSWORD=12345678
